<?php
use yii\helpers\Html;
/* @var $this yii\web\View */
/* @var $user common\models\User */
?>
<div class="password-reset" style="margin-bottom:15px;" >
    <h5>Dear Admin,</h5>
    <p style="margin-bottom:15px;">
      testing...
    </p>
</div>
