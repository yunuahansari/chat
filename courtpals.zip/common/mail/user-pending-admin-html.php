<?php
use yii\helpers\Html;

$resetLink = \Yii::$app->urlManagerFrontEnd->createAbsoluteUrl(['admin']); 
?>

<p style="margin-bottom:30px;margin-top: 0">Dear Courtpals Administrator,</p>
<p style="margin-bottom:30px;margin-top: 0"><?php echo $user->first_name.' '.$user->last_name ?> signed up on <?php echo date('F  d,Y',  strtotime($user->created_at)) ?> with Courtpals. <?php echo $user->first_name.' '.$user->last_name ?> bar number is <?php echo $user->bar_number?> .</p>
<p style="margin-bottom:30px;margin-top: 0">Please click <?= Html::a('here',Html::encode($resetLink)) ?> to approve or decline the user </p>
<p style="margin-bottom:5px;">Thanks</p>
<p style="margin-bottom:10px; margin-top: 0">Courtpals</p>

