<?php
use yii\helpers\Html;

?>

<p style="margin-bottom:30px;margin-top: 0">Dear <?= ucfirst($request->to->first_name) ?>,</p>
    
    <p style="margin-bottom:25px;">You have cancelled case Case ID<?= $request->case_id ?> before 24 hours from scheduled appearance.</p>
    
    <p style="margin-bottom:25px;">You will not get any financial compensation for your cancelled case and the cancellation will be recorded.</p>
    
    <p style="margin-bottom:25px;">We do not encourage cancellations once a placement is made – please review our <?= Html::a('cancellation policy',Html::encode(\Yii::$app->urlManagerFrontEnd->createAbsoluteUrl("/cancellation-policy"))) ?> in detail.</p>
    
        
 <p style="margin-bottom:5px;">Thanks</p>
<p style="margin-bottom:10px; margin-top: 0">Courtpals</p>
