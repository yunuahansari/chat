<?php

/* @var $this yii\web\View */
/* @var $user common\models\User */

?>
<p style="margin-bottom:30px;margin-top: 0">Dear <?= ucfirst($request->to->first_name) ?>,</p>

<p style="margin-bottom:25px;">Your client attorney has requested a payment refund for Case ID (<?= $request->case_id ?>) . </p>

<p style="margin-bottom:25px;">This payment refund request will initiate a dispute case with Courtpals. Your cooperation in resolving the dispute is appreciated. We will inform you once a resolution has been reached.</p>

<p style="margin-bottom:5px;">Thanks</p>
<p style="margin-bottom:10px; margin-top: 0">Courtpals</p>