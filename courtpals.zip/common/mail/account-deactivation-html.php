<?php
use yii\helpers\Html;

?>

<p style="margin-bottom:30px;margin-top: 0">Dear <?php echo ucfirst($user->first_name); ?>,</p>
<p style="margin-bottom:25px;">Unfortunately, Your account has been de-activated by Courtpals. You will no longer be able to login to your accout!</p>
<p style="margin-bottom:25px;">Please get in touch with Courtpals for further assistance.</p>
<p style="margin-bottom:5px;">Thanks & Regards</p>
<p style="margin-bottom:10px; margin-top: 0">Courtpals</p>

