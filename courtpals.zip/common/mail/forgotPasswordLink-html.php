<?php
use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $user common\models\User */

$resetLink = Yii::$app->urlManager->createAbsoluteUrl(['auth/login/reset-password', 'token' => $user->verified_code]);
?>
<p style="margin-bottom:30px;margin-top: 0">Hello <?= ucfirst($user->first_name) ?>,</p>

    <p style="margin-bottom:30px;">We have received a request to reset your password. Please click on <?= Html::a('this', Html::encode($resetLink)) ?>  link (or the one below) to reset your password.</p>

    <p style="margin-bottom:30px;"><?= Html::a(Html::encode($resetLink), $resetLink) ?></p>

    <p style="margin-bottom:5px;">Thanks</p>
<p style="margin-bottom:10px; margin-top: 0">Courtpals</p>
