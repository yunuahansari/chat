<?php
use yii\helpers\Html;

$resetLink = \Yii::$app->urlManagerFrontEnd->createUrl(['site/account-activation', 'verified_code' => $user->verified_code]); 
?>

<p style="margin-bottom:30px;margin-top: 0">Dear <?php echo ucfirst($request->to->first_name); ?>,</p>
<p style="margin-bottom:30px;">You have just cancelled your appearance for Case ID <?= $request->case_id ?> . </p>
<p style="margin-bottom:30px;">Pursuant to our <?= Html::a('cancellation policy',Html::encode(\Yii::$app->urlManagerFrontEnd->createAbsoluteUrl("/cancellation-policy"))) ?> ,you are now banned from using Courtpals. </p>
<p style="margin-bottom:30px;">Please contact administrator to activate your account again.</p>
<p style="margin-bottom:5px;">Thanks</p>
<p style="margin-bottom:10px; margin-top: 0">Courtpals</p>

