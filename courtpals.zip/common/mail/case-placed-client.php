<?php

use yii\helpers\Html;
?>

<tr>
    <td  valign="top" style="padding:0px 40px 0 40px;"><p style="margin-bottom:30px;margin-top: 0;color:#000">
            Dear <?= ucfirst($request->from->first_name) ?>,
    </td>
</tr>
<tr>
    <td  valign="top" style="padding:0px 40px 0 40px;"><p style="margin-bottom:30px;margin-top: 0;color:#000">
     Your case has been placed on courtpals! The case details which you have submitted are as follows:</p>
    </td>
</tr>
<tr>
    <td valign="top" style="padding:0 40px;">
        <table style="font-family:Tahoma, Geneva, sans-serif;">
            <tr>
                <td valign="top" width="340px" style="padding: 5px 0">Fee ( You have paid )</td>
                <td valign="top" style="padding: 5px 0;color: #888;">$<?= $request->transactions->amount ?></td>
            </tr>
            <tr>
                <td valign="top" width="340px" style="padding: 5px 0">Pal Attorney</td>
                <td valign="top" style="padding: 5px 0;color: #888;"><?= ucfirst($request->to->first_name).' '.$request->to->last_name ?></td>
            </tr>
            <tr>
                <td valign="top" width="340px" style="padding: 5px 0">Case ID (This Case is system generated)</td>
                <td valign="top" style="padding: 5px 0;color: #888;"><?= $request->case_id ?></td>
            </tr>
            <tr>
                <td valign="top" width="340px" style="padding: 5px 0">Case Number</td>
                <td valign="top" style="padding: 5px 0;color: #888;"><?= $request->case_number ?></td>
            </tr>
            <tr>
                <td valign="top" width="340px" style="padding: 5px 0">Location</td>
                <td valign="top" style="padding: 5px 0;color: #888;"><?= $request->address ?></td>
            </tr>
            <tr>
                <td valign="top" width="340px" style="padding: 5px 0">Date/Time</td>
                <td valign="top" style="padding: 5px 0;color: #888;"><?= date('F d, Y h:i A', strtotime($request->case_date . ' ' . $request->case_time)) ?></td>
            </tr>
            <tr>
                <td valign="top" width="340px" style="padding: 5px 0">Parties</td>
                <td valign="top" style="padding: 5px 0;color: #888;">
                    <p><b>Goverment Party</b><br> <?= $request->party_2 ?></p>
                    <p><b>Client Party</b><br><?= $request->party_1 ?></p>
                </td>

            </tr>
            <tr>
                <td valign="top" width="340px" style="padding: 5px 0">Hearing Type</td>
                <td valign="top" style="padding: 5px 0;color: #888;"><?= $request->hearingType->name ?></td>
            </tr>
            <tr>
                <td valign="top" width="340px" style="padding: 5px 0">Sub hearing Type</td>
                <td valign="top" style="padding: 5px 0;color: #888;"><?= $request->sub_hearing_type ?></td>
            </tr>
            <tr>
                <td valign="top" width="340px" style="padding: 5px 0">Attachment</td>
                <td valign="top" style="padding: 5px 0">
                    <?php
                    if (!empty($request->caseRequestImages)) {
                        foreach ($request->caseRequestImages as $image) {
                            ?>
                            <img width="120" src="<?php echo Yii::getAlias('@document_url') . '/' . $image['image'] ?>">
                            <?php
                        }
                    }
                    ?>
                </td>
            </tr>
            <tr>
                <td valign="top" width="340px" style="padding: 5px 0">Description</td>
                <td valign="top" style="padding: 5px 0;color: #888;">
                    <?= $request->description; ?>
                </td>
            </tr>
            <tr>
                <td valign="top" width="340px" style="padding: 5px 0">Desired outcome</td>
                <td valign="top" style="padding: 5px 0;color: #888;">
                    <?= $request->desired_outcome; ?>
                </td>
            </tr>
            <tr>
                <td colspan="2" valign="top" width="340px" style="padding: 5px 0">
                    <p style="margin-bottom:5px;">Thanks</p>
                    <p style="margin-bottom:10px; margin-top: 0">Courtpals</p>
                </td>
            </tr>
        </table>
    </td>
</tr>


