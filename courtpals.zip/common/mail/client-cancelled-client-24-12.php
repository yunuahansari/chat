<?php
use yii\helpers\Html;

?>
<p style="margin-bottom:30px;margin-top: 0">Dear <?= ucfirst($request->from->first_name) ?>,</p>
    
<p style="margin-bottom:30px;">You have cancelled placed Case ID <?= $request->case_id ?>  12-24 hours from the scheduled appearance.</p>
<p style="margin-bottom:30px;">You will receive 100% amount re-fund back to you. We do not encourage cancellations once a placement is made – please review our <?= Html::a('cancellation policy',Html::encode(\Yii::$app->urlManagerFrontEnd->createAbsoluteUrl("/cancellation-policy"))) ?> in detail.</p>
    
        
<p style="margin-bottom:5px;">Thanks</p>
<p style="margin-bottom:10px; margin-top: 0">Courtpals</p>
