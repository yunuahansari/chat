<?php
use yii\helpers\Html;


?>

<p style="margin-bottom:30px;margin-top: 0">Dear <?php echo ucfirst($user->first_name); ?>,</p>
<p style="margin-bottom:25px;">Congratulations, your account with Courtpals has been approved!</p>

<p style="margin-bottom:5px;">Thanks</p>
<p style="margin-bottom:10px; margin-top: 0">Courtpals</p>

