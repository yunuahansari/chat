<?php
use yii\helpers\Html;

?>

<p style="margin-bottom:30px;margin-top: 0">Dear <?= ucfirst($request->from->first_name) ?>,</p>
    
    <p style="margin-bottom:25px;">Your case Case ID <?= $request->case_id ?> was cancelled 12-24 hours from before the scheduled appearance. Our system will re-post same case requirement to get new pal attorney. </p>
    
    <p style="margin-bottom:25px;">If case cannot be re-placed with a new pal, then we will refund 100% back.</p>
    
    <p style="margin-bottom:25px;">We do not encourage cancellations once a placement is made – please review our <?= Html::a('cancellation policy',Html::encode(\Yii::$app->urlManagerFrontEnd->createAbsoluteUrl("/cancellation-policy"))) ?> in detail.</p>
        
<p style="margin-bottom:5px;">Thanks</p>
<p style="margin-bottom:10px; margin-top: 0">Courtpals</p>
