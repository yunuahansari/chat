<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $user common\models\User */
?>
<div class="password-reset" style="margin-bottom:15px;">
    <h5>Dear <?= ucfirst($data['fullname']) ?>,</h5>
    <p>Subject - <?= Html::encode($data['page_title']) ?></p>
    <p style="margin-bottom:25px;">Thank you for registring with Courtpals.</p>
    <p style="margin-bottom:25px;">Please verify your email by clicking the given link <?= Html::a('verification link', Html::encode($data['verifylink'])) ?></p>
    <p style="margin-bottom:5px;">Thanks</p>
    <p style="margin-bottom:10px; margin-top: 0">Courtpals</p>
</div>
