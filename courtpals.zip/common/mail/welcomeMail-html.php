<?php
use yii\helpers\Html;


?>

<p style="margin-bottom:30px;margin-top: 0">Dear <?php echo ucfirst($user->first_name); ?>,</p>
<p style="margin-bottom:25px;">You have been joined with Courtpals.</p>
<p style="margin-bottom:25px;">Welcome to Courtpals</p>
<p style="margin-bottom:25px;">Your username:<?php echo $user->email?></p>
<p style="margin-bottom:25px;">Your password:<?php echo $password?></p>
<p style="margin-bottom:5px;">Thanks & Regards</p>
<p style="margin-bottom:10px; margin-top: 0">Courtpals</p>

