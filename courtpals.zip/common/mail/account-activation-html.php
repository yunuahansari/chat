<?php
use yii\helpers\Html;

?>

<p style="margin-bottom:30px;margin-top: 0">Dear <?php echo ucfirst($user->first_name); ?>,</p>
<p style="margin-bottom:25px;">Welcome to Courtpals</p>
<p style="margin-bottom:25px;">Your account has been activated by Courtpals. Now you can login to Courtpals and explore it!</p>
<p style="margin-bottom:5px;">Thanks & Regards</p>
<p style="margin-bottom:10px; margin-top: 0">Courtpals</p>

