<?php
use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $user common\models\User */


?>
<div class="password-reset" style="margin-bottom:15px;">
    <p> <?= Html::encode($user->first_name.' '.$user->last_name) ?>,want contact to you for followings</p>

    <p style="margin-bottom:15px;">
       <?php echo "<br><br>" ?>
        
        message:- <?php echo$post['message'] ?>
    </p>

</div>
