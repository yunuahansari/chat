<?php
use yii\helpers\Html;

?>
<p style="margin-bottom:40px;margin-top: 0">Dear <?= ucfirst($request->from->first_name) ?>,</p>
    
<p style="margin-bottom:30px;">Congrats! Your case has been successfully completed . Please give your pal a review. See you again for another appearance soon! </p>
    
        
<p style="margin-bottom:5px;">Thanks</p>
<p style="margin-bottom:10px; margin-top: 0">Courtpals</p>

