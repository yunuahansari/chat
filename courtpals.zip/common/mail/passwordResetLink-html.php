<?php
use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $user common\models\User */

$resetLink = Yii::$app->urlManager->createAbsoluteUrl(['auth/auth/reset-password', 'token' => $user->password_reset_token]);

?>

<p style="margin-bottom:30px;margin-top: 0">Hello <?= ucfirst($user->first_name) ?>,</p>

<p style="margin-bottom:30px;">We have received a request to reset your password. Please click on this link to reset your password.</p>

<p style="margin-bottom:30px;"><?= Html::a(Html::encode($resetLink), $resetLink) ?></p>
    
<p style="margin-bottom:5px;">Thanks</p>
<p style="margin-bottom:10px; margin-top: 0">Courtpals</p>
