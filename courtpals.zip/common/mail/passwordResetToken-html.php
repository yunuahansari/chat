<?php
use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $user common\models\User */
?>
    
<p style="margin-bottom:30px;margin-top: 0">Hello <?= ucfirst($user->first_name) ?>,</p>

    <p style="margin-bottom:30px;">We have received a request to reset your password. If you didn’t make the request, please ignore this email. </p>
    <p style="margin-bottom:30px;">If you did, then please enter code <?php echo $user->verified_code; ?>  to reset your password.</p>
    <p style="margin-bottom:10px;">You will only have 24 hours to reset your password.</p>
    <p style="margin-bottom:5px;">Thanks</p>
<p style="margin-bottom:10px; margin-top: 0">Courtpals</p>
