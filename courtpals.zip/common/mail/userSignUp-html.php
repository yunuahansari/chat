<?php
use yii\helpers\Html;

$resetLink = \Yii::$app->urlManagerFrontEnd->createAbsoluteUrl(['site/account-activation', 'verified_code' => $user->verified_code]); 
?>

<p style="margin-bottom:30px;margin-top: 0">Dear <?php echo ucfirst($user->first_name); ?>,</p>
<p style="margin-bottom:25px;">Congratulations, you have successfully signed up with Courtpals. Please click on <?= Html::a('this',Html::encode($resetLink)) ?> link (or the one below) to activate your account.</p>
<p style="margin-bottom:25px;"><?= Html::a(Html::encode($resetLink), $resetLink) ?></p>
<p style="margin-bottom:25px;">After account activation, you can login and explore Courtpals!</p>
<p style="margin-bottom:5px;">Thanks</p>
<p style="margin-bottom:10px; margin-top: 0">Courtpals</p>

