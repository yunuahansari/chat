<?php
use yii\helpers\Html;

/* @var $this \yii\web\View view component instance */
/* @var $message \yii\mail\MessageInterface the message being composed */
/* @var $content string main view render result */
?> 
<?php $this->beginPage() ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
        <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no"/>
        <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
        <title>COURTPALS</title>
        <style type="text/css">
table {
    mso-table-lspace: 0pt;
    mso-table-rspace: 0pt;
}
td, th {
    border-collapse: collapse;
}
td a {
    text-decoration: none;
    border: none;
    color: #265AFF;
}
</style>
        <?php $this->head() ?>
        </head>

        <body>
        <table align="center" cellspacing="0" cellpadding="0" width="800" style="table-layout:fixed;margin:0 auto;border-collapse:collapse;font-family:Tahoma, Geneva, sans-serif; font-size:16px;border: 1px solid #009BDA;border-top: 0;">
          <tbody>
            <tr >
              <td valign="middle" align="center"><img vspace="0" hspace="0" border="0" align="center" src="<?php  echo \Yii::getAlias('@base_url') ?>/frontend/web/images/email-template/email_image.p" width="100%" /></td>
            </tr>
            <tr>
                <td  valign="top" style="padding:25px 30px;">
                    <?= $content ?>  
                </td>
            </tr>
               <tr bgcolor="#009BDA">
                  <td style="padding:7px 30px;color:#fff;font-size: 14px;">
                      <table style="font-family:Tahoma, Geneva, sans-serif" >
                          <tr>
                              <td width="400" align="left" style="color:#fff;">© 2017 courtpals.com. All rights reserved.</td>
                                <td width="400" align="right">
                                <a  href="#"><img src="<?php  echo \Yii::getAlias('@base_url') ?>/frontend/web/images/email-template/ico_fb.png"></a> 
<!--                                <a href=""><img src="<?php  echo \Yii::getAlias('@base_url') ?>/frontend/web/images/email-template/ico_twitter.png"></a> 
                                <a href=""><img src="<?php  echo \Yii::getAlias('@base_url') ?>/frontend/web/images/email-template/ico_gplus.png"></a></td>-->
                          </tr>
                      </table>
                  </td>
                </tr>
          </tbody>
        </table>
</body>
</html>
<?php $this->endPage() ?>
