<?php
use yii\helpers\Html;

?>

<p style="margin-bottom:30px;margin-top: 0">Dear <?= ucfirst($request->to->first_name) ?>,</p>
    
    <p style="margin-bottom:30px;">Thank  you for completing case successfully. You will receive case review and rating from client shortly. </p>
    <p style="margin-bottom:10px;">Payment will be made to the bank account on file.</p>
    <p style="margin-bottom:30px;">Happy lawyering! </p>
    
        
<p style="margin-bottom:5px;">Thanks</p>
<p style="margin-bottom:10px; margin-top: 0">Courtpals</p>
