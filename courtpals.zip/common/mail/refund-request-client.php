<?php

/* @var $this yii\web\View */
/* @var $user common\models\User */

?>
<p style="margin-bottom:30px;margin-top: 0">Dear <?= ucfirst($request->from->first_name) ?>,</p>

<p style="margin-bottom:25px;">You have requested a payment refund for Case ID(<?= $request->case_id ?>). </p>

<p style="margin-bottom:25px;">This payment refund request will initiate a dispute case with Courtpals. We will inform you once a resolution has been reached. In the meantime, your payment will be frozen until further notice</p>

<p style="margin-bottom:5px;">Thanks</p>
<p style="margin-bottom:10px; margin-top: 0">Courtpals</p>