<?php

namespace common\models;

use Yii;
use common\models\User;
use yii\data\ActiveDataProvider;

/**
 * This is the model class for table "favorites".
 *
 * @property integer $id
 * @property integer $from_user_id
 * @property integer $to_user_id
 * @property string $status
 * @property string $created_at
 * @property string $updated_at
 *
 * @property User $fromUser
 * @property User $toUser
 */
class Favorites extends \common\models\base\BaseFavorites {

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return 'favorites';
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['from_user_id', 'to_user_id'], 'integer'],
            [['status'], 'string'],
            [['created_at', 'updated_at'], 'safe'],
            [['from_user_id'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['from_user_id' => 'id']],
            [['to_user_id'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['to_user_id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'id' => 'ID',
            'from_user_id' => 'From User ID',
            'to_user_id' => 'To User ID',
            'status' => 'Status',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    public function fields() {
        $field = parent::fields();
        $array = [
            'user_image' => function($model) {
                $user = User::find()->where(['id' => $model->to_user_id])->one();
                if (!empty($user->profile_pic)) {
                    return \Yii::getAlias('@user_image_url') . '/' . $user->profile_pic;
                }return \Yii::getAlias('@user_image_url') . '/' . 'default.png';
            },
                    'user_name' => function($model) {
                return $model->toUser->user_name?$model->toUser->user_name:$model->toUser->first_name.' '.$model->toUser->last_name;
            },
                    'user_ratting' => function($model) {
               $sum = 0;
                $user_ratting = 0;
                $reviev = Review::find()->where(['to_user_id' => $model->to_user_id])->all();
                if (!empty($reviev)) {
                    $length = count($reviev);
                    foreach ($reviev as $value) {
                        $sum = $sum + $value->rating;
                    }
                    $user_ratting = floor($sum / $length);
                    return $user_ratting;
                }return $user_ratting;
            },
                    'user_specialization' => function($model) {
                return $model->toUser->userSpecializations;
            }
                ];
                return array_merge($array, $field);
            }

            public static function makeFavourite($post) {

                $from_user_id = \yii::$app->user->id;
                $checkExist_model = self::checkExistFavourite($from_user_id, $post['to_user_id']);
                if (!empty($checkExist_model)) {
                    $checkExist_model->status = self::updateFaveUnfave($post['isFave']);
                    $checkExist_model->save(false);
                    return $checkExist_model;
                }
                $favourite_model = new Favorites();
                $favourite_model->from_user_id = $from_user_id;
                $favourite_model->to_user_id = $post['to_user_id'];
                $favourite_model->status = self::updateFaveUnfave($post['isFave']);
                $user = User::getUserByAttr(['id' => $post['to_user_id']]);
                if (!empty($user)) {
                    if ($favourite_model->save(false)) {
                        return $favourite_model;
                    }
                }return false;
            }

            public static function updateFaveUnfave($status) {
                if ($status == 'true') {
                    return 'active';
                } else {
                    return 'inactive';
                }
            }

            public static function checkExistFavourite($from_user_id, $touser_id) {
                return self::find()->where(['from_user_id' => $from_user_id, 'to_user_id' => $touser_id])->one();
            }

            public static function getFavouriteList() {
                $user_id = \yii::$app->user->id;
                $query = self::find()->where(['from_user_id' => $user_id,'status'=>'active']);
                $provider = new ActiveDataProvider([
                    'query' => $query,
                    'pagination' => [
                        'pageSize' => 10,
                    ],
                ]);
                return $provider;
            }

            /**
             * @return \yii\db\ActiveQuery
             */
            public function getFromUser() {
                return $this->hasOne(User::className(), ['id' => 'from_user_id']);
            }

            /**
             * @return \yii\db\ActiveQuery
             */
            public function getToUser() {
                return $this->hasOne(User::className(), ['id' => 'to_user_id']);
            }

            public static function getStatus($param) {
                $return = self::find()->where(['AND', ['=', 'from_user_id', $param['from_user_id']], ['=', 'to_user_id', $param['to_user_id']], ['=', 'status', 'active']])->one();
                if ($return) {
                    return true;
                }
                return false;
            }

        }
        