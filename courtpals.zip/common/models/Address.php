<?php

namespace common\models;

use Yii;
use yii\data\ActiveDataProvider;
use yii\helpers\ArrayHelper;
use api\components\Utility;

/**
 * This is the model class for table "address".
 *
 * @property integer $id
 * @property integer $user_id
 * @property string $address
 * @property string $created_at
 * @property string $updated_at
 *
 * @property User $user
 * @property AddressFav[] $addressFavs
 */
class Address extends \common\models\base\BaseAddress {

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return 'address';
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['address','hearing_type_id'], 'required'],
            [['created_at', 'updated_at', 'address','hearing_type_id','court_name','people_dhs'], 'safe'],
            [['address'], 'string', 'max' => 255],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'id' => 'ID',
            'user_id' => 'User ID',
            'address' => 'Address',
            'hearing_type_id' => 'Hearing Type',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    public function behaviors() {
        return [
            'timestamp' => [
                'class' => \yii\behaviors\TimestampBehavior::className(),
                'createdAtAttribute' => 'created_at',
                'updatedAtAttribute' => 'updated_at',
                'value' => new \yii\db\Expression("'" . date('Y-m-d H:i:s') . "'"),
                'attributes' => [
                    \yii\db\ActiveRecord::EVENT_BEFORE_INSERT => ['created_at', 'updated_at'],
                    \yii\db\ActiveRecord::EVENT_BEFORE_UPDATE => ['updated_at'],
                ],
            ],
        ];
    }

    public function fields() {
        $parentFields = parent::fields();
        $fields = [
            'is_favorite' => function($model) {
                return AddressFav::checkIsFavourite($model->id);
            },
            'hearing_type' => function ($model){
                return $model->hearingType->name;
            }
        ];
        unset($parentFields['created_at'], $parentFields['updated_at']);
        return ArrayHelper::merge($parentFields, $fields);
    }
    
    /**
     * @return \yii\db\ActiveQuery
     */
    public function getHearingType()
    {
        return $this->hasOne(HearingType::className(), ['id' => 'hearing_type_id']);
    }
    
    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUser() {
        return $this->hasOne(User::className(), ['id' => 'user_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getAddressFavs() {
        return $this->hasMany(AddressFav::className(), ['address_id' => 'id']);
    }
    
    public static function addAddress($post) {

        $model = new Address();
        $model->load($post, '');
        $model->user_id = \yii::$app->user->id;
        if ($model->save(false)) {
            return true;
        }return false;
    }

    public static function getAddress($data) {
        if (!empty($data['search'])) {
            return self::find()->where(['like', 'address', $data['search']])->all();
        } else {
            return self::find()->all();
        }
    }

    public static function saveLatLong() {
        $address = self::find()->all();
        if (!empty($address)) {
            foreach ($address as $address) {
                $latlong = Utility::getlatitudeLongitude($address);
                $address->latitude = $latlong['latitude'];
                $address->longitude = $latlong['longitude'];
                $address->save(false);
            }
        }
    }

    public static function allAddresses($post) {

        if (!empty($post['search'])) {
            $addresses = self::find()->where(['like', 'address', $post['search']]);
        } else {
            $addresses = self::find();
        }
        if (!empty($addresses)) {
            $provider = new ActiveDataProvider([
                'query' => $addresses,
                'sort'=> ['defaultOrder' => ['id' => SORT_DESC]],
                'pagination' => [
                    'pageSize' => 5,
                ],
            ]);
        }
        return $provider;
    }

    public static function getAll() {
        $address = self::find()->all();
        $dataList = ArrayHelper::map($address, 'id', 'address');
        $data = array();
        $count = count($dataList);
        if ($count > 0) {
            return $dataList;
        } else {
            return $data;
        }
    }

}
