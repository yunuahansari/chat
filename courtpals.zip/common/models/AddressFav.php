<?php

namespace common\models;

use Yii;


/**
 * This is the model class for table "address_fav".
 *
 * @property integer $id
 * @property integer $address_id
 * @property string $status
 * @property string $created_at
 * @property string $updated_at
 *
 * @property Address $address
 */
class AddressFav extends \yii\db\ActiveRecord
{

    /**
     * @inheritdoc
     */
    public static function tableName ()
    {
        return 'address_favourite';
    }

    /**
     * @inheritdoc
     */
    public function rules ()
    {
        return [
            [['address_id'], 'integer'],
            [['status'], 'string'],
            [['created_at', 'updated_at', 'address','place_id'], 'safe'],
            [['address_id'], 'exist', 'skipOnError' => true, 'targetClass' => Address::className(), 'targetAttribute' => ['address_id' => 'id']],
        ];
    }

    public function behaviors ()
    {
        return [
            'timestamp' => [
                'class' => \yii\behaviors\TimestampBehavior::className(),
                'createdAtAttribute' => 'created_at',
                'updatedAtAttribute' => 'updated_at',
                'value' => new \yii\db\Expression("'" . date('Y-m-d H:i:s') . "'"),
                'attributes' => [
                    \yii\db\ActiveRecord::EVENT_BEFORE_INSERT => ['created_at', 'updated_at'],
                    \yii\db\ActiveRecord::EVENT_BEFORE_UPDATE => ['updated_at'],
                ],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels ()
    {
        return [
            'id' => 'ID',
            'address_id' => 'Address ID',
            'status' => 'Status',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }
    
    /**
     * @return \yii\db\ActiveQuery
     */
    public function getAddress ()
    {
        return $this->hasOne(Address::className(), ['id' => 'address_id']);
    }

    
    public static function favouriteUnfavourite ($post)
    {
        if($post['status']=='unfavourite'){
            AddressFav::deleteAll(['AND',['address_id'=>$post['address_id']],['user_id'=>  \yii::$app->user->id]]);
            return true;
        }
        $model = new AddressFav();
        $model->load($post, '');
        $model->user_id = \yii::$app->user->id;
        if ($model->save(false)) {
            return true;
        }
        return false;
    }
    
    public static function getListOfFavouriteAddress ()
    {
        return self::find()->where(['user_id'=>  \yii::$app->user->id])->all();
       
    }

    public static function checkIsFavourite($id){
        if(\Yii::$app->user->getId()){
            $count = self::find()->where(['user_id' => Yii::$app->user->getId(),'address_id' => $id, 'status' => 'favourite'])->count();
            if($count){
                return true;
            }
        }
        return false;
    }
    
}
