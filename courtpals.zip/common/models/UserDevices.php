<?php

namespace common\models;

use Yii;
use yii\helpers\ArrayHelper;

 class UserDevices extends \yii\db\ActiveRecord{
        
     public function rules() {
        return ArrayHelper::merge(
            parent::rules(),
            [
                    
                ]);
       }
       
       public function attributeLabels() {
        return ArrayHelper::merge(
            parent::attributeLabels(),
            [
                    
                ]);
       }
}
