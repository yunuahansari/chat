<?php

namespace common\models;

use Yii;
use yii\helpers\ArrayHelper;

/**
 * This is the model class for table "case_request_images".
 *
 * @property integer $id
 * @property integer $case_request_id
 * @property string $image
 * @property string $status
 * @property string $created_at
 * @property string $updated_at
 *
 * @property CaseRequest $caseRequest
 */
class CaseRequestImages extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'case_request_images';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['case_request_id'], 'integer'],
            [['status'], 'string'],
            [['created_at', 'updated_at'], 'safe'],
            [['image'], 'string', 'max' => 255],
            [['case_request_id'], 'exist', 'skipOnError' => true, 'targetClass' => CaseRequest::className(), 'targetAttribute' => ['case_request_id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'case_request_id' => 'Case Request ID',
            'image' => 'Image',
            'status' => 'Status',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }
    
     public function behaviors ()
    {
        return [
            'timestamp' => [
                'class' => \yii\behaviors\TimestampBehavior::className(),
                'createdAtAttribute' => 'created_at',
                'updatedAtAttribute' => 'updated_at',
                'value' => new \yii\db\Expression("'" . date('Y-m-d H:i:s') . "'"),
                'attributes' => [
                    \yii\db\ActiveRecord::EVENT_BEFORE_INSERT => ['created_at', 'updated_at'],
                    \yii\db\ActiveRecord::EVENT_BEFORE_UPDATE => ['updated_at'],
                ],
            ],
        ];
    }

    public function fields ()
    {
        $parentFields = parent::fields();
        $fields = [
            'document_url' => function($model){
                if($model->image != '' && file_exists('../../api/web/upload/document/'.$model->image)){
                    return Yii::getAlias('@document_url').'/'.$model->image;
                }
                return '';
            },
            'document_type' => function($model){
                if($model->image != '' && file_exists('../../api/web/upload/document/'.$model->image)){
                    $type = explode('.', $model->image);
                    return end($type);
                }
                return '';
            }
        ];
        unset($parentFields['created_at'], $parentFields['updated_at'], $parentFields['status']);
        return ArrayHelper::merge($parentFields, $fields);
    }
    
    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCaseRequest()
    {
        return $this->hasOne(CaseRequest::className(), ['id' => 'case_request_id']);
    }
}
