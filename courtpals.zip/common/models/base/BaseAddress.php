<?php

namespace common\models\base;

use Yii;

/**
 * This is the model class for table "address".
 *
 * @property integer $id
 * @property string $address
 * @property string $court_name
 * @property integer $hearing_type_id
 * @property string $latitude
 * @property string $longitude
 * @property string $created_at
 * @property string $updated_at
 * @property string $people_dhs
 *
 * @property AddressFavourite[] $addressFavourites
 * @property Departments[] $departments
 */
class BaseAddress extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'address';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['address'], 'string'],
            [['hearing_type_id'], 'integer'],
            [['created_at', 'updated_at'], 'safe'],
            [['court_name', 'latitude', 'longitude', 'people_dhs'], 'string', 'max' => 255],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'address' => 'Address',
            'court_name' => 'Court Name',
            'hearing_type_id' => 'Hearing Type ID',
            'latitude' => 'Latitude',
            'longitude' => 'Longitude',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
            'people_dhs' => 'People Dhs',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getAddressFavourites()
    {
        return $this->hasMany(AddressFavourite::className(), ['address_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getDepartments()
    {
        return $this->hasMany(Departments::className(), ['address_id' => 'id']);
    }
}
