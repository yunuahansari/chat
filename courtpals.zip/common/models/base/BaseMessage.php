<?php

namespace common\models\base;

use Yii;

/**
 * This is the model class for table "message".
 *
 * @property integer $id
 * @property string $case_id
 * @property string $sticker_id
 * @property integer $sender
 * @property integer $receiver
 * @property string $type
 * @property integer $receiver_read
 * @property integer $sender_delete
 * @property integer $receiver_delete
 * @property string $message
 * @property string $media
 * @property string $thumbnail
 * @property string $time_stamp
 * @property string $created_at
 * @property string $updated_at
 *
 * @property User $sender0
 * @property User $receiver0
 */
class BaseMessage extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'message';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['sender', 'receiver', 'receiver_read', 'sender_delete', 'receiver_delete'], 'integer'],
            [['message'], 'string'],
            [['created_at'], 'required'],
            [['created_at', 'updated_at'], 'safe'],
            [['case_id', 'sticker_id', 'type', 'media', 'thumbnail', 'time_stamp'], 'string', 'max' => 255],
            [['sender'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['sender' => 'id']],
            [['receiver'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['receiver' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'case_id' => 'Case ID',
            'sticker_id' => 'Sticker ID',
            'sender' => 'Sender',
            'receiver' => 'Receiver',
            'type' => 'Type',
            'receiver_read' => 'Receiver Read',
            'sender_delete' => 'Sender Delete',
            'receiver_delete' => 'Receiver Delete',
            'message' => 'Message',
            'media' => 'Media',
            'thumbnail' => 'Thumbnail',
            'time_stamp' => 'Time Stamp',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getSender0()
    {
        return $this->hasOne(User::className(), ['id' => 'sender']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getReceiver0()
    {
        return $this->hasOne(User::className(), ['id' => 'receiver']);
    }
}
