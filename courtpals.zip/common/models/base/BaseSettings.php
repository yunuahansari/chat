<?php

namespace common\models\base;

use Yii;

/**
 * This is the model class for table "settings".
 *
 * @property integer $id
 * @property string $key_name
 * @property string $value
 * @property string $created_at
 * @property string $updated_at
 */
class BaseSettings extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'settings';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['created_at', 'updated_at'], 'safe'],
            [['key_name'], 'string', 'max' => 255],
            [['key_value'], 'integer'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'key_name' => 'Key Name',
            'key_value' => 'Value',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    /**
     * @inheritdoc
     * @return \common\models\query\SettingsQuery the active query used by this AR class.
     */
    public static function find()
    {
        return new \common\models\query\SettingsQuery(get_called_class());
    }
}
