<?php

namespace common\models\base;

use Yii;

/**
 * This is the model class for table "notification".
 *
 * @property integer $id
 * @property string $type
 * @property integer $from_id
 * @property integer $to_id
 * @property string $message
 * @property string $read_status
 * @property string $notification_data
 * @property string $status
 * @property string $created_at
 * @property string $updated_at
 * @property integer $request_id
 *
 * @property User $to
 * @property User $from
 * @property CaseRequest $request
 */
class BaseNotification extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'notification';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['from_id', 'to_id', 'request_id'], 'integer'],
            [['read_status', 'status'], 'string'],
            [['created_at', 'updated_at'], 'safe'],
            [['type', 'message', 'notification_data'], 'string', 'max' => 255],
            [['to_id'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['to_id' => 'id']],
            [['from_id'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['from_id' => 'id']],
            [['request_id'], 'exist', 'skipOnError' => true, 'targetClass' => CaseRequest::className(), 'targetAttribute' => ['request_id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'type' => 'Type',
            'from_id' => 'From ID',
            'to_id' => 'To ID',
            'message' => 'Message',
            'read_status' => 'Read Status',
            'notification_data' => 'Notification Data',
            'status' => 'Status',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
            'request_id' => 'Request ID',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTo()
    {
        return $this->hasOne(User::className(), ['id' => 'to_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getFrom()
    {
        return $this->hasOne(User::className(), ['id' => 'from_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getRequest()
    {
        return $this->hasOne(CaseRequest::className(), ['id' => 'request_id']);
    }
}
