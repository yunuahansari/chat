<?php

namespace common\models\base;

use Yii;

/**
 * This is the model class for table "user".
 *
 * @property integer $id
 * @property string $role
 * @property string $first_name
 * @property string $last_name
 * @property string $email
 * @property string $password
 * @property string $profile_pic
 * @property string $address
 * @property string $mobile
 * @property integer $state
 * @property string $city
 * @property string $verified_code
 * @property string $auth_key
 * @property string $commition
 * @property string $status
 * @property string $created_at
 * @property string $updated_at
 * @property string $password_reset_token
 * @property string $bar_number
 * @property string $ssn_number
 * @property string $is_available
 * @property string $apeerance_type
 * @property string $type
 * @property string $profile_completed
 * @property string $zip_code
 * @property string $notification
 * @property string $stripe_customer_id
 * @property string $stripe_account_id
 * @property string $address2
 * @property string $can_place
 * @property string $approved
 *
 * @property AddressFavourite[] $addressFavourites
 * @property Auth[] $auths
 * @property BankAccountDetail[] $bankAccountDetails
 * @property CaseRequest[] $caseRequests
 * @property CaseRequest[] $caseRequests0
 * @property CaseRequest[] $caseRequests1
 * @property CaseReviews[] $caseReviews
 * @property Favorites[] $favorites
 * @property Favorites[] $favorites0
 * @property HearingDetail[] $hearingDetails
 * @property Message[] $messages
 * @property Message[] $messages0
 * @property Notification[] $notifications
 * @property Notification[] $notifications0
 * @property RepostCases[] $repostCases
 * @property Review[] $reviews
 * @property Review[] $reviews0
 * @property Transactions[] $transactions
 * @property Transactions[] $transactions0
 * @property UserBankDetails[] $userBankDetails
 * @property UserDevices[] $userDevices
 */
class BaseUser extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'user';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['role', 'status', 'is_available', 'type', 'profile_completed', 'notification', 'can_place', 'approved'], 'string'],
            [['state'], 'integer'],
            [['created_at', 'updated_at'], 'safe'],
            [['first_name'], 'string', 'max' => 30],
            [['last_name', 'password', 'profile_pic', 'address', 'mobile', 'city', 'verified_code', 'auth_key', 'commition', 'password_reset_token', 'apeerance_type', 'zip_code', 'stripe_customer_id', 'stripe_account_id', 'address2'], 'string', 'max' => 255],
            [['email'], 'string', 'max' => 50],
            [['bar_number', 'ssn_number'], 'string', 'max' => 100],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'role' => 'Role',
            'first_name' => 'First Name',
            'last_name' => 'Last Name',
            'email' => 'Email',
            'password' => 'Password',
            'profile_pic' => 'Profile Pic',
            'address' => 'Address',
            'mobile' => 'Mobile',
            'state' => 'State',
            'city' => 'City',
            'verified_code' => 'Verified Code',
            'auth_key' => 'Auth Key',
            'commition' => 'Commition',
            'status' => 'Status',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
            'password_reset_token' => 'Password Reset Token',
            'bar_number' => 'Bar Number',
            'ssn_number' => 'Ssn Number',
            'is_available' => 'Is Available',
            'apeerance_type' => 'Apeerance Type',
            'type' => 'Type',
            'profile_completed' => 'Profile Completed',
            'zip_code' => 'Zip Code',
            'notification' => 'Notification',
            'stripe_customer_id' => 'Stripe Customer ID',
            'stripe_account_id' => 'Stripe Account ID',
            'address2' => 'Address2',
            'can_place' => 'Can Place',
            'approved' => 'Approved',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getAddressFavourites()
    {
        return $this->hasMany(AddressFavourite::className(), ['user_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getAuths()
    {
        return $this->hasMany(Auth::className(), ['user_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getBankAccountDetails()
    {
        return $this->hasMany(BankAccountDetail::className(), ['user_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCaseRequests()
    {
        return $this->hasMany(CaseRequest::className(), ['from_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCaseRequests0()
    {
        return $this->hasMany(CaseRequest::className(), ['to_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCaseRequests1()
    {
        return $this->hasMany(CaseRequest::className(), ['cancelled_by' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCaseReviews()
    {
        return $this->hasMany(CaseReviews::className(), ['user_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getFavorites()
    {
        return $this->hasMany(Favorites::className(), ['from_user_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getFavorites0()
    {
        return $this->hasMany(Favorites::className(), ['to_user_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getHearingDetails()
    {
        return $this->hasMany(HearingDetail::className(), ['user_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getMessages()
    {
        return $this->hasMany(Message::className(), ['sender' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getMessages0()
    {
        return $this->hasMany(Message::className(), ['receiver' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getNotifications()
    {
        return $this->hasMany(Notification::className(), ['from_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getNotifications0()
    {
        return $this->hasMany(Notification::className(), ['to_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getRepostCases()
    {
        return $this->hasMany(RepostCases::className(), ['user_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getReviews()
    {
        return $this->hasMany(Review::className(), ['from_user_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getReviews0()
    {
        return $this->hasMany(Review::className(), ['to_user_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTransactions()
    {
        return $this->hasMany(Transactions::className(), ['from_user_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTransactions0()
    {
        return $this->hasMany(Transactions::className(), ['to_user_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUserBankDetails()
    {
        return $this->hasMany(UserBankDetails::className(), ['user_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUserDevices()
    {
        return $this->hasMany(UserDevices::className(), ['user_id' => 'id']);
    }
}
