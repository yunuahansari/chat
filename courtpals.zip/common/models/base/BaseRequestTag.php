<?php

namespace common\models\base;

use Yii;

/**
 * This is the model class for table "request_tag".
 *
 * @property integer $id
 * @property integer $tag_id
 * @property integer $request_id
 * @property string $created_at
 * @property string $updated_at
 *
 * @property Tags $tag
 * @property CaseRequest $request
 */
class BaseRequestTag extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'request_tag';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['tag_id', 'request_id'], 'integer'],
            [['created_at', 'updated_at'], 'safe'],
            [['tag_id'], 'exist', 'skipOnError' => true, 'targetClass' => Tags::className(), 'targetAttribute' => ['tag_id' => 'id']],
            [['request_id'], 'exist', 'skipOnError' => true, 'targetClass' => CaseRequest::className(), 'targetAttribute' => ['request_id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'tag_id' => 'Tag ID',
            'request_id' => 'Request ID',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTag()
    {
        return $this->hasOne(Tags::className(), ['id' => 'tag_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getRequest()
    {
        return $this->hasOne(CaseRequest::className(), ['id' => 'request_id']);
    }
}
