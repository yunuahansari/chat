<?php

namespace common\models\base;

use Yii;

/**
 * This is the model class for table "bank_account_detail".
 *
 * @property integer $id
 * @property integer $user_id
 * @property string $stripe_bank_account_id
 * @property string $account_name
 * @property string $bank_name
 * @property integer $ach_bank_aba_number
 * @property integer $account_number
 * @property string $customer_address
 * @property string $status
 * @property string $created_at
 * @property string $updated_at
 *
 * @property User $user
 */
class BaseBankAccountDetail extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'bank_account_detail';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['user_id', 'ach_bank_aba_number', 'account_number'], 'integer'],
            [['status'], 'string'],
            [['created_at', 'updated_at'], 'safe'],
            [['stripe_bank_account_id', 'account_name', 'bank_name', 'customer_address'], 'string', 'max' => 255],
            [['user_id'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['user_id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'user_id' => 'User ID',
            'stripe_bank_account_id' => 'Stripe Bank Account ID',
            'account_name' => 'Account Name',
            'bank_name' => 'Bank Name',
            'ach_bank_aba_number' => 'Ach Bank Aba Number',
            'account_number' => 'Account Number',
            'customer_address' => 'Customer Address',
            'status' => 'Status',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUser()
    {
        return $this->hasOne(User::className(), ['id' => 'user_id']);
    }
}
