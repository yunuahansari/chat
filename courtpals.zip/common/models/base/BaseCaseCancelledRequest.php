<?php

namespace common\models\base;

use Yii;

/**
 * This is the model class for table "case_cancelled_request".
 *
 * @property integer $id
 * @property integer $request_id
 * @property double $client_amount
 * @property double $peer_amount
 * @property string $status
 * @property string $created_at
 * @property string $updated_at
 *
 * @property CaseRequest $request
 */
class BaseCaseCancelledRequest extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'case_cancelled_request';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['request_id', 'client_amount', 'created_at', 'updated_at'], 'required'],
            [['request_id'], 'integer'],
            [['client_amount', 'peer_amount'], 'number'],
            [['status'], 'string'],
            [['created_at', 'updated_at'], 'safe'],
            [['request_id'], 'exist', 'skipOnError' => true, 'targetClass' => CaseRequest::className(), 'targetAttribute' => ['request_id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'request_id' => 'Request ID',
            'client_amount' => 'Client Amount',
            'peer_amount' => 'Peer Amount',
            'status' => 'Status',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getRequest()
    {
        return $this->hasOne(CaseRequest::className(), ['id' => 'request_id']);
    }
}
