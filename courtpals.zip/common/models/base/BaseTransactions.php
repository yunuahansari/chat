<?php

namespace common\models\base;

use Yii;

/**
 * This is the model class for table "transactions".
 *
 * @property integer $id
 * @property string $transaction_id
 * @property integer $request_id
 * @property integer $from_user_id
 * @property integer $to_user_id
 * @property string $amount
 * @property string $commition
 * @property string $status
 * @property string $card_last_four
 * @property string $card_exp_month
 * @property string $card_exp_year
 * @property string $brand
 * @property string $card_holder_name
 * @property string $created_at
 * @property string $updated_at
 *
 * @property CaseRequest $request
 * @property User $fromUser
 * @property User $toUser
 */
class BaseTransactions extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'transactions';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['request_id', 'from_user_id', 'to_user_id'], 'integer'],
            [['amount'], 'number'],
            [['status'], 'string'],
            [['created_at', 'updated_at'], 'safe'],
            [['transaction_id', 'commition', 'card_last_four', 'card_exp_month', 'card_exp_year', 'brand', 'card_holder_name'], 'string', 'max' => 255],
            [['request_id'], 'exist', 'skipOnError' => true, 'targetClass' => CaseRequest::className(), 'targetAttribute' => ['request_id' => 'id']],
            [['from_user_id'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['from_user_id' => 'id']],
            [['to_user_id'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['to_user_id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'transaction_id' => 'Transaction ID',
            'request_id' => 'Request ID',
            'from_user_id' => 'From User ID',
            'to_user_id' => 'To User ID',
            'amount' => 'Amount',
            'commition' => 'Commition',
            'status' => 'Status',
            'card_last_four' => 'Card Last Four',
            'card_exp_month' => 'Card Exp Month',
            'card_exp_year' => 'Card Exp Year',
            'brand' => 'Brand',
            'card_holder_name' => 'Card Holder Name',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getRequest()
    {
        return $this->hasOne(CaseRequest::className(), ['id' => 'request_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getFromUser()
    {
        return $this->hasOne(User::className(), ['id' => 'from_user_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getToUser()
    {
        return $this->hasOne(User::className(), ['id' => 'to_user_id']);
    }
}
