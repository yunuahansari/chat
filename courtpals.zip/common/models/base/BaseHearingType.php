<?php

namespace common\models\base;

use Yii;

/**
 * This is the model class for table "hearing_type".
 *
 * @property int $id
 * @property string $name
 * @property int $parent
 * @property string $price
 * @property string $status
 * @property string $created_at
 * @property string $updated_at
 *
 * @property CaseRequest[] $caseRequests
 * @property HearingDetail[] $hearingDetails
 */
class BaseHearingType extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'hearing_type';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['parent'], 'integer'],
            [['status'], 'string'],
            [['created_at', 'updated_at'], 'safe'],
            [['name', 'price'], 'string', 'max' => 255],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'parent' => 'Parent',
            'price' => 'Price',
            'status' => 'Status',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCaseRequests()
    {
        return $this->hasMany(CaseRequest::className(), ['hearing_type_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getHearingDetails()
    {
        return $this->hasMany(HearingDetail::className(), ['hearing_type' => 'id']);
    }
}
