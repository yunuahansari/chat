<?php

namespace common\models\base;

use Yii;

/**
 * This is the model class for table "case_request".
 *
 * @property integer $id
 * @property string $case_id
 * @property string $case_number
 * @property integer $from_id
 * @property integer $to_id
 * @property integer $department_id
 * @property integer $hearing_type_id
 * @property string $sub_hearing_type
 * @property string $address
 * @property string $case_date
 * @property string $case_time
 * @property string $party_1
 * @property string $party_2
 * @property string $party1_mobile
 * @property string $description
 * @property string $desired_outcome
 * @property string $paid_to_attorney
 * @property string $timezone
 * @property string $status
 * @property string $created_at
 * @property string $updated_at
 * @property integer $cancelled_by
 * @property string $other_department
 *
 * @property CaseCancelled[] $caseCancelleds
 * @property CaseCancelledRequest[] $caseCancelledRequests
 * @property User $from
 * @property User $to
 * @property Departments $department
 * @property HearingType $hearingType
 * @property User $cancelledBy
 * @property CaseRequestImages[] $caseRequestImages
 * @property CaseReviews[] $caseReviews
 * @property Notification[] $notifications
 * @property RequestTag[] $requestTags
 * @property Transactions[] $transactions
 */
class BaseCaseRequest extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'case_request';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['from_id', 'to_id', 'department_id', 'hearing_type_id', 'cancelled_by'], 'integer'],
            [['case_date', 'case_time', 'created_at', 'updated_at'], 'safe'],
            [['description', 'paid_to_attorney', 'status'], 'string'],
            [['case_id', 'case_number', 'sub_hearing_type', 'address', 'party_1', 'party_2', 'party1_mobile', 'desired_outcome', 'timezone', 'other_department'], 'string', 'max' => 255],
            [['from_id'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['from_id' => 'id']],
            [['to_id'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['to_id' => 'id']],
            [['department_id'], 'exist', 'skipOnError' => true, 'targetClass' => Departments::className(), 'targetAttribute' => ['department_id' => 'id']],
            [['hearing_type_id'], 'exist', 'skipOnError' => true, 'targetClass' => HearingType::className(), 'targetAttribute' => ['hearing_type_id' => 'id']],
            [['cancelled_by'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['cancelled_by' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'case_id' => 'Case ID',
            'case_number' => 'Case Number',
            'from_id' => 'From ID',
            'to_id' => 'To ID',
            'department_id' => 'Department ID',
            'hearing_type_id' => 'Hearing Type ID',
            'sub_hearing_type' => 'Sub Hearing Type',
            'address' => 'Address',
            'case_date' => 'Case Date',
            'case_time' => 'Case Time',
            'party_1' => 'Party 1',
            'party_2' => 'Party 2',
            'party1_mobile' => 'Party1 Mobile',
            'description' => 'Description',
            'desired_outcome' => 'Desired Outcome',
            'paid_to_attorney' => 'Paid To Attorney',
            'timezone' => 'Timezone',
            'status' => 'Status',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
            'cancelled_by' => 'Cancelled By',
            'other_department' => 'Other Department',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCaseCancelleds()
    {
        return $this->hasMany(CaseCancelled::className(), ['case_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCaseCancelledRequests()
    {
        return $this->hasMany(CaseCancelledRequest::className(), ['request_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getFrom()
    {
        return $this->hasOne(User::className(), ['id' => 'from_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTo()
    {
        return $this->hasOne(User::className(), ['id' => 'to_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getDepartment()
    {
        return $this->hasOne(Departments::className(), ['id' => 'department_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getHearingType()
    {
        return $this->hasOne(HearingType::className(), ['id' => 'hearing_type_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCancelledBy()
    {
        return $this->hasOne(User::className(), ['id' => 'cancelled_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCaseRequestImages()
    {
        return $this->hasMany(CaseRequestImages::className(), ['case_request_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCaseReviews()
    {
        return $this->hasMany(CaseReviews::className(), ['request_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getNotifications()
    {
        return $this->hasMany(Notification::className(), ['request_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getRequestTags()
    {
        return $this->hasMany(RequestTag::className(), ['request_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTransactions()
    {
        return $this->hasMany(Transactions::className(), ['request_id' => 'id']);
    }
}
