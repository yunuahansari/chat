<?php

namespace common\models;

use Yii;
use yii\helpers\ArrayHelper;
use yii\data\ActiveDataProvider;

/**
 * This is the model class for table "notification".
 *
 * @property integer $id
 * @property string $type
 * @property integer $from_id
 * @property integer $to_id
 * @property string $message
 * @property string $read_status
 * @property string $notification_data
 * @property string $status
 * @property string $created_at
 * @property string $updated_at
 * 
 * @property User $from
 * @property User $to
 */
class Notification extends \common\models\base\BaseNotification
{

    /**
     * @inheritdoc
     */
    public static function tableName ()
    {
        return 'notification';
    }
   
    /**
     * @inheritdoc
     */
    public function rules ()
    {
        return [
            [['from_id', 'to_id'], 'integer'],
            [['read_status', 'status'], 'string'],
            [['created_at', 'updated_at','request_id'], 'safe'],
            [['type', 'message', 'notification_data'], 'string', 'max' => 255],
            [['from_id'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['from_id' => 'id']],
            [['to_id'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['to_id' => 'id']],
        ];
    }

    public function behaviors ()
    {
        return [
            'timestamp' => [
                'class' => \yii\behaviors\TimestampBehavior::className(),
                'createdAtAttribute' => 'created_at',
                'updatedAtAttribute' => 'updated_at',
                'value' => new \yii\db\Expression("'" . date('Y-m-d H:i:s') . "'"),
                'attributes' => [
                    \yii\db\ActiveRecord::EVENT_BEFORE_INSERT => ['created_at', 'updated_at'],
                    \yii\db\ActiveRecord::EVENT_BEFORE_UPDATE => ['updated_at'],
                ],
            ],
        ];
    }
    
    public function fields ()
    {
        $parentFields = parent::fields();
        $fields = [
            'sender_name' => function($model) {
                return $model->from->first_name . ' ' . $model->from->last_name;
            },
            'receiver_name' => function($model) {
                return $model->to->first_name . ' ' . $model->to->last_name;
            },
            'can_place' => function($model) {
               $user =  User::getUserByAttr(['id'=>  \yii::$app->user->id]);
                return $user->can_place;
            },
            'notification_data' => function($model){
                if(is_string($model->notification_data)){
                    return json_decode($model->notification_data);
                }else{
                     return $model->notification_data;
                }
            }
        ];
        unset($parentFields['updated_at']);
        return ArrayHelper::merge($parentFields, $fields);
    }
   
    /**
     * @inheritdoc
     */
    public function attributeLabels ()
    {
        return [
            'id' => 'ID',
            'type' => 'Type',
            'from_id' => 'From ID',
            'to_id' => 'To ID',
            'message' => 'Message',
            'read_status' => 'Read Status',
            'notification_data' => 'Notification Data',
            'status' => 'Status',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }
            
            public static function getNotificationByAttr($attr) {
                return self::find()->where($attr)->one();
            }
            
            public static function getAllNotification ($param)
            {
                
                $user_id = \yii::$app->user->id;
                Notification::updateAll(['read_status' => 'read'], ['to_id' => $user_id]);
                $query = self::find()->where(['to_id' => $user_id, 'status' => 'active']);
                
                $dataProvider = new ActiveDataProvider([
                    'query' => $query,
                    'pagination' => [
                        'pageSize' => 10,
                    ],
                    'sort' => [
                        'defaultOrder' => [
                            'id' => SORT_DESC,
                        ]
                    ],
                ]);
                if(!empty($dataProvider)){
                    $returnData = [];
                    foreach ($dataProvider->getModels() as $data){
                        if($data->type!='self_cancel'){
                        $noti_data = json_decode($data->notification_data);
                        $data['notification_data'] = $noti_data;
                        $data['created_at'] = \api\components\Utility::getDateByTimezone($param['timezone'], $data->created_at);
                        $returnData[] = $data;
                    }}
                 $dataProvider->setModels($returnData);   
                }
                return $dataProvider;
            }

            public static function deleteNotification ($notification_id)
            {
                $array = [];
                $notification = self::find()->where(['id' => $notification_id])->one();
                if (!empty($notification)) {
                    $notification->status = "deleted";
                    if ($notification->save(false)) {
                        $de_status =  true;
                    }
                }else{ $de_status  = false;}
                $response = Notification::checkRatingRequest();
                $rat_status=(!empty($response))?true:false;
                $array['delete']=$de_status;
                $array['rating_status']=$rat_status;
                return $array;
            }

            public static function deleteAllNotification ()
            {
                $user_id = \yii::$app->user->id;
                $notifications = self::find()->where(['AND',['=','to_id',$user_id],['!=','type','ratting_request']])->all();
                if (!empty($notifications)) {
                    foreach ($notifications as $value) {
                        $value->status = "deleted";
                        $value->save(false);
                    }return true;
                }return false;
            }
            
          
            public static function checkRatingRequest(){
                $respose = self::find()->where(['AND',['=','type','ratting_request'] ,['=','to_id' , Yii::$app->user->id] ,['!=','status','deleted']])->one();
                if($respose){
                    return $respose;
                }
                return array();
            }

            /**
             * Function for saving new notifications
             * @param array $param
             * @return boolean
             */
            public static function saveNotification ($param)
            {
                if (!empty($param['to_id'])) {
                    foreach ($param['to_id'] as $to_id) {
                        $approved = User::find()->where(['AND', ['=', 'id', $to_id], ['=', 'approved', 'yes']])->one();
                        if (!empty($approved)) {
                            $model = new Notification;
                            $model->attributes = $param;
                            $model->to_id = $to_id;
                            $model->save(false);
                        }
                    }
                    return true;
                }
                return false;
            }
            public static function newNotification($user_id){
//    print_r($user_id);die;
                $count = self::find()->where(['to_id'=> $user_id,'read_status'=>'unread'])->count();
                return $count;
            }

            /**
             * @return \yii\db\ActiveQuery
             */
            public function getFrom ()
            {
                return $this->hasOne(User::className(), ['id' => 'from_id']);
            }

            /**
             * @return \yii\db\ActiveQuery
             */
            public function getTo ()
            {
                return $this->hasOne(User::className(), ['id' => 'to_id']);
            }

        }
        