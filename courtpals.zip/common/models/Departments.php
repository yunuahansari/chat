<?php

namespace common\models;

use Yii;
use yii\helpers\ArrayHelper;
use yii\data\ActiveDataProvider;

/**
 * This is the model class for table "departments".
 *
 * @property integer $id
 * @property string $name
 * @property string $status
 * @property string $created_at
 * @property string $updated_at
 *
 * @property CaseRequest[] $caseRequests
 */
class Departments extends base\BaseDepartments {

    public $address;

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return 'departments';
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['name', 'address_id'], 'required'],
            [['status'], 'string'],
            [['created_at', 'updated_at', 'address_id'], 'safe'],
            [['name'], 'string', 'max' => 255],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'status' => 'Status',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    public function behaviors() {
        return [
            'timestamp' => [
                'class' => \yii\behaviors\TimestampBehavior::className(),
                'createdAtAttribute' => 'created_at',
                'updatedAtAttribute' => 'updated_at',
                'value' => new \yii\db\Expression("'" . date('Y-m-d H:i:s') . "'"),
                'attributes' => [
                    \yii\db\ActiveRecord::EVENT_BEFORE_INSERT => ['created_at', 'updated_at'],
                    \yii\db\ActiveRecord::EVENT_BEFORE_UPDATE => ['updated_at'],
                ],
            ],
        ];
    }

    public function fields() {
        $parentFields = parent::fields();
        $fields = [
            'address' => function($model) {
                return $model->address->address;
            }
        ];
        unset($parentFields['created_at'], $parentFields['updated_at'], $parentFields['status']);
        return ArrayHelper::merge($parentFields, $fields);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCaseRequests() {
        return $this->hasMany(CaseRequest::className(), ['department_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getAddress() {
        return $this->hasOne(Address::className(), ['id' => 'address_id']);
    }

    public static function getAllDepartments($id) {
        return self::find()->where(['status' => 'active', 'address_id' => $id])->all();
    }

    public static function allDepartment($post) {

        $result = [];
        if (!empty($post['search'])) {
            $model = self::find()->where(['AND', ['status' => 'active'], ['like', 'name', $post['search']]]);
        } else {
            $model = self::find()->where(['status' => 'active']);
        }
        if (!empty($model)) {
            $provider = new ActiveDataProvider([
                'query' => $model,
                'sort'=> ['defaultOrder' => ['id' => SORT_DESC]],
                'pagination' => [
                    'pageSize' => 5,
                ],
            ]);
            foreach ($provider->getModels() as $value) {
                if ($value['address_id'] == 0) {
                    $value['address'] = 'not available';
                } else {
                    $value['address'] = self::addressParentName($value['address_id']);
                }
                $result[] = $value;
            }
            $provider->setModels($result);
            return $provider;
        }
    }

    public static function addressParentName($address_id) {
        return Address::find()->where(['id' => $address_id])->one()['address'];
    }

    public static function actionNewDepartment($model) {
        if ($model->validate()) {
            if ($model->save(false)) {
                return true;
            }return false;
        }
    }

}
