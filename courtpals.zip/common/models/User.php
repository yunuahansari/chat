<?php

namespace common\models;

use Yii;
use yii\base\NotSupportedException;
use yii\behaviors\TimestampBehavior;
use yii\db\ActiveRecord;
use yii\web\IdentityInterface;
use yii\data\ActiveDataProvider;
use yii\helpers\ArrayHelper;
use api\models\Payment;
use yii\web\UploadedFile;
use Zendesk\API\HttpClient as ZendeskAPI;

/**
 * User model
 *
 * @property integer $id

 * @property string $password_reset_token
 * @property string $email
 * @property string $auth_key
 * @property integer $status
 * @property integer $created_at
 * @property integer $updated_at
 * @property string $password write-only password
 */
class User extends \common\models\base\BaseUser implements IdentityInterface {

    const STATUS_DELETED = 'deleted';
    const STATUS_ACTIVE = 'active';
    const STATUS_INACTIVE = 'inactive';
    const STATUS_BANNED = 'banned';

    public $new_password;
    public $confirm_password;
    public $rating;
    public $full_name;
    public $apeerances;

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return '{{%user}}';
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['first_name', 'last_name', 'email', 'bar_number', 'ssn_number', 'address', 'mobile', 'city', 'zip_code', 'password', 'commition','dob'], 'required', 'on' => 'create_attorney'],
            [['first_name', 'last_name', 'email', 'bar_number', 'ssn_number', 'address', 'mobile', 'city', 'zip_code','commition','dob'], 'required', 'on' => ['update_pending_attorney','update_approved_attorney']],
            [['bar_number', 'ssn_number', 'address', 'mobile', 'city', 'zip_code', 'profile_pic'], 'required', 'on' => 'update'],
            [['email'], 'email', 'message' => '{attribute} is not a valid email address.'],
            ['ssn_number', 'string', 'min' => 9, 'on' => ['create_attorney', 'update','update_approved_attorney','update_pending_attorney']],
            ['ssn_number', 'string', 'max' => 9, 'on' => ['create_attorney', 'update','update_approved_attorney','update_pending_attorney']],
            [['email'], 'emailExistanceValidation', 'on' => 'update', 'message' => '{attribute} is already taken by another user.'],
            [['email'], 'unique', 'on' => 'create_attorney'],
            ['status', 'in', 'range' => [self::STATUS_ACTIVE, self::STATUS_DELETED, self::STATUS_INACTIVE, self::STATUS_BANNED]],
            [['first_name', 'last_name', 'email', 'bar_number', 'confirm_password', 'password', 'profile_pic', 'verified_code', 'auth_key', 'role', 'address', 'mobile', 'city', 'zip_code', 'ssn_number', 'profile_completed', 'notification', 'is_available', 'address2', 'commition','dob','can_place','approved'], 'safe'],
            [['password', 'new_password', 'confirm_password'], 'required', 'on' => 'changePassword', 'message' => '{attribute} not valid'],
            [['password'], 'validate_current_pasword', 'on' => 'changePassword'],
            [['confirm_password'], 'compare', 'compareAttribute' => 'new_password', 'operator' => '==', 'message' => 'Confirm password must be same.', 'on' => 'changePassword'],
                //[['first_name', 'last_name', 'email','password', 'confirm_password'], 'required', 'on' => 'signUp']
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'role' => 'Role',
            'type' => 'Type',
            'first_name' => 'First Name',
            'last_name' => 'Last Name',
            'email' => 'Email ID',
            'password' => 'Password',
            'profile_pic' => 'Profile Pic',
            'address' => 'Address',
            'mobile' => 'Phone Number',
            'city' => 'City',
            'zip_code' => 'Zip Code',
            'verified_code' => 'Verified Code',
            'bar_number' => 'BAR Number',
            'snn_number' => 'SSN Number',
            'auth_key' => 'Auth Key',
            'status' => 'Status',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
            'commition'=>'Commission'
        ];
    }

    public function behaviors() {
        return [
            'timestamp' => [
                'class' => \yii\behaviors\TimestampBehavior::className(),
                'createdAtAttribute' => 'created_at',
                'updatedAtAttribute' => 'updated_at',
                'value' => new \yii\db\Expression("'" . date('Y-m-d H:i:s') . "'"),
                'attributes' => [
                    \yii\db\ActiveRecord::EVENT_BEFORE_INSERT => ['created_at', 'updated_at'],
                    \yii\db\ActiveRecord::EVENT_BEFORE_UPDATE => ['updated_at'],
                ],
            ],
        ];
    }

    public function fields() {

        $fields = [
            'profile_pic' => function($model) {
                return \common\components\Utility::getUserImage($model->id);
            },'type','dob',
            'full_name' => function($model) {
                return $model->first_name . ' ' . $model->last_name;
            },
            'user_ratting' => function($model) {
                return Review::averageRatting($model->id);
            },
            'case_detail' => function($model) {
                $case_detail = [];
                if ($model->id != \yii::$app->user->id) {
                    $case_detail = CaseRequest::findAllRunningCase($model->id);
                }return $case_detail;
            },
            'bank_details' => function($model) {
                return $model->bankAccountDetails;
            },
            'approve_status' => function($model) {
                if (($model->role == 'user' && ($model->status == 'active'||$model->status == 'banned') && $model->approved == 'yes' && $model->profile_completed == 'yes')) {
                    return 'yes';
                } else {
                    return 'no';
                }
            },
                    'rating_status' => function($model){
                $response = Notification::checkRatingRequest();
                if(!empty($response)){
                    return true;
                }
                return false;
            }
                ];
                unset($fields['password'], $fields['type'], $fields['verified_code'], $fields['auth_key'], $fields['created_at'], $fields['updated_at']);
                return ArrayHelper::merge(parent::fields(), $fields);
            }

            public function extraFields() {
                $fields = [
                    'is_favorite' => function($model) {
                        return Favorites::getStatus($model->user->id);
                    }
                ];
                return $fields;
            }

            public function emailExistanceValidation($attribute, $params) {

                if (!$this->hasErrors()) {
                    $user = self::getUserByAttr(['AND', ['=', 'email', $this->email], ['!=', 'id', \yii::$app->user->id]]);
                    $message = 'Email Already exist with another';
                    if ($user) {
                        $this->addError($attribute, $message);
                    }
                }
            }

            public static function getUserByAttr($attr) {
                return self::find()->where($attr)->one();
            }

            public static function getAllUserByAttr($attr) {
                return self::find()->where($attr)->all();
            }

            public static function sendContactUsMail($post) {
                $user = User::findByAttr(['id' => \yii::$app->user->id]);
                $admin = User::findByAttr(['role' => 'admin']);
                try {
                    $client = new ZendeskAPI(\Yii::$app->params['zendesk_subdomain']);
                    $client->setAuth('basic', ['username' => \Yii::$app->params['zendesk_username'], 'token' => \Yii::$app->params['zendesk_token']]);

                    $zendesk_user = $client->users()->createOrUpdate(['email' => $user->email, 'name' => $user->first_name . ' ' . $user->last_name, 'role' => 'end-user']);
                    $newTicket = $client->tickets()->create([
                        'requester_id' => $zendesk_user->user->id,
                        'submitter_id' => $zendesk_user->user->id,
                        'subject' => $post['subject'],
                        'comment' => ['body' => $post['message']],
                        'priority' => 'normal'
                    ]);
                    return true;
                } catch (\Exception $e) {
                    $model = new User();
                    $model->addError('misc', $e->getMessage());
                    return $model;
                }
            }

            /**
             * @return \yii\db\ActiveQuery
             */
            public function getAddressFavourites() {
                return $this->hasMany(AddressFavourite::className(), ['user_id' => 'id']);
            }

            /**
             * @return \yii\db\ActiveQuery
             */
            public function getAuths() {
                return $this->hasMany(Auth::className(), ['user_id' => 'id']);
            }

            /**
             * @return \yii\db\ActiveQuery
             */
            public function getBankAccountDetails() {
                return $this->hasMany(BankAccountDetail::className(), ['user_id' => 'id']);
            }

            /**
             * @return \yii\db\ActiveQuery
             */
            public function getCaseCancelleds() {
                return $this->hasMany(CaseCancelled::className(), ['user_id' => 'id']);
            }

            /**
             * @return \yii\db\ActiveQuery
             */
            public function getCaseRequests() {
                return $this->hasMany(CaseRequest::className(), ['cancelled_by' => 'id']);
            }

            /**
             * @return \yii\db\ActiveQuery
             */
            public function getCaseRequests0() {
                return $this->hasMany(CaseRequest::className(), ['from_id' => 'id']);
            }

            /**
             * @return \yii\db\ActiveQuery
             */
            public function getCaseRequests1() {
                return $this->hasMany(CaseRequest::className(), ['to_id' => 'id']);
            }

            /**
             * @return \yii\db\ActiveQuery
             */
            public function getFavorites() {
                return $this->hasMany(Favorites::className(), ['from_user_id' => 'id']);
            }

            /**
             * @return \yii\db\ActiveQuery
             */
            public function getFavorites0() {
                return $this->hasMany(Favorites::className(), ['to_user_id' => 'id']);
            }

            /**
             * @return \yii\db\ActiveQuery
             */
            public function getHearingDetails() {
                return $this->hasMany(HearingDetail::className(), ['user_id' => 'id']);
            }

            /**
             * @return \yii\db\ActiveQuery
             */
            public function getNotifications() {
                return $this->hasMany(Notification::className(), ['from_id' => 'id']);
            }

            /**
             * @return \yii\db\ActiveQuery
             */
            public function getNotifications0() {
                return $this->hasMany(Notification::className(), ['to_id' => 'id']);
            }

            /**
             * @return \yii\db\ActiveQuery
             */
            public function getReviews() {
                return $this->hasMany(Review::className(), ['from_user_id' => 'id']);
            }

            /**
             * @return \yii\db\ActiveQuery
             */
            public function getReviews0() {
                return $this->hasMany(Review::className(), ['to_user_id' => 'id']);
            }

            /**
             * @return \yii\db\ActiveQuery
             */
            public function getUserBankDetails() {
                return $this->hasMany(UserBankDetails::className(), ['user_id' => 'id']);
            }

            /**
             * @return \yii\db\ActiveQuery
             */
            public function getUserDevices() {
                return $this->hasMany(UserDevices::className(), ['user_id' => 'id']);
            }

            public static function updateUserDetail($data) {

                $send = 'no';
                $user_id = yii::$app->user->id;
                $user = User::findOne(['id' => $user_id]);
                if($user->profile_completed=='no'){
                    $send = 'yes';
                }
                $user->scenario = 'update';
                $user->load($data, '');

                $file = \yii\web\UploadedFile::getInstanceByName('profile_pic');
                if (!empty($file)) {
                    $user->profile_pic = \api\models\User::uploadImage($file);
                }

                if (!empty($user) && $user->validate()) {
                    $user->profile_completed = 'yes';
                    
                    if ($user->save(false)) {
                        if ($user->stripe_account_id == "") {
                            try {
                                $account = StripeGateway::createConnectAccount(['user_id' => $user->id]);
                                if ($account) {
                                    $user->stripe_account_id = $account->id;
                                    $user->save(false);
                                }
                            } catch (\Exception $e) {
                                $user->addError('misc', $e->getMessage());
                                return $user;
                            }
                        }
                        if ($send == 'yes') {
                            \Yii::$app->mailer->compose(['html' => 'user-pending-admin-html'], ['user' => $user])
                                    ->setFrom([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
                                    ->setTo(\Yii::$app->params['supportEmail'])
                                    ->setSubject('Courtpals : Attorney Status')
                                    ->send();
                        }
                        return \api\models\UserDevices::getUserDeviceByAttr(['user_id' => $user_id]);
                    }
                } else {
                    return $user;
                }
                return false;
            }

            public static function getUserProfile($loggedin_user) {
                $user_profile = User::findOne(['id' => $loggedin_user]);
                if (!empty($user_profile)) {
                    return $user_profile;
                }
            }

            public static function allAttornyList($post,$timezone="") {
             
                
                $array = [];
                $query = self::find()->where(['AND',['!=', 'status', 'deleted'],['!=', 'role', 'admin']]);
                if (!empty($post)) {
                    if (!empty($post['name'])) {
                        $query->andWhere(['like', 'concat(user.first_name," ",user.last_name)', $post['name']]);
                    }
                    if (!empty($post['email'])) {
                        $query->andWhere(['=', 'email', $post['email']]);
                    }
                    if (!empty($post['unique_id'])) {
                        $query->andWhere(['=', 'id', $post['unique_id']]);
                    }
                    if (!empty($post['type']) && $post['type'] == 'not_approved') {
                         $query->andWhere(['AND',['=','approved','no'],['=','profile_completed','yes']]);
                        $query->orderBy('updated_at DESC');
                    }
                    if (!empty($post['type']) && $post['type'] == 'not-verified') {
                        $query->andWhere(['AND',['=','profile_completed','no'],['=','approved','no']]);
                        $query->orderBy('updated_at DESC');
                    }
                    if (!empty($post['type']) && $post['type'] != '' && $post['type'] == 'not_banned') {
                        $query->andWhere(['AND',['=','approved','yes'],['=','profile_completed','yes']]);
                        $query->orderBy('updated_at DESC');
                    } 
                    elseif(!empty($post['status']) && $post['status'] == 'banned'){
                        $query->andWhere(['=', 'status', 'banned']);
                    }
                }
                $query->orderBy('created_at DESC');
                
                $provider = new ActiveDataProvider([
                    'query' => $query,
                    'pagination' => [
                        'pageSize' => 10,
                    ]
                ]);

//                echo "<pre>";
//                print_r($provider->getModels());die;
                foreach ($provider->getModels() as $attorney) {
                    $attorney['rating'] = Review::averageRatting($attorney->id);
                    $serverTimezone = \Yii::$app->getTimeZone();
                    $fromDate = new \DateTime($attorney->created_at, new \DateTimeZone($serverTimezone));
                    $fromDate->setTimeZone(new \DateTimeZone($timezone));
                    $today_date = $fromDate->format('Y-m-d H:i:s');
                    $attorney->created_at = $today_date;
                    $array[] = $attorney;
                }
                $provider->setModels($array);
                return $provider;
            }

            public static function activeInactiveAttorny($post) {
                $notified = false;
                $user = self::find()->where(['id' => $post['id']])->one();
                if (!empty($user)) {
                    if ($user->status == 'banned') {
                        $notified = true;
                    }
                    if($post['status'] == 'active' && $user->status == 'inactive'){
                        $user->verified_code = "";
                        \Yii::$app->mailer->compose(['html' => 'account-activation-html'], ['user' => $user])
                            ->setFrom([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
                            ->setTo($user->email)
                            ->setReplyTo([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
                            ->setSubject('Welcome to ' . \Yii::$app->name)
                            ->send();
                    }
                    $user->status = $post['status'];
                    
                    if ($user->save(false)) {
                        if ($notified) {
                            $user_data = User::userDataForNotification(Yii::$app->user->id);
                            $user_device_type = UserDevices::find()->where(['user_id'=>$user->id])->one();
                            $type = 'account_activate';
                            $message = "Admin has activated your Courtpals profile. Now you can continue to use the Application.";

                            $notification_data = ['title' => '',
                                'type' => $type,
                                'from_id' => Yii::$app->user->id,
                                'to_id' => $user->id,
                                'user_name' => $user_data['user_name'],
                                'profile_image' => $user_data['profile_image'],
                                'request_id' => "",
                                'request_description' => "",
                                'case_id' => "",
                                'case_date' => "",
                                'case_time' => "",
                                'notification_receive_status'=>$user->notification
                            ];

                            Notification::saveNotification(['to_id' => [$user->id], 'request_id' => "", 'from_id' => Yii::$app->user->id, 'type' => $type, 'message' => $message, 'notification_data' => json_encode($notification_data)]);
//                            if ($user->notification == 'enable') {
                             $notification_data['unread_notification_count'] = Notification::newNotification($user->id);
                            if($user->notification=='disable'){
                                 \api\components\Utility::sendWithoutAlertMessagePushNotification($user->id, $message, $notification_data);
                            }
                            if($user->notification=='enable'){
                                \api\components\Utility::sendMessagePushNotification($user->id, $message, $notification_data);
                            }

                        }
                        
                        
                        return $user->status;
                    }return false;
                }
            }

            public function validate_current_pasword($attribute, $param) {

                $user_id = yii::$app->user->identity->id;
                $userDetail = static::findOne(['id' => $user_id]);
                if (!Yii::$app->getSecurity()->validatePassword($this->password, $userDetail->password))
                    $this->addError($attribute, 'Current Password is Wrong!');
            }

            public static function userDataForNotification($user_id) {
                $data = [];
                $user = User::find()->where(['id' => $user_id])->one();
                $user_name = $user->first_name . ' ' . $user->last_name;
                $profileImage = \common\components\Utility::getUserImage($user->id);
                $data['user_name'] = $user_name;
                $data['image'] = $profileImage;
                $data['user_id'] = $user->id;
                $data['profile_image'] = $profileImage;
                $data['notification'] = $user['notification'];


                return $data;
            }

            /**
             * @inheritdoc
             */
            public static function findIdentity($id) {
                return static::findOne(['id' => $id, 'status' => self::STATUS_ACTIVE]);
            }

            /**
             * @inheritdoc
             */
            public static function findIdentityByAccessToken($token, $type = null) {
                $userDevice = \common\models\UserDevices::findOne(['access_token' => $token]);
                if (!empty($userDevice))
                    return \common\models\User::findOne(['id' => $userDevice->user_id]);
                else
                    return null;
            }

            /**
             * Finds user by password reset token
             *
             * @param string $token password reset token
             * @return static|null
             */
            public static function findByPasswordResetToken($token) {
//                if (!static::isPasswordResetTokenValid($token)) {
//                    return null;
//                }

                return static::findOne([
                            'verified_code' => $token,
                            'status' => self::STATUS_ACTIVE,
                ]);
            }
            
            public static function findByPasswordToken($token) {
                
                return static::findOne([
                            'password_reset_token' => $token,
                            'status' => self::STATUS_ACTIVE,
                ]);
            }
            
            /**
             * Finds user by email
             *
             * @param string $email
             * @return static|null
             */
            public static function findByEmail($email) {
                return static::findOne(['email' => $email]);
            }

            public static function findByAttr($attr) {
                return static::findOne($attr);
            }

            public static function getAdminId() {
                $adminId = [];
                $admin = 'admin';
                $admin_users = self::find()->where(['role' => $admin])->all();
                if (!empty($admin_users)) {
                    foreach ($admin_users as $admin) {
                        $adminId[] = $admin->id;
                    }
                    return $adminId;
                }
            }

            public static function updateLanguage($post) {
                $user_id = \yii::$app->user->id;
                $user = self::findByAttr(['id' => $user_id]);
                $user->language = $post['language'];
                if ($user->save(false)) {
                    return true;
                }return false;
            }

            /**
             * Finds out if password reset token is valid
             *
             * @param string $token password reset token
             * @return bool
             */
            public static function isPasswordResetTokenValid($token) {
                if (empty($token)) {
                    return false;
                }

                $timestamp = (int) substr($token, strrpos($token, '_') + 1);
                $expire = Yii::$app->params['user.passwordResetTokenExpire'];
                return $timestamp + $expire >= time();
            }

            public static function changePassword($model) {
                $admin = self::findByAttr(['role' => 'admin']);
                $admin->password = \Yii::$app->getSecurity()->generatePasswordHash($model->new_password);
                if ($admin->save(false)) {
                    return true;
                }return false;
            }

            /**
             * @inheritdoc
             */
            public function getId() {
                return $this->getPrimaryKey();
            }

            /**
             * @inheritdoc
             */
            public function getAuthKey() {
                return $this->auth_key;
            }

            /**
             * @inheritdoc
             */
            public function validateAuthKey($authKey) {
                return $this->getAuthKey() === $authKey;
            }

            /**
             * Validates password
             *
             * @param string $password password to validate
             * @return bool if password provided is valid for current user
             */
            public function validatePassword($password) {
                return Yii::$app->security->validatePassword($password, $this->password);
            }

            /**
             * Generates password hash from password and sets it to the model
             *
             * @param string $password
             */
            public function setPassword($password) {
                return Yii::$app->security->generatePasswordHash($password);
            }

            /**
             * Generates "remember me" authentication key
             */
            public function generateAuthKey() {
                $this->auth_key = Yii::$app->security->generateRandomString();
            }

            /**
             * Generates new password reset token
             */
            public function generatePasswordResetToken() {
                $this->password_reset_token = Yii::$app->security->generateRandomString() . '_' . time();
            }

            /**
             * Removes password reset token
             */
            public function removePasswordResetToken() {
                $this->password_reset_token = null;
            }

            /**
             * Generates new verify token
             */
            public function generateVerifyCode() {
                $this->verified_code = Yii::$app->security->generateRandomString() . '_' . time();
            }

            /**
             * Removes virified code
             */
            public function removeVerifiedCode() {
                $this->verified_code = null;
            }

//            public static function getAllUsers ($post)
//            {
//                $where = " role = '{$post['user_role']}' AND status = 'active' ";
//
//                if (!empty($post['searchText'])) {
//                    $where .= " AND (first_name LIKE '%" . $post['searchText'] . "%' OR last_name LIKE '%" . $post['searchText'] . "%') ";
//                }
//                $query = "SELECT id, first_name, last_name, email, user_name from `user` WHERE {$where} ORDER BY user_name ASC";
//
//                return \yii::$app->db->createCommand($query)->queryAll();
//            }

            public function changeAdminPassword($adminData) {

                $user_id = yii::$app->user->identity->id;
                $model = self::find()->where(['id' => $user_id])->one();

                $model->password = $this->setPassword($adminData['new_password']);
                $model->updated_at = date('Y-m-d H:s:i');
                if ($model->save(false)) {
                    return true;
                } else {
                    return false;
                }
            }

            public static function uploadDocument($file) {

                $filePath = '../../api/web/upload/document/';
                if (!is_dir($filePath)) {
                    mkdir($filePath, 0777, true);
                }
                $name = strtolower($file->baseName) . '.' . $file->extension;
                if ($file->saveAs($filePath . $name)) {
                    return $name;
                }
                return false;
            }

            public static function saveSettings($data) {
                $user = self::findByAttr(['id' => \Yii::$app->user->getId()]);
                if (!empty($user)) {
                    $user->notification = $data['notification'];
                    $user->is_available = $data['is_available'];
//                    if(!$user->is_available){
//                        HearingDetail::deleteAll(['user_id'=>  \yii::$app->user->id]);
//                    }
                    if (!empty($data['hearing_type_id'])) {

                        HearingDetail::deleteAll(['user_id' => \yii::$app->user->id]);
                        $hearing_ids = explode(',', $data['hearing_type_id']);

                        foreach ($hearing_ids as $id) {

                            $model = new HearingDetail();
                            $model->user_id = \yii::$app->user->id;
                            $model->hearing_type = $id;
                            $model->save(false);
                        }
                    }
                    if ($user->save(false)) {
                        return true;
                    }
                }
                return false;
            }

            public static function getList() {
                $query = User::find()->where(['id' => 239]);
                $provider = new ActiveDataProvider([
                    'query' => $query,
                    'pagination' => [
                        'pageSize' => 10,
                    ]
                ]);
                return $provider;
            }
            
            public static function verifyEmail($verified_code){
                $user = User::find()->where(['verified_code' =>$verified_code])->one();
                if(!empty($user)){
                    if($user->verified_code == ''){
                        return false;
                    }else{
                        $user->status = 'active';
                        $user->verified_code = null;
                        $user->save(false);
                        return true;
                    }
                }
            }
        }
        