<?php

namespace common\models;

use Yii;
use yii\data\ActiveDataProvider;
use yii\helpers\ArrayHelper;
use common\components\Utility;
use yii\web\UploadedFile;
use yii\imagine\Image;
use yii\data\SqlDataProvider;
use common\models\Notification;

/**
 * This is the model class for table "message".
 *
 * @property integer $id
 * @property string $case_id
 * @property string $sticker_id
 * @property integer $sender
 * @property integer $receiver
 * @property string $type
 * @property integer $receiver_read
 * @property integer $sender_delete
 * @property integer $receiver_delete
 * @property string $message
 * @property string $media
 * @property string $thumbnail
 * @property string $time_stamp
 * @property string $created_at
 * @property string $updated_at
 *
 * @property User $sender0
 * @property User $receiver0
 */
class Message extends \common\models\base\BaseMessage
{

    public $other_user;
    public $other_user_image;
    public $file_type;
    public $file_name;

    /**
     * @inheritdoc
     */
    public static function tableName ()
    {
        return 'message';
    }

    /**
     * @inheritdoc
     */
    public function rules ()
    {
        return [
            [['sender', 'receiver', 'receiver_read', 'sender_delete', 'receiver_delete'], 'integer'],
            [['message'], 'string'],
            [['created_at'], 'required'],
            [['created_at', 'updated_at'], 'safe'],
            [['case_id', 'sticker_id', 'type', 'media', 'thumbnail', 'time_stamp'], 'string', 'max' => 255],
            [['sender'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['sender' => 'id']],
            [['receiver'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['receiver' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels ()
    {
        return [
            'id' => 'ID',
            'case_id' => 'Case ID',
            'sticker_id' => 'Sticker ID',
            'sender' => 'Sender',
            'receiver' => 'Receiver',
            'type' => 'Type',
            'receiver_read' => 'Receiver Read',
            'sender_delete' => 'Sender Delete',
            'receiver_delete' => 'Receiver Delete',
            'message' => 'Message',
            'media' => 'Media',
            'thumbnail' => 'Thumbnail',
            'time_stamp' => 'Time Stamp',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    public function behaviors ()
    {
        return [
            'timestamp' => [
                'class' => \yii\behaviors\TimestampBehavior::className(),
                'createdAtAttribute' => 'created_at',
                'updatedAtAttribute' => 'updated_at',
                'value' => new \yii\db\Expression("'" . date('Y-m-d H:i:s') . "'"),
                'attributes' => [
                    \yii\db\ActiveRecord::EVENT_BEFORE_INSERT => ['created_at', 'updated_at'],
                    \yii\db\ActiveRecord::EVENT_BEFORE_UPDATE => ['updated_at'],
                ],
            ],
        ];
    }

    public function fields ()
    {
        $parentFields = parent::fields();
        $fields = [
        ];
        unset($parentFields['updated_at'], $parentFields['receiver_read'], $parentFields['sender_delete'], $parentFields['receiver_delete'], $parentFields['sticker_id']);
        return ArrayHelper::merge($parentFields, $fields);
    }

    public function extraFields ()
    {
        $fields = [
            'sender_name' => function($model) {
                return $model->sender0->first_name . ' ' . $model->sender0->last_name;
            },
            'sender_profile_image' => function($model) {
                return Utility::getUserImage($model->sender);
            },
            'receiver_name' => function($model) {
                if (!empty($model->receiver0))
                    return $model->receiver0->first_name . ' ' . $model->receiver0->last_name;
            },
            'receiver_profile_image' => function($model) {
                if (!empty($model->receiver0))
                    return Utility::getUserImage($model->receiver);
            },
            'other_user' => function($model) {
                if (\Yii::$app->user->getId() == $model->sender) {
                    return $model->receiver0->first_name . ' ' . $model->receiver0->last_name;
                } else {
                    return $model->sender0->first_name . ' ' . $model->sender0->last_name;
                }
            },
            'other_user_image' => function($model) {
                if (\Yii::$app->user->getId() == $model->sender) {
                    return Utility::getUserImage($model->receiver);
                } else {
                    return Utility::getUserImage($model->sender);
                }
            },
        ];
        return $fields;
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getSender0 ()
    {
        return $this->hasOne(User::className(), ['id' => 'sender']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getReceiver0 ()
    {
        return $this->hasOne(User::className(), ['id' => 'receiver']);
    }

    public static function getInbox ($param)
    {
        $data = [];
        $result = [];
        $user_id = \Yii::$app->user->getId();
        $query = "SELECT sender, receiver, case_id, message,created_at,type,media
                  FROM message m WHERE m.id = (SELECT MAX(id) FROM message WHERE case_id = m.case_id) 
                  AND ((m.sender = $user_id AND m.sender_delete=0)OR (m.receiver = $user_id AND m.receiver_delete=0))
                  GROUP BY m.case_id ORDER BY m.id DESC";
        $count_query = "SELECT COUNT(DISTINCT m.case_id) AS ct
                        FROM message m WHERE m.id = (SELECT MAX(id) FROM message WHERE case_id = m.case_id) 
                        AND ((m.sender = $user_id AND m.sender_delete=0)OR (m.receiver = $user_id AND m.receiver_delete=0))";
        $count = \yii::$app->db->createCommand($count_query)->queryScalar();

        $dataProvider = new SqlDataProvider([
            'sql' => $query,
            'totalCount' => $count,
            'pagination' => [
                'pageSize' => 10,
            ],
        ]);
        foreach ($dataProvider->getModels() as $value) {
            if ($value['sender'] == $user_id) {
                $user = User::find()->where(['id' => $value['receiver']])->one();
            } else {
                $user = User::find()->where(['id' => $value['sender']])->one();
            }
            $value['other_user'] = $user->first_name . ' ' . $user->last_name;
            $value['other_user_image'] = Utility::getUserImage($user->id);
            $value['unread_message_count'] = self::unreadMessageCount($value['case_id'], $user_id);
            $value['file_type'] = "";
            $value['file_name'] = "";
            if ($value['type'] == 'media') {
                $media = $value['media'];
                $split = explode('/', $media);
                $media_name = array_pop($split);
                $media_data = explode('.', $media_name);
                $value['file_type'] = $media_data[1];
                $value['file_name'] = $media_data[0];
            }
            if (isset($param['timezone']) && $param['timezone'] != '') {
                $serverTimezone = \Yii::$app->getTimeZone();
                $fromDate = new \DateTime($value['created_at'], new \DateTimeZone($serverTimezone));
                $fromDate->setTimeZone(new \DateTimeZone($param['timezone']));
                $value['created_at'] = $fromDate->format('Y-m-d H:i:s');
            }
            $result[] = $value;
        }
        $dataProvider->setModels($result);
        \Yii::$app->response->extraData = ['unread_thread_count' => self::unreadThreadCount($user_id), 'unread_notification_count' => Notification::newNotification($user_id)];
        return $dataProvider;
    }

    public static function getDetail ($param)
    {
        $data = [];
        $result = [];
        $user_id = \Yii::$app->user->getId();
        self::updateAll(['receiver_read' => 1], ['receiver' => $user_id, 'case_id' => $param['case_id']]);
        $query = "SELECT m.id, m.sender, m.receiver, m.case_id, m.type, m.time_stamp, m.media, m.message,m.created_at,s.profile_pic as sender_profile_image, CONCAT(s.first_name,' ',s.last_name) as sender_name, r.profile_pic as receiver_profile_image, CONCAT(r.first_name,' ',r.last_name) as receiver_name
                  FROM message m 
                  LEFT JOIN user s ON s.id = m.sender
                  LEFT JOIN user r ON r.id = m.receiver
                  WHERE case_id = '" . $param['case_id'] . "'
                  AND CASE WHEN m.receiver = $user_id THEN receiver_delete = 0 ELSE TRUE END 
                  AND CASE WHEN m.sender = $user_id THEN sender_delete = 0 ELSE TRUE END 
                  ORDER BY m.id DESC";

        $count_query = "SELECT COUNT(m.case_id) AS ct
                        FROM message m 
                        LEFT JOIN user s ON s.id = m.sender
                        LEFT JOIN user r ON r.id = m.receiver 
                        WHERE case_id = '" . $param['case_id'] . "'
                        AND CASE WHEN m.receiver = $user_id THEN receiver_delete = 0 ELSE TRUE END 
                        AND CASE WHEN m.sender = $user_id THEN sender_delete = 0 ELSE TRUE END ";
        $count = \yii::$app->db->createCommand($count_query)->queryScalar();

        $dataProvider = new SqlDataProvider([
            'sql' => $query,
            'totalCount' => $count,
            'pagination' => [
                'pageSize' => 10,
            ],
        ]);
        foreach ($dataProvider->getModels() as $value) {
            $user = User::find()->where(['id' => $value['receiver']])->one();
            if ($value['sender'] == $user_id) {
                $user = User::find()->where(['id' => $value['receiver']])->one();
            } else {
                $user = User::find()->where(['id' => $value['sender']])->one();
            }
            $value['sender_profile_image'] = Utility::getUserImage($value['sender']);
            $value['receiver_profile_image'] = Utility::getUserImage($value['receiver']);
            $value['other_user'] = $user->first_name . ' ' . $user->last_name;
            $value['other_user_image'] = Utility::getUserImage($user->id);
            if (isset($param['timezone']) && $param['timezone'] != '') {
                $serverTimezone = \Yii::$app->getTimeZone();
                $fromDate = new \DateTime($value['created_at'], new \DateTimeZone($serverTimezone));
                $fromDate->setTimeZone(new \DateTimeZone($param['timezone']));
                $value['created_at'] = $fromDate->format('Y-m-d H:i:s');
            }
            $result[] = $value;
        }
        $dataProvider->setModels(array_reverse($result));
        \yii::$app->response->extraData = [
            'unread_thread_count' => self::unreadThreadCount($user_id),
            'unread_notification_count' => Notification::newNotification($user_id),
        ];
        return $dataProvider;
    }

    public static function saveMultiMediaMessage ($data)
    {
        $file = UploadedFile::getInstanceByName('media');
        $return = [];

        if (!empty($file) && $file->size > 0 && $file->size / 1048576 < 11) {
            $imagename = self::uploadMedia($file, $data['type']);
            $return['media'] = \api\components\Utility::getUserMedia($imagename, $data['type']);
            $return['document'] = \api\components\Utility::getUserMedia($imagename, 'document');
            return $return;
        } else {
            return \api\components\Utility::apiError(201, 'Please try different image with smaller in size.');
        }
        return false;
    }

    public static function uploadMedia ($file, $type)
    {

        $filePath = './uploads/media/' . $type . '/';
        if (!is_dir($filePath)) {
            mkdir($filePath, 0777, true);
        }
        $name = strtolower(str_replace(' ', '_', $file->baseName)) . time() . '.' . $file->extension;

        $file->saveAs($filePath . $name);
        if ($type == 'image') {
            $thumbPath = './uploads/media/' . $type . '/thumb/';
            if (!is_dir($thumbPath)) {
                mkdir($thumbPath, 0777, true);
            }
            $response = Image::thumbnail($filePath . $name, 100, 100)->save($thumbPath . $name, ['quality' => 90]);
        }
        return $name;
    }

    public static function saveMessage ($data)
    {
        $model = new Message();
        $message_count = self::find()->where(['sender' => $data['sender'], 'receiver' => $data['receiver']])->count();
        $model->load($data, '');
        $response = [];
        if ($model->save(false)) {
            if (!$data['online']) {
                $user = User::find()->where(['id' => $model->sender])->one();
                if ($data['type'] == 'text') {
                    $message = $data['message'];
                } else {
                    $message = "Media attached";
                }
                $profileImage = \common\components\Utility::getUserImage($user->id);
                $receiver = User::find()->where(['id'=>$model->receiver])->one();
                $receiver_device_type = UserDevices::find()->where(['user_id'=>$model->receiver])->one();
                $message_type = $data['type'];
                $notification_data = ['type' => 'new_message',
                    'noti_type' => $message_type,
                    'message_id' => $model->id,
                    'media' => $data['media'],
                    'time_stamp' => $data['time_stamp'],
                    'to_user_id' => $model->receiver,
                    'from_user_id' => $model->sender,
                    'case_id' => $model->case_id,
                    'user_id' => $user->id,
                    'user_name' => $user->first_name . ' ' . $user->last_name,
                    'profile_image' => $profileImage,
                    'unread_message_count' => self::unreadMessageCount($model->case_id, $model->receiver),
                    'unread_thread_count' => self::unreadThreadCount($model->receiver),
                    'unread_notification_count' => Notification::newNotification($model->receiver),
                    'notification_receive_status'=>$receiver->notification
                ];
                if($receiver->notification=='disable'){
                    \api\components\Utility::sendWithoutAlertMessagePushNotification($model->receiver, $message, $notification_data);
                }
                \api\components\Utility::sendMessagePushNotification($model->receiver, $message, $notification_data);
            }
            $response['unread_message_count'] = self::unreadMessageCount($model->case_id, $model->receiver);
            $response['unread_thread_count'] = self::unreadThreadCount($model->receiver);
            $response['message_id'] = $model->id;
            return $response;
        }
        return false;
    }

    public static function readMessage ($data)
    {
        $userId = \Yii::$app->user->id;
        $message = self::find()->where(['id' => $data['message_id']])->one();
        $message->receiver_read = $data['receiver_read'];
        if ($message->save(false)) {
            return true;
        }
        return false;
    }

    public static function unreadThreadCount ($user_id)
    {
        return Message::find()->select('case_id')->where(['receiver_read' => 0, 'receiver_delete' => 0, 'receiver' => $user_id])->distinct()->count();
    }

    public static function unreadMessageCount ($case_id, $reciever_id)
    {
        return self::find()->where(['receiver_read' => 0, 'case_id' => $case_id, 'receiver' => $reciever_id, 'receiver_delete' => 0])->count();
    }

    public static function getAllChat ($post = "")
    {
        $array = [];
        if (!empty($post['searchvalue'])) {
            $chats = self::find()->where(['like', 'case_id', $post['searchvalue']])->orderBy('id DESC')->groupBy('case_id')->all();
        } else {
            $chats = self::find()->orderBy('id DESC')->groupBy('case_id')->all();
        }
        foreach ($chats as $chat) {
            if ($post['time_zone']) {
                $serverTimezone = \Yii::$app->getTimeZone();
                $fromDate = new \DateTime($chat->created_at, new \DateTimeZone($serverTimezone));
                $fromDate->setTimeZone(new \DateTimeZone($post['time_zone']));
                $today_date = $fromDate->format('Y-m-d H:i:s');
                $chat->created_at = $today_date;
            }
            $array[] = $chat;
        }
        return $array;
    }

    public static function getAllChatOfCase ($post)
    {
        $array = [];
        $allchats = Message::find()->where(['case_id' => $post['case_id']])->all();
        if (!empty($allchats)) {
            foreach ($allchats as $chat) {
                if ($post['time_zone']) {
                    $serverTimezone = \Yii::$app->getTimeZone();
                    $fromDate = new \DateTime($chat->created_at, new \DateTimeZone($serverTimezone));
                    $fromDate->setTimeZone(new \DateTimeZone($post['time_zone']));
                    $today_date = $fromDate->format('Y-m-d H:i:s');
                    $chat->created_at = $today_date;
                }
                $array[] = $chat;
            }
            return $array;
        }
    }

    public static function deleteMessage ($post)
    {
        $login_user = \yii::$app->user->id;
        $message = Message::find()->where(['id' => $post['message_id']])->one();
        if (!empty($message)) {
            if ($message->sender == $login_user) {
                $message->sender_delete = 1;
            } else {
                $message->receiver_delete = 1;
            }
            $message->save(false);
            return true;
        }return false;
    }

    public static function deleteAlleMessage ($post="")
    {
       
        $login_user = \yii::$app->user->id;
        if(!empty($post['case_id'])){
        $messages = Message::find()->where(['AND',['OR',['sender' => $login_user],['receiver'=>$login_user]],['case_id'=>$post['case_id']]])->all();
        }else{
         $messages = Message::find()->where(['OR',['sender' => $login_user],['receiver'=>$login_user]])->all();
        }
        if (!empty($messages)) {
             foreach ($messages as $value) {
                if ($value->sender == $login_user) {
                    $value->sender_delete = 1;
                } elseif ($value->receiver == $login_user) {
                    $value->receiver_delete = 1;
                }
                $value->save(false);
            }
            return true;
        }return false;
    }
   

}
