<?php

namespace common\models;

use Yii;
use yii\helpers\ArrayHelper;

/**
 * This is the model class for table "bank_account_detail".
 *
 * @property integer $id
 * @property integer $user_id
 * @property string $account_name
 * @property string $bank_name
 * @property integer $ach_bank_aba_number
 * @property integer $account_number
 * @property string $customer_address
 * @property string $status
 * @property string $created_at
 * @property string $updated_at
 *
 * @property User $user
 */
class BankAccountDetail extends base\BaseBankAccountDetail
{

    /**
     * @inheritdoc
     */
    public static function tableName ()
    {
        return 'bank_account_detail';
    }

    /**
     * @inheritdoc
     */
    public function rules ()
    {
        return [
            [['user_id', 'ach_bank_aba_number', 'account_number'], 'integer'],
            [['status'], 'string'],
            [['created_at', 'updated_at','stripe_bank_account_id'], 'safe'],
            [['bank_name'], 'string', 'max' => 255],
            [['user_id'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['user_id' => 'id']],
        ];
    }

    public function behaviors ()
    {
        return [
            'timestamp' => [
                'class' => \yii\behaviors\TimestampBehavior::className(),
                'createdAtAttribute' => 'created_at',
                'updatedAtAttribute' => 'updated_at',
                'value' => new \yii\db\Expression("'" . date('Y-m-d H:i:s') . "'"),
                'attributes' => [
                    \yii\db\ActiveRecord::EVENT_BEFORE_INSERT => ['created_at', 'updated_at'],
                    \yii\db\ActiveRecord::EVENT_BEFORE_UPDATE => ['updated_at'],
                ],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels ()
    {
        return [
            'id' => 'ID',
            'user_id' => 'User ID',
            'account_name' => 'Account Name',
            'bank_name' => 'Bank Name',
            'ach_bank_aba_number' => 'Ach Bank Aba Number',
            'account_number' => 'Account Number',
            'customer_address' => 'Customer Address',
            'status' => 'Status',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }
    
    public function fields ()
    {
        $parentFields = parent::fields();
        $fields = [
            
        ];
        unset($parentFields['created_at'], $parentFields['updated_at']);
        return ArrayHelper::merge($parentFields, $fields);
    }
    
    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUser ()
    {
        return $this->hasOne(User::className(), ['id' => 'user_id']);
    }
    
    public static function addBankDetail ($data)
    {
        $model = new BankAccountDetail();
        $user = User::find()->where(['id' =>  \Yii::$app->user->id])->one();
        $data['account_name'] = $user->first_name .' '. $user->last_name;
        try{
            $stripeAccount = StripeGateway::addBankAccount($data);
            $model->load($data, '');
            $model->user_id = \yii::$app->user->id;
            if(isset($stripeAccount->id)){
                $model->stripe_bank_account_id = $stripeAccount->id;
            }else{
              return   \api\components\Utility::apiError(201, $stripeAccount);
            }
            if ($model->save(false)) {
                return $model;
            }
        }  catch (\Exception $e){
            $model->addError('misc',$e->getMessage());
            return $model;
        }
        
        return false;
    }
    
    public static function editBankDetail ($data)
    {
        $user_id = \Yii::$app->user->id;
        $bank_dtail = BankAccountDetail::find()->where(['user_id' => $user_id])->one();
        
        if (!empty($bank_dtail)) {
            try{
                $stripeAccount = StripeGateway::editBankAccount($bank_dtail);
                $bank_dtail->load($data, '');
                if ($bank_dtail->save(false)) {
                    return $bank_dtail;
                }
            }catch (\Exception $e){
                $model->addError('misc',$e->getMessage());
                return $model;
            }
        }
        
        return false;
    }
    public static function deleteBankDetail($bank_detail_id){
        
            $bank_account = BankAccountDetail::find()->where(['id'=>$bank_detail_id])->one();
            if(!empty($bank_account)){
                try{
                    $response = StripeGateway::deleteBankAccount($bank_account->stripe_bank_account_id);
                    if(!empty($bank_account) && $response->deleted){
                        $bank_account->delete();
                        return true;
                    }
                }catch (\Exception $e){
                    $bank_account->addError('misc',$e->getMessage());
                    return $bank_account;
                }
            }
        return false;
    }

}
