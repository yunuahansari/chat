<?php
namespace common\models;

use Yii;
use yii\base\Model;

/**
 * Login form
 */
class LoginForm extends Model
{
    public $email;
    public $password;
    public $rememberMe = true;
    public $role;
    private $_user;


    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            // username and password are both required
            [['email','password'], 'required','message' => '{attribute} is required.'],
            [['email'], 'email', 'message' => 'Enter valid email'],
            // rememberMe must be a boolean value
            ['rememberMe', 'boolean'],
            // password is validated by validatePassword()
            ['password', 'validatePassword'],
            [['email', 'password', 'rememberMe', 'role'], 'safe'],
        ];
    }
    
     /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'email' => 'Email',
            'password' => 'Password',
            'rememberMe' => Yii::t('app','rememberMe')
        ];
    }
    
    /**
     * Validates the password.
     * This method serves as the inline validation for password.
     *
     * @param string $attribute the attribute currently being validated
     * @param array $params the additional name-value pairs given in the rule
     */
    public function validatePassword($attribute, $params)
    {
      
        if (!$this->hasErrors()) {
            $user = $this->getUser();
            $message = 'Email or password is incorrect';
           
            if (!$user || $user->password=="" || !$user->validatePassword($this->password)) {
                $this->addError($attribute, $message);
            }
            if(isset($this->role)){
                if($user && $user->role != 'admin'){
                    $this->addError($attribute, $message);
                }
            }
            if(!$user || ($user->role == 'user' && $user->status == 'inactive')){
                $this->addError($attribute, 'Please verify your email to continue.');
            }
//            if(!$user || ($user->role == 'user' && $user->status == 'active' && $user->approved == 'no' && $user->profile_completed == 'yes')){
//                $this->addError($attribute, 'Your account is under review.');
//            }
        }
    }

    /**
     * Logs in a user using the provided username and password.
     *
     * @return bool whether the user is logged in successfully
     */
    public function login()
    {
        if ($this->validate()) {
            return Yii::$app->user->login($this->getUser(), $this->rememberMe ? 3600 * 24 * 30 : 0);
        } else {
            return false;
        }
    }

    /**
     * Finds user by [[username]]
     *
     * @return User|null
     */
    public function getUser()
    {
       
        if ($this->_user === null) {
            $this->_user = User::findByEmail($this->email);
        }
        return $this->_user;
    }
    
    public function linkedInLogin()
    {
        return Yii::$app->user->login($this->getUser(), $this->rememberMe ? 3600 * 24 * 30 : 3600 * 24 * 365);
    }
}
