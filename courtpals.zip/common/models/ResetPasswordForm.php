<?php

namespace common\models;

use yii\base\Model;
use yii\base\InvalidParamException;
use common\models\User;

/**
 * Password reset form
 */
class ResetPasswordForm extends Model
{

    public $password;
    public $email;
    public $confirm_password;

    /**
     * @var \common\models\User
     */
    private $_user;

    /**
     * Creates a form model given a token.
     *
     * @param string $token
     * @param array $config name-value pairs that will be used to initialize the object properties
     * @throws \yii\base\InvalidParamException if token is empty or not valid
     */
    public function __construct ($token, $config = [])
    {
        if (empty($token) || !is_string($token)) {
            throw new InvalidParamException('Password reset token cannot be blank.');
        }
        $this->_user = User::findByPasswordResetToken($token);
        
        if (!$this->_user) {
            throw new InvalidParamException('Wrong password reset token.');
        }
        parent::__construct($config);
    }

    /**
     * @inheritdoc
     */
    public function rules ()
    {
        return [
            ['email', 'required'],
            ['password', 'string', 'min' => 6],
            [['password', 'confirm_password'], 'required', 'on' => 'resetPassword'],
            [['confirm_password'], 'compare', 'compareAttribute' => 'password', 'operator' => '==', 'message' => 'Confirm password must be same.', 'on' => 'resetPassword'],
            ['email', 'exist',
                'targetClass' => '\common\models\User',
                'message' => 'There is no user with such email.','on'=>'forgot'
            ],
        ];
    }

    /**
     * Resets password.
     *
     * @return bool if password was reset.
     */
    public function resetPassword ()
    {
        $user = $this->_user;
        $user->password = $user->setPassword($this->password);
        $user->removeVerifiedCode();
        return $user->save(false);
    }

    public function sendEmail ()
    {
        
       $user = \common\models\User::findByAttr(['email'=>$this->email,'role'=>'admin']);
            if(!empty($user)){
                $user->verified_code = \common\components\Utility::generateVerificationCode();
                $user->save(false);
                try{
                    \Yii::$app->mailer->compose(['html' => 'forgotPasswordLink-html'], ['user' => $user])
                        ->setFrom([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
                        ->setTo($this->email)
                        ->setSubject('Password reset for ' . \Yii::$app->name)
                        ->send();
                }catch (\Exception $e){
        
                }
             return true;
             
            }
            return false;
    }

}
