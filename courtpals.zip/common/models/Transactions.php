<?php

namespace common\models;

use Yii;
use yii\data\ActiveDataProvider;
use yii\helpers\ArrayHelper;
use api\components\Utility;

/**
 * This is the model class for table "transactions".
 *
 * @property integer $id
 * @property string $transaction_id
 * @property integer $request_id
 * @property integer $to_user_id
 * @property string $amount
 * @property string $status
 * @property string $card_last_four
 * @property string $card_exp_month
 * @property string $card_exp_year
 * @property string $brand
 * @property string $card_holder_name
 * @property string $created_at
 * @property string $updated_at
 *
 * @property User $toUser
 * @property CaseRequest $request
 * @property User $fromUser
 */
class Transactions extends \common\models\base\BaseTransactions
{

    public $total_sent;
    public $first_name;
    public $last_name;
    public $email;
    public $bar_number;
    public $ssn_number;
    public $mobile;
    public $case_id;
    public $case_status;
    public $paid_to_attorney;
    public $admin_earning;
    public $sender_name;
    public $amount_paid;
    public $case_date;
    public $case_time;
    public $dob;



    /**
     * @inheritdoc
     */
    public static function tableName ()
    {
        return 'transactions';
    }

    /**
     * @inheritdoc
     */
    public function rules ()
    {
        return [
            [['request_id', 'user_id'], 'integer'],
            [['amount'], 'number'],
            [['status'], 'string'],
            [['created_at', 'updated_at','commition'], 'safe'],
            [['transaction_id', 'card_last_four', 'card_exp_month', 'card_exp_year', 'brand', 'card_holder_name'], 'string', 'max' => 255],
            [['user_id'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['user_id' => 'id']],
            [['request_id'], 'exist', 'skipOnError' => true, 'targetClass' => CaseRequest::className(), 'targetAttribute' => ['request_id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels ()
    {
        return [
            'id' => 'ID',
            'transaction_id' => 'Transaction ID',
            'request_id' => 'Request ID',
            'user_id' => 'User ID',
            'amount' => 'Amount',
            'status' => 'Status',
            'card_last_four' => 'Card Last Four',
            'card_exp_month' => 'Card Exp Month',
            'card_exp_year' => 'Card Exp Year',
            'brand' => 'Brand',
            'card_holder_name' => 'Card Holder Name',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    public function behaviors ()
    {
        return [
            'timestamp' => [
                'class' => \yii\behaviors\TimestampBehavior::className(),
                'createdAtAttribute' => 'created_at',
                'updatedAtAttribute' => 'updated_at',
                'value' => new \yii\db\Expression("'" . date('Y-m-d H:i:s') . "'"),
                'attributes' => [
                    \yii\db\ActiveRecord::EVENT_BEFORE_INSERT => ['created_at', 'updated_at'],
                    \yii\db\ActiveRecord::EVENT_BEFORE_UPDATE => ['updated_at'],
                ],
            ],
        ];
    }

    public function fields ()
    {
        $parentFields = parent::fields();
        $fields = [
            'from_user' => function($model) {
                return $model->fromUser->first_name . ' ' . $model->fromUser->last_name;
            },
            'to_user' => function($model) {
                return $model->toUser->first_name . ' ' . $model->toUser->last_name;
            },
            'request_detail' => function($model) {
                return $model->request;
            },
            'created_at' => function($model) {
                $timezone = (!empty(\Yii::$app->request->get('timezone'))) ? \Yii::$app->request->get('timezone') : \Yii::$app->getTimeZone();
                return Utility::getDateByTimezone($timezone, $model->created_at, 'Y-m-d H:i');
            }
        ];
        unset($parentFields['updated_at']);
        return ArrayHelper::merge($parentFields, $fields);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getToUser ()
    {
        return $this->hasOne(User::className(), ['id' => 'to_user_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getRequest ()
    {
        return $this->hasOne(CaseRequest::className(), ['id' => 'request_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getFromUser ()
    {
        return $this->hasOne(User::className(), ['id' => 'from_user_id']);
    }

    public static function addTransaction ($data)
    {
        $users = [];
        try {
            $transactionModel = new Transactions();
            $charge = StripeGateway::chargeCustomer($data);
            $admin = User::find()->where(['role' => 'admin'])->one();
            $Client = User::find()->where(['id' => \yii::$app->user->id])->one();
            if (isset($charge->id)) {
                $transactionModel->amount = $charge->amount / 100;
                $transactionModel->request_id = $data['request_id'];
                $transactionModel->from_user_id = \Yii::$app->user->getId();
                $transactionModel->to_user_id = $admin->id;
                $transactionModel->status = ($charge->status == "succeeded") ? 'success' : "failed";
                $transactionModel->transaction_id = $charge->id;
                $transactionModel->card_last_four = $charge->source->last4;
                $transactionModel->card_exp_month = $charge->source->exp_month;
                $transactionModel->card_exp_year = $charge->source->exp_year;
                $transactionModel->brand = $charge->source->brand;
                $transactionModel->card_holder_name = $charge->source->name;
                $transactionModel->commition = $Client->commition;
                if ($transactionModel->save(false)) {
                    $requestModel = CaseRequest::find()->where(['id' => $transactionModel->request_id])->one();
                    $requestModel->status = 'active';
                    if ($requestModel->save(false)) {
                        
//                        \Yii::$app->mailer->compose(['html' => 'case-placed-client'], ['request' => $requestModel])
//                        ->setFrom([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
//                        ->setTo($requestModel->from->email)
//                        ->setSubject('Case placed ' . \Yii::$app->name)
//                        ->send();
                        
                        $user_data = User::userDataForNotification(\yii::$app->user->id);
                        $hearingType = HearingType::find()->where(['id' => $requestModel->hearing_type_id])->one();
                        $title = $hearingType->name . ' Case Request';

                        $to_users = User::find()->select('user.id,user.notification')->join('left join', 'hearing_detail', 'user.id=hearing_detail.user_id')
                                        ->where(['AND', ['hearing_detail.hearing_type' => $requestModel->hearing_type_id], ['!=', 'user.id', $requestModel->from_id], ['user.status' => 'active'], ['user.is_available' => 1]])->all();

                        $type = 'new_case_request';
                        $message = 'You have received new ' . $title . ' on '. date('jS F Y',strtotime($requestModel->case_date));
                        
                        $notification_data = ['title' => $title, 'type' => $type, 'from_id' => $requestModel->to_id, 'to_id' => $requestModel->from_id, 'user_name' => $user_data['user_name'],
                            'profile_image' => $user_data['profile_image'], 'request_id' => $requestModel->id];
                        if (!empty($to_users)) {
                            foreach ($to_users as $user) {
                                    Notification::saveNotification(['to_id' => [$user['id']], 'from_id' => \yii::$app->user->id, 'type' => $type, 'message' => $message,
                                        'request_id' => $requestModel->id, 'notification_data' => json_encode($notification_data)]);
                                 $notification_data['unread_notification_count'] = Notification::newNotification($user['id']);
                                 $notification_data['notification_receive_status'] = $user['notification'];
                                if ($user['notification'] == 'disable') {
                                    \api\components\Utility::sendWithoutAlertMessagePushNotification($user['id'], $message, $notification_data);
                                }
                                if ($user['notification'] == 'enable') {
                                    \api\components\Utility::sendMultiPushNotification($user['id'], $message, $notification_data);
                                }
                            }
                            
                        }
                       return true; 
                    }
                }
                
            }
            return false;
        } catch (\Exception $ex) {
            $transaction = new Transactions();
            $transaction->addError('misc', $ex->getMessage());
            return $transaction;
        }
    }
    
    public static function addTransfer($data)
    {
        try{
            $request = CaseRequest::find()->where(['id' => $data['request_id'], 'status' => 'completed'])->one();
            if(!empty($data['admin_id'])){
                $fromUser = $data['admin_id'];
            }else{
                $fromUser =  \Yii::$app->user->getId();
            }
                if(!empty($request)){
                    $transaction = new Transactions();
                    
                    $param = array(
                                    'amount' => $data['paid_to_attorney'],
                                    'account_id' => $request->to->stripe_account_id
                                   );

                    $response = StripeGateway::transferToPeerAttorney($param);

                    if(!empty($response)){
                        $transaction->amount = $response->amount/100;
                        $transaction->request_id = $data['request_id'];
                        $transaction->from_user_id = $fromUser;
                        $transaction->to_user_id = $request->to_id;
                        $transaction->status = ($response->status == "paid") ? 'success' : "failed";
                        $transaction->transaction_id = $response->id;
                        $transaction->commition = $request->from->commition;
                        if($transaction->save(false)){
                            
                            $user_data = User::userDataForNotification(\yii::$app->user->id);
                            $to_user = User::find()->select('user.id,user.notification')->where(['AND', ['=', 'user.id', $request->to_id], ['user.status' => 'active'], ['user.is_available' => 1]])->one();
                            $type = 'confirm_payment';
                            
                            $message = 'Your payment of $'.$transaction->amount.' has been initiated for case ID '.$request->case_id.'  and it will reflect in your bank account within 2-4 working days';
                            $notification_data = ['type' => $type, 'from_id' => \yii::$app->user->id, 'to_id' => $request->to_id, 'user_name' => $user_data['user_name'],
                                        'profile_image' => $user_data['profile_image'], 'request_id' => $request->id];
                            $notification_data['notification_receive_status'] = $to_user->notification;
                            Notification::saveNotification(['to_id' => [$to_user->id], 'from_id' => \yii::$app->user->id, 'type' => $type, 'message' => $message, 'request_id' => $request->id, 'notification_data' => json_encode($notification_data)]);
                            $notification = Notification::find()->where(['request_id'=>$request->id,'type'=>'confirm_payment'])->one();
                            $notification_data['notification_id'] = $notification->id;
                                   if ($to_user->notification == 'disable') {
                                                $notification_data['unread_notification_count'] = Notification::newNotification($to_user->id);
                                                \api\components\Utility::sendWithoutAlertMessagePushNotification($to_user->id, $message, $notification_data);
                                   }
                                   if ($to_user->notification == 'enable') {
                                                $notification_data['unread_notification_count'] = Notification::newNotification($to_user->id);
                                                \api\components\Utility::sendMessagePushNotification($to_user->id, $message, $notification_data);
                                   }
                            $request->paid_to_attorney = 'yes';
                            $request->save(false);
                        }
                    }
                    return true;
                }
            return false;
        }catch (\DoctrineTest\InstantiatorTest\Exception $ex){
            $transaction = new Transactions();
            $transaction->addError('misc', $ex->getMessage());
            return $transaction;                    
        }
        return false;
    }

    public static function getTransactions ($data)
    {

        if ($data['type'] == 'sent') {
            $transaction = self::find()->where(['from_user_id' => Yii::$app->user->id])->orderBy('id DESC');
        } else {
            $transaction = self::find()->where(['to_user_id' => Yii::$app->user->id])->orderBy('id DESC');
        }
        $provider = new ActiveDataProvider([
            'query' => $transaction,
            'pagination' => [
                'pageSize' => 10,
            ]
        ]);
        return $provider;
    }

    public static function getTransactionTotals ()
    {
        $return = [];
        $sent = self::find()->where(['from_user_id' => \Yii::$app->user->getId()])->sum('amount');
        $received = self::find()->where(['to_user_id' => \Yii::$app->user->getId()])->sum('amount');
        $return['sent'] = (!empty($sent)) ? $sent : "0";
        $return['received'] = (!empty($received)) ? $received : "0";
        return $return;
    }

    public static function totalPaymentReceived ()
    {
        $admin_id = \yii::$app->user->id;
        $sum = Transactions::find()->where(['!=', 'from_user_id', $admin_id])->sum('amount');
        if (!empty($sum)) {
            return $sum;
        } return 0;
    }

    public static function totalPaymentSent ()
    {
        $admin_id = \yii::$app->user->id;
        $sum = Transactions::find()->where(['=', 'from_user_id', $admin_id])->sum('amount');
        if (!empty($sum)) {
            return $sum;
        } return 0;
    }

    public static function getReceivedPayment ($post)
    {
        
        $array=[];
        $transaction = self::find()->select('transactions.from_user_id,cr.created_at as case_date,cr.id as request_id, cr.case_date,cr.case_time, cr.case_id as case_id,cr.status as case_status, cr.paid_to_attorney, transactions.amount,'
                                            . 'transactions.created_at,transactions.commition,u.first_name,u.last_name,u.email')
                                   ->join('left join', 'user as u', 'transactions.from_user_id=u.id')
                                   ->join('left join', 'case_request as cr', 'transactions.request_id=cr.id')->orderBy('transactions.id DESC');
        if (!empty($post)) {
            if (!empty($post['receiver'])) {
                $transaction->andWhere(['like', 'concat(u.first_name," ",u.last_name)', $post['receiver']]);
            }
            if (!empty($post['case_id'])) {
                $transaction->andWhere(['cr.case_id' => $post['case_id']]);
            }
            $transaction->andWhere(['transactions.to_user_id' => Yii::$app->user->id]);
        } else {
            $transaction->where(['transactions.to_user_id' => Yii::$app->user->id]);
        }

        $provider = new ActiveDataProvider([
            'query' => $transaction,
            'pagination' => [
                'pageSize' => 10,
            ]
        ]);

       foreach ($provider->getModels() as $pay){
             $serverTimezone = \Yii::$app->getTimeZone();
                    $fromDate = new \DateTime($pay->created_at, new \DateTimeZone($serverTimezone));
                    $fromDate->setTimeZone(new \DateTimeZone($post['timezone']));
                    $pay->created_at = $fromDate->format('Y-m-d H:i:s');
                    $deducted_amount = self::calculateCommitionedAmount($pay->commition, $pay->amount);
                    $pay->admin_earning = ($pay->amount-$deducted_amount);
                $array[]=$pay;
        }
        $provider->setModels($array);
        return $provider;
    }

    public static function getSentPayment ($post)
    {
     
       $array = [];
          $transaction = self::find()->select('transactions.from_user_id,transactions.commition,case_request.id,case_request.case_id,case_request.case_date,case_request.case_time,case_request.status as case_status,'
                        . 'transactions.amount,transactions.created_at,u.first_name,u.last_name,u.email')
                ->join('left join', 'user as u', 'transactions.to_user_id = u.id')
//                ->join('left join', 'user as su', 'transactions.from_user_id = su.id')
                ->join('left join', 'case_request', 'transactions.request_id=case_request.id')->orderBy('transactions.id DESC');
        if (!empty($post)) {
            if (!empty($post['sender'])) {
                $transaction->andWhere(['like', 'concat(u.first_name," ",u.last_name)', $post['sender']]);
            }
            if (!empty($post['case_id'])) {
                $transaction->andWhere(['case_request.case_id' => $post['case_id']]);
            }
            $transaction->andWhere(['transactions.from_user_id' => Yii::$app->user->id]);
        } else {
            $transaction->where(['transactions.from_user_id' => Yii::$app->user->id]);
        }
        $provider = new ActiveDataProvider([
            'query' => $transaction,
            'pagination' => [
                'pageSize' => 10,
            ]
        ]);
        foreach ($provider->getModels() as $pay){
                    $request = CaseRequest::find()->where(['id' => $pay->id])->one();
                    $serverTimezone = \Yii::$app->getTimeZone();
                    $fromDate = new \DateTime($pay->created_at, new \DateTimeZone($serverTimezone));
                    $fromDate->setTimeZone(new \DateTimeZone($post['timezone']));
                    $pay->created_at = $fromDate->format('Y-m-d H:i:s');
                    $pay->amount_paid = $pay->amount;
                    $pay->amount = $request->transactions->amount;
                    $pay->admin_earning = ($pay->commition*$request->transactions->amount)/100;
                    
                $array[]=$pay;
        }
        $provider->setModels($array);
        return $provider;
    }

    public static function getReceiverUserDetail ($receiver_id,$timezone)
    {
        $response=[] ;
        $receiver_detail = self::find()->select('case_request.case_id,transactions.request_id,transactions.amount,transactions.commition,transactions.created_at,user.bar_number,user.ssn_number,user.first_name,user.last_name,user.email,user.mobile')
                        ->join('left join', 'case_request', 'transactions.request_id = case_request.id')
                        ->join('left join', 'user', 'user.id=transactions.from_user_id')->where(['transactions.to_user_id' => Yii::$app->user->id,'case_request.id' => $receiver_id])->one();
        if (!empty($receiver_detail)) {
                    $request = CaseRequest::find()->where(['id' => $receiver_detail->request_id])->one();
                    $serverTimezone = \Yii::$app->getTimeZone();
                    $fromDate = new \DateTime($receiver_detail->created_at, new \DateTimeZone($serverTimezone));
                    $fromDate->setTimeZone(new \DateTimeZone($timezone));
                    $receiver_detail->created_at = $fromDate->format('Y-m-d h:i:s A');
                    //$deducted_amount = self::calculateCommitionedAmount($receiver_detail->commition, $receiver_detail->amount);
                    //$receiver_detail->admin_earning = ($receiver_detail->amount-$deducted_amount);
                    $receiver_detail->admin_earning = ($receiver_detail->commition*$request->transactions->amount)/100;
                    $response=$receiver_detail;
            return $response;
        }return false;
    }

    public static function getSenderUserDetail ($case_id,$timezone)
    {
        $response=[] ;
        $sender_detail = self::find()->select('case_request.case_id,case_request.status as case_status, transactions.request_id, transactions.amount,transactions.commition,transactions.created_at,user.bar_number,user.ssn_number,user.first_name,user.last_name,user.email,user.mobile')
                                ->join('left join', 'case_request', 'transactions.request_id = case_request.id')
                                ->join('left join', 'user', 'user.id=transactions.to_user_id')->where(['transactions.request_id' => $case_id,'transactions.from_user_id' => Yii::$app->user->id])->one();
        if (!empty($sender_detail)) {
                    $request = CaseRequest::find()->where(['id' => $sender_detail->request_id])->one();
                    $serverTimezone = \Yii::$app->getTimeZone();
                    $fromDate = new \DateTime($sender_detail->created_at, new \DateTimeZone($serverTimezone));
                    $fromDate->setTimeZone(new \DateTimeZone($timezone));
                    $sender_detail->created_at = $fromDate->format('Y-m-d h:i:s A');
                    //$deducted_amount = self::calculateCommitionedAmount($sender_detail->commition, $sender_detail->amount);
                    //$sender_detail->admin_earning = ($sender_detail->amount-$deducted_amount);
                    
                    if($sender_detail->amount == $request->transactions->amount && $sender_detail->case_status == 'cancelled'){
                        $adminEarning = "0.00";
                    }else{
                        $adminEarning = ($sender_detail->commition*$request->transactions->amount)/100;
                    }
                    $sender_detail->admin_earning = $adminEarning;
                    $response=$sender_detail;
            return $response;
        }return false;
    }
  
    public static function calculateCommitionedAmount($commition,$amount)
    {
        $netAmount = ($amount - ($amount * $commition)/100);
        return $netAmount;
    }
    
    public static function getPeerAttorneyPaymentData($requestId)
    {
        return CaseRequest::find()->select('t.amount, t.commition, t.request_id, pays_to.id, pays_to.first_name, pays_to.last_name, pays_to.stripe_account_id')
                           ->join('left join', 'transactions t', 't.request_id = case_request.id')
                           ->join('left join', 'user pays_to', 'pays_to.id = case_request.from_id')
                           ->where(['case_request.id' => $requestId])->one();
    }
    
    
}
