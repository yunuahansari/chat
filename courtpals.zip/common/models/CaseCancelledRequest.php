<?php

namespace common\models;

use Yii;
use yii\data\ActiveDataProvider;

/**
 * This is the model class for table "case_cancelled_request".
 *
 * @property integer $id
 * @property integer $request_id
 * @property string $status
 * @property string $created_at
 * @property string $updated_at
 *
 * @property CaseRequest $request
 */
class CaseCancelledRequest extends \common\models\base\BaseCaseCancelledRequest
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'case_cancelled_request';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'request_id', 'status', 'created_at', 'updated_at'], 'required'],
            [['id', 'request_id'], 'integer'],
            [['created_at', 'updated_at','client_amount', 'peer_amount'], 'safe'],
            [['status'], 'string', 'max' => 11],
            [['request_id'], 'exist', 'skipOnError' => true, 'targetClass' => CaseRequest::className(), 'targetAttribute' => ['request_id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'request_id' => 'Request ID',
            'status' => 'Status',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }
    
    public function behaviors ()
    {
        return [
            'timestamp' => [
                'class' => \yii\behaviors\TimestampBehavior::className(),
                'createdAtAttribute' => 'created_at',
                'updatedAtAttribute' => 'updated_at',
                'value' => new \yii\db\Expression("'" . date('Y-m-d H:i:s') . "'"),
                'attributes' => [
                    \yii\db\ActiveRecord::EVENT_BEFORE_INSERT => ['created_at', 'updated_at'],
                    \yii\db\ActiveRecord::EVENT_BEFORE_UPDATE => ['updated_at'],
                ],
            ],
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getRequest()
    {
        return $this->hasOne(CaseRequest::className(), ['id' => 'request_id']);
    }
    
    public static function getCancelRequest($post)
    {
        $array=[];
        $cancelRequest = CaseRequest::find()
                                        ->join('INNER JOIN', self::tableName().' as ccr','ccr.request_id = case_request.id')
                                        ->join('LEFT JOIN', 'user client', 'client.id = case_request.from_id')
                                        ->join('LEFT JOIN', 'user peer', 'peer.id = case_request.to_id')
                                        ->orderBy('id DESC');
        if (!empty($post['client'])) {
                $cancelRequest->andWhere(['like', 'concat(client.first_name," ",client.last_name)', $post['client']]);
        }
        if (!empty($post['peer'])) {
                $cancelRequest->andWhere(['like', 'concat(peer.first_name," ",peer.last_name)', $post['peer']]);
        }
        if (!empty($post['case_id'])) {
            $cancelRequest->andWhere(['case_request.case_id' => $post['case_id']]);
        }
        if (!empty($post['status'])) {
            $cancelRequest->andWhere(['ccr.status' => $post['status']]);
        }
        $provider = new ActiveDataProvider([
            'query' => $cancelRequest,
            'pagination' => [
                'pageSize' => 10,
            ]
        ]);

        foreach ($provider->getModels() as $pay){
             $serverTimezone = \Yii::$app->getTimeZone();
                    $fromDate = new \DateTime($pay->created_at, new \DateTimeZone($serverTimezone));
                    $fromDate->setTimeZone(new \DateTimeZone($post['timezone']));
                    $pay->created_at = $fromDate->format('Y-m-d H:i:s');
                $array[]=$pay;
        }
        $provider->setModels($array);
        return $provider;
    }
    
    public static function addCancelRequest($id){
        $array = [];
        $request = CaseRequest::find()->where(['id' => $id])->one();
        $user_id = \yii::$app->user->id;
        if(!empty($request)){
            $request->paid_to_attorney = 'no';
            $request->save(false);
            Notification::deleteAll(['request_id' => $request->id,'to_id' => $user_id, 'type' => 'ratting_request']);   
            try{
                \Yii::$app->mailer->compose(['html' => 'refund-request-peer'], ['request' => $request])
                        ->setFrom([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
                        ->setTo($request->to->email)
                        ->setReplyTo([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
                        ->setSubject('Refund request for caseId ' . $request->case_id)
                        ->send(); 
                
                \Yii::$app->mailer->compose(['html' => 'refund-request-client'], ['request' => $request])
                        ->setFrom([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
                        ->setTo($request->from->email)
                        ->setReplyTo([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
                        ->setSubject('Refund request for caseId ' . $request->case_id)
                        ->send(); 
            }catch (\Exception $e){
        
            }
            $re_status= true;
        }else{
           $re_status= false; 
        }
        $response = Notification::checkRatingRequest();
         $rat_status=(!empty($response))?true:false;
        $array['refund']=$re_status;
        $array['rating_status']=$rat_status;
        return $array;
    }
}
