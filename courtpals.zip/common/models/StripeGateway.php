<?php
namespace common\models;

use Stripe\Stripe;
use Stripe\Customer;
use Stripe\Token;
use Stripe\Transfer;
use Stripe\Account;
use Stripe\Refund;

class StripeGateway extends \yii\base\Model
{
    
    public function __construct(){
        parent::__construct();
        
    }
    
    public static function createCustomer($params){
        Stripe::setApiKey(\Yii::$app->params['stripe_secret_key']);
        $allCustomers = Customer::all();
        $found = false;
        if(!empty($allCustomers)){
            foreach ($allCustomers->data as $customer){
                if($customer->email == $params['email']){
                    return Customer::retrieve($customer->id);
                }
            }
        }
        if(!$found){
            return Customer::create(array(
                'email' => $params['email'],
                "description" => "Customer created for Courtpals"
            ));
        }
    }
    
    public static function createConnectAccount($params){
        Stripe::setApiKey(\Yii::$app->params['stripe_secret_key']);
        $user = User::findByAttr(['id' => $params['user_id']]);
        $city = Cities::find()->where(['id' => $user->city])->one();
        $state = States::find()->where(['id' => $city->state_id])->one();
        if(!empty($user)){
            return  \Stripe\Account::create(array(   
                    "type" => "custom",
                    "country" => "US",
                    "email" => $params['email'],
                    "legal_entity" => array(
                        "first_name" => $user->first_name,
                        "last_name" => $user->last_name,
                        "address" => array(
                            "city" => (!empty($city)) ? $city->name : $user->city,
                            "country" => "US",
                            "line1" => $user->address,
                            "line2" => null,
                            "postal_code" => $user->zip_code,
                            "state" => (!empty($state)) ? $state->name : $user->city,
                            ),
                        "dob" => array(
                              "day" => date('d', strtotime($user->dob)),
                              "month" => date('m', strtotime($user->dob)),
                              "year" => date('Y', strtotime($user->dob))
                            ),
                        "personal_id_number" => $user->ssn_number,
                        //"phone_number" => $user->mobile,
                        "type"  =>"individual"
                    ),
                    'tos_acceptance' => array(
                        'date' => time(),
                        'ip' => $_SERVER['REMOTE_ADDR']
                    ),
                ));     
        }
        return false;
    }
       
    public static function addBankAccount($param){
        try{
        Stripe::setApiKey(\Yii::$app->params['stripe_secret_key']);
        $user = User::findByAttr(['id' => \Yii::$app->user->getId()]);
        if(empty($user->stripe_account_id)){
            return 'Please update profile first.';
        }
        $bankToken = Token::create(array(
                                            "bank_account" => array(
                                                "country" => "US",
                                                "currency" => "usd",
                                                "account_holder_name" => \Yii::$app->user->identity->first_name . ' '. \Yii::$app->user->identity->last_name,
                                                "account_number" => $param['account_number'],
                                                "routing_number" => ($param['ach_bank_aba_number']) ? $param['ach_bank_aba_number'] : "110000000",
                                                "account_holder_type" => "individual"
                                            )
                                        )
                                    );
           
        $account = \Stripe\Account::retrieve($user->stripe_account_id);
        return $account->external_accounts->create(array("external_account" => $bankToken->id));
        }  catch (\Exception $e){
               return $e->getMessage();
        }
    }
    
    public static function editBankAccount($param){
        Stripe::setApiKey(\Yii::$app->params['stripe_secret_key']);
        $user = User::findByAttr(['id' => \Yii::$app->user->getId()]);
        $account = \Stripe\Account::retrieve($user->stripe_account_id);
        $bank_account = $account->external_accounts->retrieve($param->stripe_bank_account_id);
        $bank_account->metadata["account_holder_name"] = \Yii::$app->user->identity->first_name . ' '. \Yii::$app->user->identity->last_name;
        $bank_account->metadata["account_number"] = $param->account_number;
        return $bank_account->save();
    }
    
    public static function deleteBankAccount($bankAccountId){
        Stripe::setApiKey(\Yii::$app->params['stripe_secret_key']);
        $user = User::findByAttr(['id' => \Yii::$app->user->getId()]);
        $account = \Stripe\Account::retrieve($user->stripe_account_id);
        return $account->external_accounts->retrieve($bankAccountId)->delete();
    }
    
    public static function chargeCustomer($param){
        Stripe::setApiKey(\Yii::$app->params['stripe_secret_key']);
        $user = User::findByAttr(['id' => \Yii::$app->user->getId()]);
        $chargeOptions = array(
            "amount" => $param['amount'] * 100,
            "currency" => "usd",
            "description" => "Charge for Courtpals request."
        );
        if(!empty($param['token'])){
            $chargeOptions["source"] = $param['token'];
        }else{
            $chargeOptions["customer"] = $user->stripe_customer_id;
            $chargeOptions["card"] = $param['card_id'];
        }
        return \Stripe\Charge::create($chargeOptions);
        
    }
    
    public static function transferToPeerAttorney($param){
        Stripe::setApiKey(\Yii::$app->params['stripe_secret_key']);
        try{
            return Transfer::create(array(
            "amount" => $param['amount'] * 100,
            "currency" => "usd",
            "destination" => $param['account_id'],
            "transfer_group" => "Transfer From Courtpals case."
            ));
        }catch(\Exception $e){
            return false;
        }
    }
    
    public static function deleteConnectAccount(){
        Stripe::setApiKey(\Yii::$app->params['stripe_secret_key']);
        $account = Account::retrieve('acct_1AugiSJ94BU9Hd6Z');
        $account->delete();
    }
    
    public static function refund($param)
    {
        try{
        Stripe::setApiKey(\Yii::$app->params['stripe_secret_key']);
        return Refund::create(array(
            "charge" => $param['charge_id'],
            "amount" => $param['amount'] * 100
        ));
        }catch (\Exception $ex){
            $transaction = new StripeGateway();
            $transaction->addError('misc', $ex->getMessage());
            return $transaction;                    
        }
    }
    
}

