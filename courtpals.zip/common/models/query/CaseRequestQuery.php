<?php

namespace common\models\query;

/**
 * This is the ActiveQuery class for [[\common\models\base\BaseCaseRequest]].
 *
 * @see \common\models\base\BaseCaseRequest
 */
class CaseRequestQuery extends \yii\db\ActiveQuery
{
    /*public function active()
    {
        return $this->andWhere('[[status]]=1');
    }*/

    /**
     * @inheritdoc
     * @return \common\models\base\BaseCaseRequest[]|array
     */
    public function all($db = null)
    {
        return parent::all($db);
    }

    /**
     * @inheritdoc
     * @return \common\models\base\BaseCaseRequest|array|null
     */
    public function one($db = null)
    {
        return parent::one($db);
    }
}
