<?php

namespace common\models\query;

/**
 * This is the ActiveQuery class for [[\common\models\base\BaseDepartments]].
 *
 * @see \common\models\base\BaseDepartments
 */
class DepartmentsQuery extends \yii\db\ActiveQuery
{
    /*public function active()
    {
        return $this->andWhere('[[status]]=1');
    }*/

    /**
     * @inheritdoc
     * @return \common\models\base\BaseDepartments[]|array
     */
    public function all($db = null)
    {
        return parent::all($db);
    }

    /**
     * @inheritdoc
     * @return \common\models\base\BaseDepartments|array|null
     */
    public function one($db = null)
    {
        return parent::one($db);
    }
}
