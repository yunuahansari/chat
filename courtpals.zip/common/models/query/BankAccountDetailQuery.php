<?php

namespace common\models\query;

/**
 * This is the ActiveQuery class for [[\common\models\base\BaseBankAccountDetail]].
 *
 * @see \common\models\base\BaseBankAccountDetail
 */
class BankAccountDetailQuery extends \yii\db\ActiveQuery
{
    /*public function active()
    {
        return $this->andWhere('[[status]]=1');
    }*/

    /**
     * @inheritdoc
     * @return \common\models\base\BaseBankAccountDetail[]|array
     */
    public function all($db = null)
    {
        return parent::all($db);
    }

    /**
     * @inheritdoc
     * @return \common\models\base\BaseBankAccountDetail|array|null
     */
    public function one($db = null)
    {
        return parent::one($db);
    }
}
