<?php

namespace common\models\query;

/**
 * This is the ActiveQuery class for [[\common\models\base\Settings]].
 *
 * @see \common\models\base\Settings
 */
class SettingsQuery extends \yii\db\ActiveQuery
{
    /*public function active()
    {
        return $this->andWhere('[[status]]=1');
    }*/

    /**
     * @inheritdoc
     * @return \common\models\base\Settings[]|array
     */
    public function all($db = null)
    {
        return parent::all($db);
    }

    /**
     * @inheritdoc
     * @return \common\models\base\Settings|array|null
     */
    public function one($db = null)
    {
        return parent::one($db);
    }
}
