<?php

namespace common\models;

use yii\base\Model;
use common\models\User;
use common\models\base\BaseUser;
use yii\behaviors\TimestampBehavior;
use yii\db\Expression;
use yii\helpers\ArrayHelper;
use common\components\Utility;

/**
 * Signup form
 */
class ContactUs extends Model{

    public $message;
    public $subject;
    public $email;

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['email', 'subject','message'],'required'],
            [['email'], 'email'],
            //[['name'], 'string', 'max' => 30],
        ];
    }

    

    public static function contactUs() {
        
    }

}
