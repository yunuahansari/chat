<?php

namespace common\models;

use Yii;
use yii\helpers\ArrayHelper;
use yii\data\ActiveDataProvider;

/**
 * This is the model class for table "hearing_type".
 *
 * @property integer $id
 * @property string $name
 * @property string $status
 * @property string $created_at
 * @property string $updated_at
 *
 * @property CaseRequest[] $caseRequests
 */
class HearingType extends base\BaseHearingType {

    public $hearing_type;
    public $parent_name;
    public $sub_hearing_types;

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return 'hearing_type';
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['name','price'], 'required'],
            [['status'], 'string'],
            [['price'], 'number', 'numberPattern' => '/^\s*[-+]?[0-9]*[.,]?[0-9]+([eE][-+]?[0-9]+)?\s*$/','max' => 9999, 'min' => 1],
            [['created_at', 'updated_at','parent'], 'safe'],
            [['name'], 'string', 'max' => 255],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'status' => 'Status',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    public function behaviors() {
        return [
            'timestamp' => [
                'class' => \yii\behaviors\TimestampBehavior::className(),
                'createdAtAttribute' => 'created_at',
                'updatedAtAttribute' => 'updated_at',
                'value' => new \yii\db\Expression("'" . date('Y-m-d H:i:s') . "'"),
                'attributes' => [
                    \yii\db\ActiveRecord::EVENT_BEFORE_INSERT => ['created_at', 'updated_at'],
                    \yii\db\ActiveRecord::EVENT_BEFORE_UPDATE => ['updated_at'],
                ],
            ],
        ];
    }

    public function fields() {
        $parentFields = parent::fields();
        $fields = [
            'selected' => function($model) {
                return HearingDetail::getUserHearingTypeStatus($model->id);
            },
            'parent_name',
            'sub_hearing_types'
        ];
        unset($parentFields['created_at'], $parentFields['updated_at'], $parentFields['status'], $parentFields['sub_hearing_types']);
        return ArrayHelper::merge($parentFields, $fields);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCaseRequests() {
        return $this->hasMany(CaseRequest::className(), ['hearing_type_id' => 'id']);
    }
    
    public static function getAll()
    {
        $hearingTypes = self::find()->where(['parent' => 0])->all();
        return ArrayHelper::map($hearingTypes, 'id', 'name');
    }
    
    public static function getAllHearingType() {
        $hearingType = self::find()->where(['status' => 'active', 'parent' => 0])->all();
        $return = [];
        if (!empty($hearingType)) {
            foreach ($hearingType as $hearingType) {
                $hearingType['sub_hearing_types'] = self::getChildTypes($hearingType->id);
                $return[] = $hearingType;
            }
        }
        return $return;
    }
    
    public static function getAllSubHearingType($id) {
        
        $hearingType = self::find()->where(['status' => 'active', 'parent' => $id])->all();
        return $hearingType;
    }
    
    public static function getChildTypes($parent) {
        return self::find()->select('hearing_type.id, hearing_type.name, hearing_type.price, ht.name as parent_name')
                        ->join('left join', 'hearing_type as ht', 'ht.id = hearing_type.parent')
                        ->where(['hearing_type.status' => 'active', 'hearing_type.parent' => $parent])->all();
    }

    public static function allHearingType($post) {

        $result = [];
        if (!empty($post['search'])) {
            $model = self::find()->where(['AND', ['status' => 'active'], ['like', 'name', $post['search']]]);
        } else {
            $model = self::find()->where(['status' => 'active']);
        }
        if (!empty($model)) {
            $provider = new ActiveDataProvider([
                'query' => $model,
                'sort'=> ['defaultOrder' => ['id' => SORT_DESC]],
                'pagination' => [
                    'pageSize' => 5,
                ],
            ]);
            foreach ($provider->getModels() as $value) {
                if ($value['parent'] == 0) {
                    $value['parent'] = 'not available';
                } else {
                    $value['parent'] = self::hearingParentName($value['parent']);
                }
                $result[] = $value;
            }
            $provider->setModels($result);
            return $provider;
        }
    }

    public static function hearingParentName($parent_id) {
        return self::find()->where(['id' => $parent_id])->one()['name'];
    }

    public static function addHearingType($model) {
        if ($model->validate()) {
            if ($model->save(false)) {
                return true;
            }return false;
        }
    }

}
