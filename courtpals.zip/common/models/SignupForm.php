<?php

namespace common\models;

use yii;
use yii\base\Model;
use common\models\User;
use common\models\base\BaseUser;
use yii\behaviors\TimestampBehavior;
use yii\db\Expression;
use yii\helpers\ArrayHelper;
use common\components\Utility;
use common\models\Settings;

/**
 * Signup form
 */
class SignupForm extends User {

    public $confirm_password;
    public $password;
    public $first_name;
    public $last_name;
    public $email;

    /**
     * @inheritdoc
     */
    public function rules() {
        return ArrayHelper::merge(
                        parent::rules(), [
                    [['first_name', 'last_name', 'email', 'password'], 'trim'],
                    [['first_name', 'last_name', 'email', 'password', 'confirm_password'], 'required'],
                    ['email', 'unique', 'targetClass' => '\common\models\User', 'message' => 'This email has already been taken.'],
                    // ['email', 'uniqueEmail', 'message' => 'Email already exist'],
                    [['confirm_password'], 'compare', 'compareAttribute' => 'password', 'message' => 'Passwords do not match', 'operator' => '=='],
                    ['email', 'email'],
                    ['password', 'string', 'min' => 6],
                        //['password', 'match','pattern' => '/^(?=.*[0-9])(?=.*[A-Z])([a-zA-Z0-9]+)$/','message' => 'Password can only contain Minimum 6 characters, at least 1 capital letter, and at least 1 numeric digit'],
        ]);
    }

    /**
     * @inheritdoc
     */
    public function behaviors() {
        return [
            [
                'class' => TimestampBehavior::className(),
                'value' => new Expression('NOW()')
            ],
        ];
    }

//    public function uniqueEmail() {
//        $email = User::find()->where('email=:email',['email' => $this->email])->all(); 
//        if (count($email))
//            return $this->addError('email', 'Email already exists');
//    }

    public function signUp() {
        $model = new User();
        $model->first_name = $this->first_name;
        $model->last_name = $this->last_name;
        $model->email = $this->email;
        $model->password = $model->setPassword($this->password);
        $model->generateVerifyCode(); //ganerate varify token for activation
        $model->status = 'inactive';
        $model->role = 'user';
        $model->commition = Settings::getCommissionFromSettings();
        if ($model->save(false)) {
            
            $customer = \common\models\StripeGateway::createCustomer(['email' => $model->email]);
            if(!empty($customer) && $customer->id != ''){
                User::updateAll(['stripe_customer_id' => $customer->id], ['id' => $model->id]);
            }
            $hearing_type = \common\models\HearingType::find()->where(['status' => 'active','parent' => 0])->all();
            if(!empty($hearing_type)){
                foreach ($hearing_type as $hearing_type){
                    $hearingDetail = new \common\models\HearingDetail();
                    $hearingDetail->user_id = $model->id;
                    $hearingDetail->hearing_type = $hearing_type->id;
                    $hearingDetail->save(false);
                }
            }
            try{
                Yii::$app->mailer->compose(['html' => 'userSignUp-html'], ['user' => $model])
                    ->setFrom([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
                    ->setTo($model->email)
                    ->setReplyTo([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
                    ->setSubject('Welcome to ' . \Yii::$app->name)
                    ->send();
            }catch (\Exception $e){
                return true;
            }
            return true;
        } else {
            return $model;
        }
    }

}
