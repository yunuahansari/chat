<?php

namespace common\models;

use Yii;
use common\models\User;
use yii\data\ActiveDataProvider;
use yii\helpers\ArrayHelper;

/**
 * This is the model class for table "review".
 *
 * @property integer $id
 * @property integer $from_user_id
 * @property integer $to_user_id
 * @property string $review_text
 * @property double $rating
 * @property string $status
 * @property string $created_at
 * @property string $updated_at
 *
 * @property User $fromUser
 * @property User $toUser
 */
class Review extends base\BaseReview
{

    /**
     * @inheritdoc
     */
    public static function tableName ()
    {
        return 'review';
    }

    public function behaviors ()
    {
        return [
            'timestamp' => [
                'class' => \yii\behaviors\TimestampBehavior::className(),
                'createdAtAttribute' => 'created_at',
                'updatedAtAttribute' => 'updated_at',
                'value' => new \yii\db\Expression("'" . date('Y-m-d H:i:s') . "'"),
                'attributes' => [
                    \yii\db\ActiveRecord::EVENT_BEFORE_INSERT => ['created_at', 'updated_at'],
                    \yii\db\ActiveRecord::EVENT_BEFORE_UPDATE => ['updated_at'],
                ],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function rules ()
    {
        return [
            [['from_user_id', 'to_user_id'], 'integer'],
            [['review_text', 'status'], 'string'],
            [['rating'], 'number'],
            [['created_at', 'updated_at', 'request_id','apeerance_successfull'], 'safe'],
            [['from_user_id'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['from_user_id' => 'id']],
            [['to_user_id'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['to_user_id' => 'id']],
        ];
    }

    public function fields ()
    {
        $fields = [
        ];
        return ArrayHelper::merge(parent::fields(), $fields);
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels ()
    {
        return [
            'id' => 'ID',
            'from_user_id' => 'From User ID',
            'to_user_id' => 'To User ID',
            'review_text' => 'Review Text',
            'rating' => 'Rating',
            'status' => 'Status',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }
    
    /**
     * @return \yii\db\ActiveQuery
     */
    public function getFromUser ()
    {
        return $this->hasOne(User::className(), ['id' => 'from_user_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getToUser ()
    {
        return $this->hasOne(User::className(), ['id' => 'to_user_id']);
    }
    
    /**
     * @return \yii\db\ActiveQuery
     */
    public function getRequest()
    {
        return $this->hasOne(CaseRequest::className(), ['id' => 'request_id']);
    }
    
    public static function giveRating ($data)
    {

        $user_id = \yii::$app->user->id;
        $rattingModel = new Review();
        $rattingModel->load($data, '');
        $rattingModel->from_user_id = $user_id;
        
        if ($rattingModel->save(false)) {
            $user_data = User::userDataForNotification(\yii::$app->user->id);
            $to_user = User::find()->select('user.id,user.notification')->where(['AND', ['=', 'user.id', $data['to_user_id']], ['OR',['user.status' => 'active'],['user.status' => 'banned']], ['user.is_available' => 1]])->one();
            $type = 'ratting_given';
            $message = 'you have been reviewed by '.$user_data['user_name'];
            
            $notification_data =  ['title' => "you've been reviewed!", 'type' => $type, 'from_id' => \yii::$app->user->id, 'to_id' => $data['to_user_id'], 'user_name' => $user_data['user_name'],
                'profile_image' => $user_data['profile_image'],'case_id' => $rattingModel->request->case_id,'notification_receive_status'=>$to_user->notification];

             if (!empty($to_user)) {
                    $to_user_device_type = UserDevices::find()->where(['user_id'=>$to_user['id']])->one();
                    Notification::saveNotification(['to_id' => [$to_user['id']], 'request_id'=>$data['request_id'],'from_id' => \yii::$app->user->id, 'type' => $type, 'message' => $message, 'notification_data' => json_encode($notification_data)]);
                    if($to_user->notification == 'disable'){
                        $notification_data['unread_notification_count'] = Notification::newNotification($to_user['id']);
                        \api\components\Utility::sendWithoutAlertMessagePushNotification($to_user['id'], $message, $notification_data);
                    }
                    if($to_user->notification == 'enable'){
                        $notification_data['unread_notification_count'] = Notification::newNotification($to_user['id']);
                        \api\components\Utility::sendMessagePushNotification($to_user['id'], $message, $notification_data);
                    }
                    $request = CaseRequest::find()->where(['id' => $rattingModel->request->id])->one();
                    
                    if($request->from_id == Yii::$app->user->id){
                        $admin = User::find()->where(['role' => 'admin'])->one();
                        $postData = array();
                        $postData['request_id'] = $data['request_id'];
                        $postData['admin_id'] = $admin->id;
                        $postData['paid_to_attorney'] = Transactions::calculateCommitionedAmount($request->from->commition, $request->transactions->amount);
                        Transactions::addTransfer($postData);
                    }
                    Notification::deleteAll(['AND',['request_id' => $data['request_id'],'to_id' => $user_id], ['OR',['type' => 'ratting_request'],['type' => 'accept_case_request']]]);
            }
                $response = Notification::checkRatingRequest();
                $status=(!empty($response))?true:false;
                \yii::$app->response->extraData = ['rating_status' =>  $status];
            return $rattingModel;
        }
        return $rattingModel;
    }

    public static function findRattingCount ($consultant_id)
    {
        return Review::find()->where(['to_user_id' => $consultant_id, 'status' => 'active'])->groupBy('from_user_id')->count();
    }

    public static function getRattingAndReview ($data)
    {
        $array = [];
        $query = self::find()->where(['to_user_id' => $data['provider_id']])->orderBy('created_at DESC');
        $provider = new ActiveDataProvider([
            'query' => $query,
            'pagination' => [
                'pageSize' => 5,
            ]
        ]);
        foreach ($provider->getModels() as $rat){
            if(!empty($data['timezone'])){
                $serverTimezone = \Yii::$app->getTimeZone();
                $fromDate = new \DateTime($rat['created_at'], new \DateTimeZone($serverTimezone));
                $fromDate->setTimeZone(new \DateTimeZone($data['timezone']));
                $rat['created_at'] = $fromDate->format('Y-m-d H:i:s');
            }
            $array[] = $rat;
        }
        $provider->getModels($array);
        return $provider;
    }

    public static function findReviewList ($data)
    {
        $array = [];
        $query = self::find()->where(['to_user_id' => $data['id']]);
        $provider = new ActiveDataProvider([
            'query' => $query,
            'pagination' => [
                'pageSize' => 10,
            ],
        ]);
        foreach ($provider->getModels() as $value) {
            if (isset($data['timezone']) && $data['timezone'] != '') {
                $serverTimezone = \Yii::$app->getTimeZone();
                $fromDate = new \DateTime($value['created_at'], new \DateTimeZone($serverTimezone));
                $fromDate->setTimeZone(new \DateTimeZone($data['timezone']));
                $value['created_at'] = $fromDate->format('Y-m-d H:i:s');
            }
            $array[] = $value;
        }
        $provider->setModels($array);
        return $provider;
    }

    public static function averageRatting ($mover_id)
    {

        $reviews = Review::find()->where(['to_user_id' => $mover_id])->all();
        $length = count($reviews);
        $sum = 0;
        if (!empty($reviews)) {
            foreach ($reviews as $value) {
                $sum+=$value->rating;
            }
            $average_ratting = number_format($sum / $length,1);
            return $average_ratting;
        }
        return 0.00;
    }
    
    public static function getCaseDetail($data) {
        
        $userId = Yii::$app->user->getId();
        $touserId = $data['id'];
        $query = "SELECT  u.id, u.profile_pic, u.address as user_address, CONCAT(u.first_name,' ',u.last_name) as user_name, cr.case_id, cr.address, cr.case_date, cr.case_time, r.rating,r.review_text, (SELECT TRUNCATE(Avg(rating),1) FROM review WHERE to_user_id = $touserId) as user_rating
                  FROM case_request cr
                  LEFT JOIN user u ON u.id = CASE WHEN cr.to_id = $touserId THEN cr.from_id ELSE cr.to_id END
                  LEFT JOIN review r ON cr.id = r.request_id
                  WHERE cr.case_id = '{$data['case_id']}' AND cr.status = 'completed' AND r.to_user_id = $touserId";
        
        $data = \yii::$app->db->createCommand($query)->queryOne();
        $data['profile_pic'] = \common\components\Utility::getUserImage($data['id']);
        return $data;
    }
    
}
