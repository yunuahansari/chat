<?php

namespace common\models;

use Yii;
use yii\web\UploadedFile;
use api\components\Utility;
use yii\data\ActiveDataProvider;
use yii\helpers\ArrayHelper;
use common\models\CaseCancelledRequest;
use common\models\RepostCases;

/**
 * This is the model class for table "case_request".
 *
 * @property integer $id
 * @property string $case_id
 * @property string $case_number
 * @property integer $from_id
 * @property integer $to_id
 * @property integer $department_id
 * @property integer $hearing_type_id
 * @property string $address
 * @property string $case_date
 * @property string $case_time
 * @property string $party_1
 * @property string $party_2
 * @property string $description
 * @property string $desired_outcome
 * @property string $status
 * @property string $created_at
 * @property string $updated_at
 *
 * @property User $from
 * @property User $to
 * @property Departments $department
 * @property HearingType $hearingType
 * @property CaseRequestImages[] $caseRequestImages
 */
class CaseRequest extends base\BaseCaseRequest
{

    public $request_id;
    public $amount;
    public $commition;
    public $can_complete;

    /**
     * @inheritdoc
     */
    public static function tableName ()
    {
        return 'case_request';
    }

    /**
     * @inheritdoc
     */
    public function rules ()
    {
        return [
            [['from_id', 'to_id', 'department_id', 'hearing_type_id'], 'integer'],
            [['case_date', 'case_time', 'created_at', 'updated_at', 'party1_mobile', 'cancelled_by', 'sub_hearing_type', 'timezone', 'other_department'], 'safe'],
            [['description', 'status'], 'string'],
            [['case_id', 'case_number', 'address', 'party_1', 'party_2', 'desired_outcome'], 'string', 'max' => 255],
            [['from_id'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['from_id' => 'id']],
            [['to_id'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['to_id' => 'id']],
            [['department_id'], 'exist', 'skipOnError' => true, 'targetClass' => Departments::className(), 'targetAttribute' => ['department_id' => 'id']],
            [['hearing_type_id'], 'exist', 'skipOnError' => true, 'targetClass' => HearingType::className(), 'targetAttribute' => ['hearing_type_id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels ()
    {
        return [
            'id' => 'ID',
            'case_id' => 'Case ID',
            'case_number' => 'Case Number',
            'from_id' => 'From ID',
            'to_id' => 'To ID',
            'department_id' => 'Department ID',
            'hearing_type_id' => 'Hearing Type ID',
            'address' => 'Address',
            'case_date' => 'Case Date',
            'case_time' => 'Case Time',
            'party_1' => 'Party 1',
            'party_2' => 'Party 2',
            'description' => 'Description',
            'desired_outcome' => 'Desired Outcome',
            'status' => 'Status',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    public function behaviors ()
    {
        return [
            'timestamp' => [
                'class' => \yii\behaviors\TimestampBehavior::className(),
                'createdAtAttribute' => 'created_at',
                'updatedAtAttribute' => 'updated_at',
                'value' => new \yii\db\Expression("'" . date('Y-m-d H:i:s') . "'"),
                'attributes' => [
                    \yii\db\ActiveRecord::EVENT_BEFORE_INSERT => ['created_at', 'updated_at'],
                    \yii\db\ActiveRecord::EVENT_BEFORE_UPDATE => ['updated_at'],
                ],
            ],
        ];
    }

    public function fields ()
    {
        $parentFields = parent::fields();
        $fields = [
            'sender_name' => function($model) {
                return $model->from->first_name . ' ' . $model->from->last_name;
            },
            'sender_profile_image' => function($model) {
                return \common\components\Utility::getUserImage($model->from_id);
            },
            'receiver_name' => function($model) {
                if (!empty($model->to))
                    return $model->to->first_name . ' ' . $model->to->last_name;
            },
            'receiver_profile_image' => function($model) {
                if (!empty($model->to))
                    return \common\components\Utility::getUserImage($model->to_id);
            },
            'department_name' => function($model) {
                return $model->department->name;
            },
            'hearing_type' => function($model) {
                return $model->hearingType->name;
            },
            'documents' => function($model) {
                return $model->caseRequestImages;
            },
            'price' => function($model) {
                $amount = Transactions::calculateCommitionedAmount($model->transactions->commition, $model->transactions->amount);
                return $amount;
                //return $model->transactions->amount;
            },
            'main_amount' => function($model) {
                return $model->transactions->amount;
            },
            'can_complete' => function($model) {
                $data = \yii::$app->request->get();
                if (isset($data['timezone']) && $data['timezone'] != '') {
                    $serverTimezone = \Yii::$app->getTimeZone();
                    $fromDate = new \DateTime(date('Y-m-d H:i:s'), new \DateTimeZone($serverTimezone));
                    $fromDate->setTimeZone(new \DateTimeZone($data['timezone']));
                    $current_time = $fromDate->format('H:i:s');
                    $current_date = $fromDate->format('Y-m-d');

                    if ($model->case_date < $current_date || ($model->case_date == $current_date && $model->case_time <= $current_time)) {
                        return true;
                    }
                }
                return false;
            },
            'can_cancel' => function($model) {
                $data = \yii::$app->request->get();
                if (isset($data['timezone']) && $data['timezone'] != '') {
                    $serverTimezone = \Yii::$app->getTimeZone();
                    $fromDate = new \DateTime(date('Y-m-d H:i:s'), new \DateTimeZone($serverTimezone));
                    $fromDate->setTimeZone(new \DateTimeZone($data['timezone']));
                    $current_time = $fromDate->format('H:i:s');
                    $current_date = $fromDate->format('Y-m-d');
                    if ($model->case_date < $current_date || ($model->case_date == $current_date && $model->case_time < $current_time)) {
                        return false;
                    }
                }
                return true;
            },
        ];
        unset($parentFields['created_at'], $parentFields['updated_at']);
        return ArrayHelper::merge($parentFields, $fields);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getFrom ()
    {
        return $this->hasOne(User::className(), ['id' => 'from_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTo ()
    {
        return $this->hasOne(User::className(), ['id' => 'to_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getDepartment ()
    {
        return $this->hasOne(Departments::className(), ['id' => 'department_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getHearingType ()
    {
        return $this->hasOne(HearingType::className(), ['id' => 'hearing_type_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCaseRequestImages ()
    {
        return $this->hasMany(CaseRequestImages::className(), ['case_request_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getRequestTags ()
    {
        return $this->hasMany(RequestTag::className(), ['request_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTransactions ()
    {
        return $this->hasOne(Transactions::className(), ['request_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getReviews ()
    {
        return $this->hasMany(Review::className(), ['request_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCancelledBy ()
    {
        return $this->hasOne(User::className(), ['id' => 'cancelled_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCaseCancelledRequests ()
    {
        return $this->hasMany(CaseCancelledRequest::className(), ['request_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getRepostCases ()
    {
        return $this->hasMany(RepostCases::className(), ['request_id' => 'id']);
    }

    public static function postCaseRequest ($post)
    {
        $result = [];
        $model = new CaseRequest();
        $model->load($post, '');
        $model->from_id = \yii::$app->user->id;
        $files = UploadedFile::getInstancesByName('image');
        if ($model->save(false)) {

            if (!empty($files)) {
                foreach ($files as $file) {
                    $image_model = new CaseRequestImages();
                    $image_model->case_request_id = $model->id;
                    $image_model->image = User::uploadDocument($file);
                    $image_model->save(false);
                }
            }
            if (!empty($post['tags'])) {
                $tags = explode(',', $post['tags']);
                if (!empty($tags)) {
                    foreach ($tags as $tag) {
                        $tagModel = Tags::find()->where(['name' => $tag])->one();
                        if (empty($tagModel)) {
                            $tagModel = new Tags();
                            $tagModel->name = $tag;
                            $tagModel->save(false);
                        }
                        $requestTag = new RequestTag();
                        $requestTag->tag_id = $tagModel->id;
                        $requestTag->request_id = $model->id;
                        $requestTag->save(false);
                    }
                }
            }
            $result['request_id'] = $model->id;
            return $result;
        }return false;
    }

    public static function generateCaseId ()
    {
        $data = [];
        $data['case_id'] = Utility::generateCaseId();
        return $data;
    }

    public static function getRequestList ($params)
    {
        if ($params['type'] == 'requested') {
            $query = self::find()->where(['AND', ['=', 'from_id', \yii::$app->user->id], ['OR', ['=', 'status', 'active'], ['=', 'status', 'accepted']]])->orderBy('id DESC');
        } else if ($params['type'] == 'received') {
            $query = self::find()->where(['AND', ['=', 'to_id', \yii::$app->user->id], ['OR', ['=', 'status', 'active'], ['=', 'status', 'accepted']]])->orderBy('id DESC');
        } else if ($params['type'] == 'cancelled') {
            $query = self::find()->where(['AND', ['=', 'status', 'cancelled'], ['OR', ['=', 'cancelled_by', \yii::$app->user->id], ['=', 'from_id', \yii::$app->user->id], ['=', 'to_id', \yii::$app->user->id]]])->orderBy('id DESC');
        } else {

            $case_id = [];
            $canceled_cases = CaseCancelled::find()->where(['user_id' => \yii::$app->user->id])->orderBy('updated_at DESC')->all();
            foreach ($canceled_cases as $value) {
                $case_id = $value['case_id'];
            }
            $query = self::find()->where(['id' => $case_id]);
        }

        if (!empty($params['last_case_id'])) {
            $query->andWhere(['>', 'id', $params['last_case_id']]);
            $pagination = false;
        } else {
            $pagination = [
                'pageSize' => 10,
            ];
        }
        if (!empty($query)) {
            $provider = new ActiveDataProvider([
                'query' => $query,
                'pagination' => $pagination
            ]);
                $response = Notification::checkRatingRequest();
                $status=(!empty($response))?true:false;
                $user =  User::getUserByAttr(['id'=>  \yii::$app->user->id]);
                $place_status=(!empty($user))?$user->can_place:'no';
                \yii::$app->response->extraData = ['rating_status' =>  $status,'can_place'=>$place_status
                ];
            return $provider;
        }return false;
    }

    public static function getRequestDetail ($request_id)
    {
        $request = self::find()->where(['id' => $request_id])->one();
        if ($request) {
            return $request;
        }return false;
    }

    public static function cancelAcceptRequest ($post)
    {
        $banAttorney = 0;
        $response = [];
        $post['timezone'] = (Yii::$app->request->get('timezone')) ? Yii::$app->request->get('timezone') : Yii::$app->getTimeZone();

        $request = self::find()->where(['id' => $post['request_id']])->one();


        if (!empty($request) && $request['status'] == 'accepted' && $post['status'] == 'accepted' && $request['to_id'] != \yii::$app->user->id) {
            return Utility::apiError(201, 'Request is already accepted by other lawyer.');
        }
        if (!empty($request) && $request['status'] == 'cancelled' && $post['status'] == 'accepted') {
            return Utility::apiError(201, 'This request has been cancelled.');
        }
        $check_runig_case = self::find()->where(['status' => 'accepted','to_id'=>\yii::$app->user->id ,'case_date'=>$request['case_date'],'case_time'=>$request['case_time']])->one();
      
        if (!empty($check_runig_case)) {
            return Utility::apiError(201, 'You already have a active case.');
        }
        $response = Notification::checkRatingRequest();
        if(!empty($response) && $post['status']=='accepted'){
            $case_id = CaseRequest::find()->where(['id'=>$response->request_id])->one();
            return Utility::apiError(201, 'Please Rate your Case ID '.$case_id->case_id .' before accepting case.');
        }
        if (!empty($request)) {
            $login_user = \yii::$app->user->id;
            $user = User::find()->where(['id' => $login_user])->one();
            $repost = RepostCases::findOne(['request_id' => $request->id]);
            if (($post['status'] == 'cancelled') && ($request['from_id'] == $login_user || $request['to_id'] == $login_user) && ($request['status'] == 'accepted')) {
                $request->status = $post['status'];
                $request->cancelled_by = $login_user;
            } elseif ($post['status'] == 'accepted' && $user->approved =='yes') {
                $request->status = $post['status'];
                $request->to_id = \yii::$app->user->id;
            } else if ($post['status'] == 'completed') {
                $request->status = $post['status'];
            } else if ($post['status'] == 'cancelled' && $request['status'] == 'active') {
                Notification::deleteAll(['request_id' => $post['request_id'], 'to_id' => \yii::$app->user->id]);
                $request->status = $post['status'];
                $request->cancelled_by = $login_user;
            }

            if ($request->save(false)) {

                if ($post['status'] == 'accepted') {
                    Notification::deleteAll(['request_id' => $post['request_id']]);

                    $user_data = User::userDataForNotification(\yii::$app->user->id);
                    $to_user = User::find()->select('user.id,user.notification')->where(['AND', ['=', 'user.id', $request->from_id], ['OR',['user.status' => 'active'],['user.status' => 'banned']], ['user.is_available' => 1]])->one();
                    $to_user_device_type = UserDevices::find()->where(['user_id' => $request->from_id])->one();
                    $type = 'accept_case_request';
                    $message = 'Case request accepted by ' . $user_data['user_name'];

                    $notification_data = ['title' => '',
                        'type' => $type,
                        'from_id' => $request->to_id,
                        'to_id' => $request->from_id,
                        'user_name' => $user_data['user_name'],
                        'profile_image' => $user_data['profile_image'],
                        'request_id' => $request->id,
                        'request_description' => $request->description,
                        'case_id' => $request->case_id,
                        'case_date' => $request->case_date,
                        'case_time' => $request->case_time,
                        'notification_receive_status' => $to_user->notification
                    ];

                    if (!empty($to_user)) {
                        Notification::saveNotification(['to_id' => [$request->from_id], 'request_id' => $request->id, 'from_id' => \yii::$app->user->id, 'type' => $type, 'message' => $message, 'notification_data' => json_encode($notification_data)]);
                        if ($to_user->notification == 'disable') {
                            $notification_data['unread_notification_count'] = Notification::newNotification($request->from_id);
                            \api\components\Utility::sendWithoutAlertMessagePushNotification($request->from_id, $message, $notification_data);
                        }
                        if ($to_user->notification == 'enable') {
                            $notification_data['unread_notification_count'] = Notification::newNotification($request->from_id);
                            \api\components\Utility::sendMessagePushNotification($request->from_id, $message, $notification_data);
                        }
                    }
                    try{
                        \Yii::$app->mailer->compose(['html' => 'case-placed-client'], ['request' => $request])
                                ->setFrom([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
                                ->setTo($request->from->email)
                                ->setSubject('Case placed ' . \Yii::$app->name)
                                ->send();

                        \Yii::$app->mailer->compose(['html' => 'case-placed-peer'], ['request' => $request])
                            ->setFrom([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
                            ->setTo($request->to->email)
                            ->setSubject('Case placed ' . \Yii::$app->name)
                            ->send();
                    }catch (\Exception $e){
        
                    }
//                    $transaction = Transactions::find()->where(['request_id' => $request->id])->one();
//                    if (!empty($transaction)) {
//                        $transaction->commition = $request->from->commition;
//                        $transaction->save(false);
//                    }
                }

                if ($post['status'] == 'completed') {
                    Notification::deleteAll(['request_id' => $post['request_id'], 'type' => 'accept_case_request']);
                    $user_data = User::userDataForNotification(\yii::$app->user->id);
                    $to_user = User::find()->select('user.id,user.notification')->where(['AND', ['=', 'user.id', $request->from_id], ['OR',['user.status' => 'active'],['user.status' => 'banned']], ['user.is_available' => 1]])->one();
                    $peer_user = User::userDataForNotification($request->from_id);

                    if (\yii::$app->user->id != $request->from_id) {
                        $type = 'ratting_request';
                        $message = 'Case ID '.$request->case_id.' was completed by pal attorney '. $request->to->first_name.' '.$request->to->last_name.'.Please provide a rating and review of '.$request->to->first_name.'’s performance on this matter ';
                        $peer_message = 'Congratulations on completing Case ID'.$request->case_id.'.Please provide a rating and review for '.$request->from->first_name. ' '.$request->from->last_name;
                        $to_user_id = $request->from_id;
                        $peer_id = $request->to_id;

                        $caseReview = CaseReviews::find()->where(['request_id' => $post['request_id']])->one();

                        $notification_data = ['title' => '',
                            'type' => $type,
                            'from_id' => $request->to_id,
                            'to_id' => $request->from_id,
                            'user_name' => $user_data['user_name'],
                            'profile_image' => $user_data['profile_image'],
                            'request_id' => $request->id,
                            'address' => $request->address,
                            'request_description' => $request->description,
                            'case_id' => $request->case_id,
                            'case_date' => $request->case_date,
                            'case_time' => $request->case_time,
                            'case_review' => (!empty($caseReview->review))?$caseReview->review:""
                        ];
                        $peer_notification_data = ['title' => '',
                            'type' => $type,
                            'from_id' => $request->from_id,
                            'to_id' => $request->to_id,
                            'user_name' => $peer_user['user_name'],
                            'profile_image' => $peer_user['profile_image'],
                            'request_id' => $request->id,
                            'address' => $request->address,
                            'request_description' => $request->description,
                            'case_id' => $request->case_id,
                            'case_date' => $request->case_date,
                            'case_time' => $request->case_time,
                            'case_review' => ''
                        ];

                        if (!empty($to_user)) {
                            Notification::saveNotification(['to_id' => [$to_user_id], 'request_id' => $request->id, 'from_id' => \yii::$app->user->id, 'type' => $type, 'message' => $message, 'notification_data' => json_encode($notification_data)]);
                            $to_user_device_type = UserDevices::find()->where(['user_id' => $to_user_id])->one();
                            
                            
                            $notification_data['notification_receive_status'] = $to_user->notification;
                            if ($to_user->notification == 'disable') {
                            $notification = Notification::find()->where(['request_id'=>$request->id,'type'=>'ratting_request','to_id'=>$to_user_id])->one();
                            $notification_data['notification_id'] = ($notification)?$notification->id:"";
                                $notification_data['unread_notification_count'] = Notification::newNotification($request->from_id);
                                \api\components\Utility::sendWithoutAlertMessagePushNotification($to_user_id, $message, $notification_data);
                            }
                            if ($to_user->notification == 'enable') {
                            $notification = Notification::find()->where(['request_id'=>$request->id,'type'=>'ratting_request','to_id'=>$to_user_id])->one();
                            $notification_data['notification_id'] = ($notification)?$notification->id:"";
                                $notification_data['unread_notification_count'] = Notification::newNotification($request->from_id);
                                \api\components\Utility::sendMultiPushNotification($to_user_id, $message, $notification_data);
                            }
                        }
                        if (!empty($peer_user)) {
                            Notification::saveNotification(['to_id' => [$peer_id], 'request_id' => $request->id, 'from_id' => $request->from_id, 'type' => $type, 'message' => $peer_message, 'notification_data' => json_encode($peer_notification_data)]);
                            
                            $peer_notification_data['notification_receive_status'] = $peer_user['notification'];
                            $notification = Notification::find()->where(['AND',['request_id'=>$request->id,'type'=>'ratting_request','to_id'=>$peer_id]])->one();
                            $peer_notification_data['notification_id'] = ($notification)?$notification->id:"";
                            
                            
                            $peer_user_device = UserDevices::find()->where(['user_id' => $peer_id])->one();
                            if ($user_data['notification'] == 'disable') {
                                $peer_notification_data['unread_notification_count'] = Notification::newNotification($request->to_id);
                                \api\components\Utility::sendWithoutAlertMessagePushNotification($peer_id, $peer_message, $peer_notification_data);
                            }
                            if ($user_data['notification'] == 'enable') {
                                $peer_notification_data['unread_notification_count'] = Notification::newNotification($request->to_id);
                                \api\components\Utility::sendMultiPushNotification($peer_id, $peer_message, $peer_notification_data);
                            }
                        }
                        try{
                            \Yii::$app->mailer->compose(['html' => 'case-complete-client'], ['request' => $request])
                                ->setFrom([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
                                ->setTo($request->from->email)
                                ->setSubject('Case Completed ' . \Yii::$app->name)
                                ->send();

                            \Yii::$app->mailer->compose(['html' => 'case-complete-peer'], ['request' => $request])
                                ->setFrom([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
                                ->setTo($request->to->email)
                                ->setSubject('Case Completed ' . \Yii::$app->name)
                                ->send();
                        }catch (\Exception $e){
        
                        }
                    }
                }

                if ($post['status'] == 'cancelled' && $request->cancelled_by != '' && $request->to_id != '') {

                    Notification::deleteAll(['request_id' => $post['request_id']]);

                    // get case refund amount
                    $requestClient = $request->from_id;
                    $requestUser = $request->to_id;
                    $loggedUserID = \yii::$app->user->id;
                    $requestDateTime = $request->case_date . ' ' . $request->case_time;
                    $currentDateTime = date('Y-m-d H:i:s');
                    $currentDateTime = Utility::getDateByTimezone($post['timezone'], $currentDateTime);
                    $datetime1 = new \DateTime($requestDateTime);
                    $datetime2 = new \DateTime($currentDateTime);
                    $difference = $datetime1->diff($datetime2);
                    if ($difference->days > 0) {
                        $hours = $difference->days * 24;
                    } else {
                        $hours = $difference->h;
                    }
                    
                    if ($hours >= 24) {
                        $clientRefundPercent = \Yii::$app->params['client']['before24hour'];
                        $peerRefundPercent = \Yii::$app->params['peer']['before24hour'];

                        if (\yii::$app->user->id != $request->to_id) {
                           
                            try{
                                \Yii::$app->mailer->compose(['html' => 'client-cancelled-client-24'], ['request' => $request])
                                    ->setFrom([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
                                    ->setTo($request->from->email)
                                    ->setSubject('Case cancelled ' . \Yii::$app->name)
                                    ->send();
                                \Yii::$app->mailer->compose(['html' => 'client-cancelled-peer-24'], ['request' => $request])
                                    ->setFrom([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
                                    ->setTo($request->to->email)
                                    ->setSubject('Case cancelled ' . \Yii::$app->name)
                                    ->send();
                            }catch (\Exception $e){
        
                            }
                        } else {
                            try{
                                \Yii::$app->mailer->compose(['html' => 'peer-cancelled-client-24'], ['request' => $request])
                                    ->setFrom([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
                                    ->setTo($request->from->email)
                                    ->setSubject('Case cancelled ' . \Yii::$app->name)
                                    ->send();
                                \Yii::$app->mailer->compose(['html' => 'peer-cancelled-peer-24'], ['request' => $request])
                                    ->setFrom([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
                                    ->setTo($request->to->email)
                                    ->setSubject('Case cancelled ' . \Yii::$app->name)
                                    ->send();
                            }catch (\Exception $e){
        
                            }
                        }
                    } elseif ($hours < 24 && $hours > 12) {
                        $clientRefundPercent = \Yii::$app->params['client']['between24hour'];
                        if (\yii::$app->user->id != $request->to_id) {
                            $peerRefundPercent = \Yii::$app->params['peer']['between24hour'];
                            try{
                                \Yii::$app->mailer->compose(['html' => 'client-cancelled-placed-client-24-12'], ['request' => $request])
                                    ->setFrom([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
                                    ->setTo($request->from->email)
                                    ->setSubject('Case cancelled ' . \Yii::$app->name)
                                    ->send();

                                \Yii::$app->mailer->compose(['html' => 'client-cancelled-placed-peer-24-12'], ['request' => $request])
                                    ->setFrom([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
                                    ->setTo($request->to->email)
                                    ->setSubject('Case cancelled ' . \Yii::$app->name)
                                    ->send();
                            }catch (\Exception $e){
        
                            }       
                        } else {
                            $banAttorney = 1;
                            $peerRefundPercent = 0;
                            try{
                                \Yii::$app->mailer->compose(['html' => 'peer-cancelled-client-24-12'], ['request' => $request])
                                    ->setFrom([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
                                    ->setTo($request->from->email)
                                    ->setSubject('Case cancelled ' . \Yii::$app->name)
                                    ->send();

                                \Yii::$app->mailer->compose(['html' => 'peer-cancelled-peer-24-12'], ['request' => $request])
                                    ->setFrom([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
                                    ->setTo($request->to->email)
                                    ->setSubject('Case cancelled ' . \Yii::$app->name)
                                    ->send();
                            }catch (\Exception $e){
        
                            }
                        }
                    } else {
                        $clientRefundPercent = \Yii::$app->params['client']['lessthen12hour'];

                        if (\yii::$app->user->id != $request->to_id) {
                            $peerRefundPercent = \Yii::$app->params['peer']['lessthen12hour'];
                            try{
                                \Yii::$app->mailer->compose(['html' => 'client-cancelled-placed-client-12'], ['request' => $request])
                                    ->setFrom([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
                                    ->setTo($request->from->email)
                                    ->setSubject('Case cancelled ' . \Yii::$app->name)
                                    ->send();

                                \Yii::$app->mailer->compose(['html' => 'client-cancelled-peer-12'], ['request' => $request])
                                    ->setFrom([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
                                    ->setTo($request->to->email)
                                    ->setSubject('Case cancelled ' . \Yii::$app->name)
                                    ->send();
                            }catch (\Exception $e){
        
                            }
                        } else {
                            $banAttorney = 1;
                            $peerRefundPercent = 0;
                            try{
                                \Yii::$app->mailer->compose(['html' => 'peer-cancelled-client-12'], ['request' => $request])
                                    ->setFrom([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
                                    ->setTo($request->from->email)
                                    ->setSubject('Case cancelled ' . \Yii::$app->name)
                                    ->send();

                                \Yii::$app->mailer->compose(['html' => 'peer-cancelled-peer-12'], ['request' => $request])
                                    ->setFrom([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
                                    ->setTo($request->to->email)
                                    ->setSubject('Case cancelled ' . \Yii::$app->name)
                                    ->send();
                            }catch (\Exception $e){
        
                            }
                        }
                    }
                    if($clientRefundPercent == 100){
                        $clientRefundAmount = $request->transactions->amount / 100 * $clientRefundPercent;
                    }else{
                        $clientRefundAmount = Transactions::calculateCommitionedAmount( $request->transactions->commition, $request->transactions->amount) / 100 * $clientRefundPercent;
                    }
                    $peerRefundAmount = Transactions::calculateCommitionedAmount($request->transactions->commition, $request->transactions->amount) / 100 * $peerRefundPercent;
                    // end case cancel refund amount

                    if (\yii::$app->user->id == $request->from_id) {

                        $cancelRequestModel = new CaseCancelledRequest();
                        $cancelRequestModel->request_id = $request->id;
                        $cancelRequestModel->client_amount = number_format((float) $clientRefundAmount, 2, '.', '');
                        $cancelRequestModel->peer_amount = number_format((float) $peerRefundAmount, 2, '.', '');
                        $cancelRequestModel->save(false);

                        $to_user_id = $request->to_id;
                    } else {
                        $repostCase = RepostCases::find()->where(['request_id' => $request->id])->one();
                        if (empty($repostCase)) {
                            $repostModel = new RepostCases();
                            $repostModel->user_id = \yii::$app->user->id;
                            $repostModel->request_id = $request->id;
                            if ($repostModel->save(false)) {
                                $request->to_id = '';
                                $request->cancelled_by = "";
                                $request->status = "active";
                                if ($request->save(false)) {
                                    $user_data = User::userDataForNotification(\yii::$app->user->id);
                                    $hearingType = HearingType::find()->where(['id' => $request->hearing_type_id])->one();
                                    $title = $hearingType->name . ' Case Request';

                                    $to_users = User::find()->select('user.id,user.notification')->join('left join', 'hearing_detail', 'user.id=hearing_detail.user_id')
                                                    ->where(['AND', ['hearing_detail.hearing_type' => $request->hearing_type_id], ['NOT IN', 'user.id', [$request->from_id, $repostModel->user_id]], ['user.status' => 'active'], ['user.is_available' => 1]])->all();

                                    $type = 'new_case_request';

                                    $message = 'You have received new ' . $title . ' on ' . date('jS F Y', strtotime($request->case_date));

                                    $notification_data = ['title' => $title, 'type' => $type, 'from_id' => $request->to_id, 'to_id' => $request->from_id, 'user_name' => $user_data['user_name'],
                                        'profile_image' => $user_data['profile_image'], 'request_id' => $request->id];
                                    if (!empty($to_users)) {
                                        foreach ($to_users as $user) {
                                            $notification_data['notification_receive_status'] = $user['notification'];
                                            $to_user_device_type = UserDevices::find()->where(['user_id' => $user['id']])->one();
                                            Notification::saveNotification(['to_id' => [$user['id']], 'from_id' => \yii::$app->user->id, 'type' => $type, 'message' => $message, 'request_id' => $request->id, 'notification_data' => json_encode($notification_data)]);
                                            if ($user['notification'] == 'disable') {
                                                $notification_data['unread_notification_count'] = Notification::newNotification($user['id']);
                                                \api\components\Utility::sendWithoutAlertMessagePushNotification($user['id'], $message, $notification_data);
                                            }
                                            if ($user['notification'] == 'enable') {
                                                $notification_data['unread_notification_count'] = Notification::newNotification($user['id']);
                                                \api\components\Utility::sendMessagePushNotification($user['id'], $message, $notification_data);
                                            }
                                        }
                                    }
                                }
                            }
                        } else {
                            $cancelRequestModel = new CaseCancelledRequest();
                            $cancelRequestModel->request_id = $request->id;
                            $cancelRequestModel->client_amount = number_format((float) $clientRefundAmount, 2, '.', '');
                            $cancelRequestModel->peer_amount = number_format((float) $peerRefundAmount, 2, '.', '');
                            $cancelRequestModel->save(false);
                        }
                        $to_user_id = $request->from_id;
                    }

                    $user_data = User::userDataForNotification(\yii::$app->user->id);
                    $to_user = User::find()->select('user.id,user.notification')->where(['AND', ['=', 'user.id', $to_user_id], ['OR',['user.status' => 'active'],['user.status' => 'banned']], ['user.is_available' => 1]])->one();
                    $type = 'cancelled_case_request';
                    $message = 'Case cancelled by ' . $user_data['user_name'];

                    $notification_data = ['title' => '',
                        'type' => $type,
                        'from_id' => $request->to_id,
                        'to_id' => $request->from_id,
                        'user_name' => $user_data['user_name'],
                        'profile_image' => $user_data['profile_image'],
                        'request_id' => $request->id,
                        'request_description' => $request->description,
                        'case_id' => $request->case_id,
                        'case_date' => $request->case_date,
                        'case_time' => $request->case_time,
                        'notification_receive_status' => $to_user->notification,
                    ];
                    if (!empty($to_user)) {
                        Notification::saveNotification(['to_id' => [$to_user_id], 'request_id' => $request->id, 'from_id' => \yii::$app->user->id, 'type' => $type, 'message' => $message, 'notification_data' => json_encode($notification_data)]);
                        $to_user_device_type = UserDevices::find()->where(['user_id' => $to_user_id])->one();
                        if ($to_user->notification == 'disable') {
                            $notification_data['unread_notification_count'] = Notification::newNotification($to_user_id);
                            \api\components\Utility::sendWithoutAlertMessagePushNotification($to_user_id, $message, $notification_data);
                        }
                        if ($to_user->notification == 'enable') {
                            $notification_data['unread_notification_count'] = Notification::newNotification($to_user_id);
                            \api\components\Utility::sendMessagePushNotification($to_user_id, $message, $notification_data);
                        }
                    }
                }

                if ($post['status'] == 'cancelled' && \yii::$app->user->id == $request->from_id && $request->to_id == '' && empty($repost)) {

                    Notification::deleteAll(['request_id' => $post['request_id']]);

                    // get case refund amount
                    $requestClient = $request->from_id;
                    $requestUser = $request->to_id;
                    $loggedUserID = \yii::$app->user->id;
                    $requestDateTime = $request->case_date . ' ' . $request->case_time;
                    $currentDateTime = date('Y-m-d H:i:s');
                    $currentDateTime = Utility::getDateByTimezone($post['timezone'], $currentDateTime);
                    $datetime1 = new \DateTime($requestDateTime);
                    $datetime2 = new \DateTime($currentDateTime);
                    $difference = $datetime1->diff($datetime2);
                    $repost = RepostCases::findOne(['request_id' => $request->id]);
                    if ($difference->days > 0) {
                        $hours = $difference->days * 24;
                    } else {
                        $hours = $difference->h;
                    }
                    if ($hours >= 24) {
                        if (!empty($repost)) {
                            $clientRefundPercent = 50;
                        } else {
                            $clientRefundPercent = \Yii::$app->params['client']['before24hour'];
                        }
                        $peerRefundPercent = 0;
                        try{
                            \Yii::$app->mailer->compose(['html' => 'client-cancelled-client-24'], ['request' => $request])
                                ->setFrom([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
                                ->setTo($request->from->email)
                                ->setSubject('Case cancelled ' . \Yii::$app->name)
                                ->send();
                        }catch (\Exception $e){
        
                        }
                        if (!empty($request->to->email)) {
                            try{
                                \Yii::$app->mailer->compose(['html' => 'client-cancelled-peer-24'], ['request' => $request])
                                    ->setFrom([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
                                    ->setTo($request->to->email)
                                    ->setSubject('Case cancelled ' . \Yii::$app->name)
                                    ->send();
                            }catch (\Exception $e){
        
                            }
                        }
                    } elseif ($hours < 24 && $hours > 12) {
                        if (!empty($repost)) {
                            $clientRefundPercent = 50;
                        } else {
                            $clientRefundPercent = 100;
                        }
                        $peerRefundPercent = 0;
                        try{
                            \Yii::$app->mailer->compose(['html' => 'client-cancelled-client-24-12'], ['request' => $request])
                                ->setFrom([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
                                ->setTo($request->from->email)
                                ->setSubject('Case cancelled ' . \Yii::$app->name)
                                ->send();
                        }catch (\Exception $e){
        
                        }
                        if (!empty($request->to->email)) {
                            try{
                                \Yii::$app->mailer->compose(['html' => 'client-cancelled-peer-24-12'], ['request' => $request])
                                    ->setFrom([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
                                    ->setTo($request->to->email)
                                    ->setSubject('Case cancelled ' . \Yii::$app->name)
                                    ->send();
                            }catch (\Exception $e){
        
                            }
                        }
                    } else {
                        if (!empty($repost)) {
                            $clientRefundPercent = 50;
                        } else {
                            $clientRefundPercent = 50;
                        }
                        $peerRefundPercent = 0;
                        try{
                            \Yii::$app->mailer->compose(['html' => 'client-cancelled-client-12'], ['request' => $request])
                                ->setFrom([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
                                ->setTo($request->from->email)
                                ->setSubject('Case cancelled ' . \Yii::$app->name)
                                ->send();
                        }catch (\Exception $e){
        
                        }
                        if (!empty($request->to->email)) {
                            try{
                                \Yii::$app->mailer->compose(['html' => 'client-cancelled-peer-12'], ['request' => $request])
                                    ->setFrom([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
                                    ->setTo($request->to->email)
                                    ->setSubject('Case cancelled ' . \Yii::$app->name)
                                    ->send();
                            }catch (\Exception $e){
        
                            }
                        }
                    }

                    if($clientRefundPercent == 100){
                        $clientRefundAmount = $request->transactions->amount / 100 * $clientRefundPercent;
                    }else{
                        $clientRefundAmount = Transactions::calculateCommitionedAmount( $request->transactions->commition, $request->transactions->amount) / 100 * $clientRefundPercent;
                    }
                    $peerRefundAmount = Transactions::calculateCommitionedAmount($request->transactions->commition, $request->transactions->amount) / 100 * $peerRefundPercent;
                    // end case cancel refund amount

                    $cancelRequestModel = new CaseCancelledRequest();
                    $cancelRequestModel->request_id = $request->id;
                    $cancelRequestModel->client_amount = number_format((float) $clientRefundAmount, 2, '.', '');
                    $cancelRequestModel->peer_amount = number_format((float) $peerRefundAmount, 2, '.', '');
                    $cancelRequestModel->save(false);
                }

                if ($post['status'] == 'cancelled' && \yii::$app->user->id == $request->from_id && $request->to_id == '' && !empty($repost)) {

                    Notification::deleteAll(['request_id' => $post['request_id']]);

                    // get case refund amount
                    $requestClient = $request->from_id;
                    $requestUser = $request->to_id;
                    $loggedUserID = \yii::$app->user->id;
                    $requestDateTime = $request->case_date . ' ' . $request->case_time;
                    $currentDateTime = date('Y-m-d H:i:s');
                    $currentDateTime = Utility::getDateByTimezone($post['timezone'], $currentDateTime);
                    $datetime1 = new \DateTime($requestDateTime);
                    $datetime2 = new \DateTime($currentDateTime);
                    $difference = $datetime1->diff($datetime2);
                    $repost = RepostCases::findOne(['request_id' => $request->id]);
                    if ($difference->days > 0) {
                        $hours = $difference->days * 24;
                    } else {
                        $hours = $difference->h;
                    }
                    if ($hours >= 24) {
                        $clientRefundPercent = 50;
                        $peerRefundPercent = 0;
                        try{
                            \Yii::$app->mailer->compose(['html' => 'client-cancelled-client-24-regenerated'], ['request' => $request])
                                ->setFrom([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
                                ->setTo($request->from->email)
                                ->setSubject('Case cancelled ' . \Yii::$app->name)
                                ->send();
                        }catch (\Exception $e){
        
                        }
                    } elseif ($hours < 24 && $hours > 12) {
                        $peerRefundPercent = 0;
                        $clientRefundPercent = 50;
                        try{
                            \Yii::$app->mailer->compose(['html' => 'client-cancelled-client-24-12-regenerated'], ['request' => $request])
                                ->setFrom([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
                                ->setTo($request->from->email)
                                ->setSubject('Case cancelled ' . \Yii::$app->name)
                                ->send();
                        }catch (\Exception $e){
        
                        }
                    } else {
                        $clientRefundPercent = 50;
                        $peerRefundPercent = 0;
                        try{
                            \Yii::$app->mailer->compose(['html' => 'client-cancelled-client-12-regenerated'], ['request' => $request])
                                ->setFrom([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
                                ->setTo($request->from->email)
                                ->setSubject('Case cancelled ' . \Yii::$app->name)
                                ->send();
                        }catch (\Exception $e){
        
                        }
                    }

                    if($clientRefundPercent == 100){
                        $clientRefundAmount = $request->transactions->amount / 100 * $clientRefundPercent;
                    }else{
                        $clientRefundAmount = Transactions::calculateCommitionedAmount( $request->transactions->commition, $request->transactions->amount) / 100 * $clientRefundPercent;
                    }
                    $peerRefundAmount = Transactions::calculateCommitionedAmount($request->transactions->commition, $request->transactions->amount) / 100 * $peerRefundPercent;
                    // end case cancel refund amount

                    $cancelRequestModel = new CaseCancelledRequest();
                    $cancelRequestModel->request_id = $request->id;
                    $cancelRequestModel->client_amount = number_format((float) $clientRefundAmount, 2, '.', '');
                    $cancelRequestModel->peer_amount = number_format((float) $peerRefundAmount, 2, '.', '');
                    $cancelRequestModel->save(false);
                }
            }
            if ($banAttorney) {
                User::updateAll(['status' => 'banned'], ['id' => $login_user]);
                $user = User::find()->where(['id' => $login_user])->one();
                try{
                    \Yii::$app->mailer->compose(['html' => 'banned-attorney'], ['request' => $request])
                        ->setFrom([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
                        ->setTo($request->to->email)
                        ->setSubject('You are banned from ' . \Yii::$app->name)
                        ->send();
                }catch (\Exception $e){
        
                }
            }
            $response = array('user' => array('status' => $user->status));
            return $response;
        }return false;
    }

    public static function findAllRunningCase ($customer_id)
    {
        $case_detail = [];
        $array = [];
        $all_cases = self::find()->where(['AND', ['OR', ['=', 'from_id', \yii::$app->user->id], ['=', 'to_id', \yii::$app->user->id]],
                    ['OR', ['=', 'from_id', $customer_id], ['=', 'to_id', $customer_id]],
                    ['=', 'status', 'accepted']])->orderBy('id DESC')->all();
        if (!empty($all_cases)) {
            foreach ($all_cases as $value) {
                $case_detail['case_id'] = $value['case_id'];
                $case_detail['request_id'] = $value['id'];
                $array [] = $case_detail;
            }
        }
        return $array;
    }

    public static function findDashBoardDetail ()
    {

        $result = [];
        $cases = User::find()->select('user.id,user.first_name,user.last_name,user.email,user.bar_number,COUNT(case_request.from_id) as apeerances')->join('left join', 'case_request', 'user.id=case_request.from_id')
                        ->where(['user.role' => 'user'])->groupBy('case_request.from_id')->orderBy('case_request.created_at DESC')->limit(5)->all();
        $attornys = User::find()->where(['AND',['=','role','user'],['=','approved','no'],['=','profile_completed','yes']])->orderBy('created_at DESC')->limit(5)->all();
        $result['apeerances'] = $cases;
        $result['attornys'] = $attornys;
        $result['apeerance_count'] = self::apeeranceCount();
        $result['attorny_count'] = self::attornyCount();
        $result['total_payment_received'] = Transactions::totalPaymentReceived();
        $result['total_payment_sent'] = Transactions::totalPaymentSent();
        return $result;
    }

    public static function apeeranceCount ()
    {
        return $apeerances = CaseRequest::find()->count();
    }

    public static function attornyCount ()
    {
        return $attorny_count = User::find()->where(['AND',['!=', 'status', 'deleted'],['=', 'role', 'user']])->count();
    }

    public static function apeeranceList ($post)
    {
        $cases = User::find()->select('user.id,user.first_name,user.last_name,user.email,user.bar_number,COUNT(case_request.from_id) as apeerances')->join('left join', 'case_request', 'user.id=case_request.from_id')
                        ->where(['user.role' => 'user'])->groupBy('case_request.from_id')->orderBy('case_request.created_at DESC');
        if (!empty($post)) {
            if (!empty($post['name'])) {
                $cases->andWhere(['like', 'concat(user.first_name," ",user.last_name)', $post['name']]);
            }
            if (!empty($post['email'])) {
                $cases->andWhere(['=', 'user.email', $post['email']]);
            }
            if (!empty($post['unique_id'])) {
                $cases->andWhere(['=', 'user.id', $post['unique_id']]);
            }
        }
        if (!empty($cases)) {
            $provider = new ActiveDataProvider([
                'query' => $cases,
                'pagination' => [
                    'pageSize' => 10,
                ],
            ]);

            return $provider;
        }
    }

    public static function attorneyCases ()
    {
        $post = \yii::$app->request->get();
        $model = CaseRequest::find()->where(['from_id' => $post['id']])->orderBy('created_at DESC');
        if (!empty($post['case_id'])) {
            $model->andWhere(['case_id' => $post['case_id']]);
        }
        if (!empty($model)) {
            $provider = new ActiveDataProvider([
                'query' => $model,
                'pagination' => [
                    'pageSize' => 5,
                ],
            ]);
            return $provider;
        }
    }

    public static function caseCancelMessage ($post)
    {
        $request = self::find()->where(['AND', ['=', 'id', $post['request_id']], ['OR', ['=', 'status', 'accepted'], ['=', 'status', 'active']]])->one();
        if (!empty($request)) {
            $requestClient = $request->from_id;
            $requestUser = $request->to_id;
            $loggedUserID = \yii::$app->user->id;
            $requestDateTime = $request->case_date . ' ' . $request->case_time;
            $currentDateTime = date('Y-m-d H:i:s');
            $currentDateTime = Utility::getDateByTimezone($post['timezone'], $currentDateTime);
            $datetime1 = new \DateTime($requestDateTime);
            $datetime2 = new \DateTime($currentDateTime);
            $difference = $datetime1->diff($datetime2);
            $repost = RepostCases::findOne(['request_id' => $request->id]);
            $message = '';
            if ($difference->days > 0) {
                $hours = $difference->days * 24;
            } else {
                $hours = $difference->h;
            }

            if ($hours >= 24) {
                if ($requestClient == $loggedUserID) {
                    if (!empty($repost)) {
                        $message = 'You will receive a 100% refund, subject to any processing fees';
                    } else {
                        //not placed
                        $message = 'You will receive a 100% refund, subject to any processing fees';
                    }
                } elseif ($requestUser == $loggedUserID) {
                    $message = 'The attorney is counting on you, <a href="' . Yii::$app->urlManagerFrontEnd->createAbsoluteUrl("site/cancellation-policy") . '">are you sure you want to cancel?</a>';
                }
            } elseif ($hours < 24 && $hours > 12) {
                if ($requestClient == $loggedUserID) {
                    if (!$request->to_id) {
                        if (!empty($repost)) {
                            $message = 'We have not placed your case and therefore you will be refunded.';
                        } else {
                            //not placed
                            $message = 'We have not placed your case and therefore you will be refunded.';
                        }
                    } else {
                        //plced case
                        $message = 'Your cancellation at this late time will result in a 50% refund.';
                    }
                } elseif ($requestUser == $loggedUserID) {
                    $message = 'Your cancellation will ban you from Courtpals <a href="' . Yii::$app->urlManagerFrontEnd->createAbsoluteUrl("site/cancellation-policy") . '">subject to our terms and conditions.</a>';
                }
            } else {
                if ($requestClient == $loggedUserID) {
                    if (!$request->to_id) {
                        if (!empty($repost)) {
                            $message = 'There is no refund for a cancellation with less than 12 hours notice.';
                        } else {
                            //not placed
                            $message = 'We have not placed your case and therefore you will be refunded.';
                        }
                    } else {
                        //plced case
                        $message = 'There is no refund for a cancellation with less than 12 hours notice.';
                    }
                } elseif ($requestUser == $loggedUserID) {
                    $message = '<a href="' . Yii::$app->urlManagerFrontEnd->createAbsoluteUrl("site/cancellation-policy") . '">Your cancellation will ban you from Courtpals subject to our terms and conditions.</a>';
                }
            }
            return $message;
        }
        return false;
    }

    public static function cancelPastRequest ()
    {
        $pastCases = self::find()->where(['=', 'status', 'active'])->all();

        if (!empty($pastCases)) {
            foreach ($pastCases as $request) {
                $timezone = ($request->timezone) ? $request->timezone : Yii::$app->getTimeZone();
                $caseDateTime = $request->case_date . ' ' . $request->case_time;
                $todayDate = Utility::getDateByTimezone($timezone, date('Y-m-d H:i:s'));
                if ($caseDateTime < $todayDate) {
                    $request->status = "cancelled";
                    if ($request->save(false)) {
                        $param = array(
                            "client_amount" => $request->transactions->amount,
                            "peer_amount" => 0,
                            "transaction_id" => $request->transactions->transaction_id,
                            "request_id" => $request->id,
                            "client_id" => $request->from_id,
                            "ccr_id" => 0,
                        );
                        \backend\models\Refund::processRefund($param);
                    }

                    Notification::deleteAll([['=','request_id', $request->id],['=','type', 'refund_processed']]);
                }
            }
            return true;
        }
        return false;
    }

    public static function deletePastCase ()
    {


        $pastCase = self::find()->all();
        foreach ($pastCase as $case) {
            if (!empty($case->timezone)) {
                $serverTimezone = \Yii::$app->getTimeZone();
                $fromDate = new \DateTime(date('Y-m-d H:i:s'), new \DateTimeZone($serverTimezone));
                $fromDate->setTimeZone(new \DateTimeZone($case->timezone));
                $current_time = $fromDate->format('H:i:s');
                $current_date = $fromDate->format('Y-m-d');
            }
            if (($case->case_date < $current_date) || ($case->case_date == $current_date && $case->case_time < $current_time)) {
                $notification = Notification::find()->where(['=', 'request_id', $case->id])->one();
                $case->status = "cancelled";

                if (!empty($notification)) {
                    Notification::deleteAll(['request_id' => $case->id, 'type' => 'new_case_request']);
                }
                if (empty($case->to_id)) {
                    $check_notification = Notification::find()->where(['request_id' => $case->id, 'type' => 'self_cancel', 'to_id' => $case->from_id])->one();
                    if ((($current_date = $case->case_date && $current_time > $case->case_time) || $current_date > $case->case_date) && empty($check_notification)) {

                        $case->save(false);
                        $message = "your request has been cancellled";
                        $type = "self_cancel";
                        $user_data = User::find()->where(['role' => 'admin'])->one();
                        $to_user = User::find()->where(['id'=>$case->from_id])->one();
                        $profileImage = \common\components\Utility::getUserImage($user_data->id);
                        $notification_data = [
                            'type' => $type,
                            'from_id' => $user_data->id,
                            'to_id' => $case->from_id,
                            'user_name' => $user_data->first_name . " " . $user_data->last_name,
                            'profile_image' => $profileImage,
                            'request_id' => $case->id,
                            'notification_receive_status' => $to_user->notification
                        ];
                         Notification::saveNotification(['to_id' => [$case->from_id], 'request_id' => $case->id, 'from_id' => $user_data->id, 'type' => $type, 'message' => $message, 'notification_data' => json_encode($notification_data)]);
                        if ($to_user['notification'] == 'disable') {
                                                $notification_data['unread_notification_count'] = Notification::newNotification($to_user['id']);
                                                \api\components\Utility::sendWithoutAlertMessagePushNotification($to_user['id'], $message, $notification_data);
                         }
                         if ($to_user['notification'] == 'enable') {
                                                $notification_data['unread_notification_count'] = Notification::newNotification($to_user['id']);
                                                \api\components\Utility::sendMessagePushNotification($to_user['id'], $message, $notification_data);
                         }
                       
//                        \api\components\Utility::sendMessagePushNotification($case->from_id, $message, $notification_data);
                    }
                }
            }
        }
    }

}
