<?php

namespace common\models;

use Yii;
use yii\helpers\ArrayHelper;

/**
 * This is the model class for table "cities".
 *
 * @property integer $id
 * @property string $name
 * @property integer $state_id
 */
class Cities extends base\BaseCities
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'cities';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name', 'state_id'], 'required'],
            [['state_id'], 'integer'],
            [['name'], 'string', 'max' => 30],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'state_id' => 'State ID',
        ];
    }
    
    public static function getAllCities($country_id=231)
    {
        $cities = Cities::find()->select('cities.id,cities.name')->join('left join', 'states', 'states.id=cities.state_id')->join('left join', 'countries', 'states.country_id=countries.id')->where(['countries.id'=>$country_id])->all();
        return ArrayHelper::map($cities, 'id', 'name');
    }
    
    public static function getListOfCities($country_id=231)
    {
        $cities = Cities::find()->select('cities.id,cities.name')->join('left join', 'states', 'states.id=cities.state_id')->join('left join', 'countries', 'states.country_id=countries.id')->where(['countries.id'=>$country_id])->all();

        return $cities;
    }
    
}
