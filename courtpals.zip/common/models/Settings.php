<?php

namespace common\models;

use Yii;
use common\models\base\BaseSettings;

/**
 * This is the model class for table "settings".
 *
 * @property integer $id
 * @property string $key_name
 * @property string $value
 * @property string $created_at
 * @property string $updated_at
 */
class Settings extends BaseSettings {

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['created_at', 'updated_at','key_name'], 'safe'],
            [['key_value'], 'required'],
            [['key_value'],'match','pattern' => '/^[0-9]*(\.[0-9]+)?$/','message'=>"Please enter integer or float"],  
        ];
    }

    public function saveSettings($post) {
        $model = Settings::find()->where(['id'=>$post['id']])->one();
        $model->key_value = $post['key_value'];
        if($model->save()) {
            return true;
        } else {
            return false;
        }
    }
    
    public static function getCommissionFromSettings(){
        $model = Settings::find()->where(['key_name'=>'commission'])->one();
        return $model->key_value;
    }
}
