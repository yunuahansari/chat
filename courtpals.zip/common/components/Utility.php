<?php

namespace common\components;

use yii;
use yii\web\Response;
use yii\db\Query;

final class Utility {

    public static function generateAccessCode() {
        return Yii::$app->security->generateRandomString() . '_' . time();
    }

    public static function getUserImage($id) {
        $image = '';
        $user = \api\models\User::getUserByAttr(['id' => $id]);
        if (!empty($user)) {
            $image_name = $user->profile_pic;
            if (file_exists('../../api/web/upload/user/profile/' . $image_name) && $image_name != '') {
                $image = Yii::getAlias('@user_image_url') . '/' . $image_name;
            } else if ($image_name != '' && !empty($user->auths)) {
                $image = $user->profile_pic;
            } else {
                $image = Yii::getAlias('@images_url') . '/default.png';
            }
        } else {
            $image = Yii::getAlias('@images_url') . '/default.png';
        }
        return $image;
    }

    public static function generateVerificationCode() {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $randomStr = substr(str_shuffle($characters), 0, 10);
        return $randomStr;
    }

    public static function getRealIpAddr() {
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            //to check ip is pass from proxy  
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else if ($_SERVER['SERVER_NAME'] == 'localhost') {
            $ip = '127.0.0.1';
        } else {
            $ip = $_SERVER['SERVER_ADDR'];
        }
        return $ip;
    }
    
    public static function flashMessage() {
       
        if (Yii::$app->session->hasFlash('success')) {
            ?>
            <script>
                $(document).ready(function() {
                    toastr.options.closeButton = true;
                    toastr.success("<?= Yii::$app->session->getFlash('success') ?>", "Success");
                });
            </script>
            <?php
        }
        if (Yii::$app->session->hasFlash('error')) {
            ?>
            <script>
                $(document).ready(function() {
                    toastr.options.closeButton = true;
                    toastr.error("<?= Yii::$app->session->getFlash('error') ?>", "Alert");
                });
            </script>
            <?php
        }
    }
    public static function GetConvertedTime($time,$timezone){
        
                $serverTimezone = \Yii::$app->getTimeZone();
                $fromDate = new \DateTime($time, new \DateTimeZone($serverTimezone));
                $fromDate->setTimeZone(new \DateTimeZone($timezone));
               return  $convertedTime = $fromDate->format('Y-m-d H:i:s');
    }
}
