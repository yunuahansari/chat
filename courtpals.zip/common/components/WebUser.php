<?php

namespace common\components;

use Yii;
use yii\web\User;

class WebUser extends User {
    
    public function isAdmin(){
            if(!empty(\Yii::$app->user->identity) && \Yii::$app->user->identity->role == 'admin')
                return true;
            else
                return false;
    }
    
    public function isUser(){
            if(!empty(\Yii::$app->user->identity) && \Yii::$app->user->identity->role == 'user')
                return true;
            else
                return false;
    }
    
}