<?php
namespace common\components;

class Translate { 

    var $translate_from; 
    var $translate_into; 
    var $debug; 

    function __construct($from , $to){ 

        $this->debug = 0; 


        ini_set("display_errors",$this->debug); 


        if(!$from){ 

            $this->translate_from = "en"; 

        }else{ 

            $this->translate_from = $from; 

        } 
         
        if(!$to){ 

            $this->translate_into = "it"; 


        }else{ 
             
            $this->translate_into = $to; 

        } 

    } 


    function TranslateUrl($word){ 


        if(!$word){ 

            die("you need to adda a translate word"); 
        } 


        $word = urlencode($word); 

        $url = "http://translate.google.com/?sl=". $this->translate_from ."&tl=". $this->translate_into ."&js=n&prev=_t&hl=it&ie=UTF-8&eotf=1&text=". $word .""; 


        return $url; 

    } 

    function get($word){ 

        
        $dom  = new \DOMDocument(); 
         
        $html =  $this->curl_download($this->TranslateUrl($word)); 
        
        $dom->loadHTML($html); 

        $xpath = new \DOMXPath($dom); 
         
        $tags = $xpath->query('//*[@id="result_box"]'); 
        
        foreach ($tags as $tag) { 
             
            $var = trim($tag->nodeValue); 

            if(!$var){ 
                $this->sendEmail(); 
            }else{ 

                return ($var); 

            } 
             
                   
        } 

    } 

   

    function curl_download($Url){ 
      
        
        if (!function_exists('curl_init')){ 
            
            if (function_exists('file_get_contents')){ 

                return file_get_contents($Url); 

            }else{ 

                die("Your server dosen't support curl or file get contents"); 

            } 

        } 
      
        
        $ch = curl_init(); 

        curl_setopt($ch, CURLOPT_URL, $Url); 
      
        
        curl_setopt($ch, CURLOPT_USERAGENT, "MozillaXYZ/1.0"); 
      
        curl_setopt($ch, CURLOPT_HEADER, 0); 
      
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
      
        curl_setopt($ch, CURLOPT_TIMEOUT, 10); 
      
        $output = curl_exec($ch); 
      
        curl_close($ch); 
      
        return $output; 
    } 


} 