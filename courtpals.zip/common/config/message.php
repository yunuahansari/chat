<?php
return [
    'En'=>[
    
        'signup_email_to_user'=>'',
  
        'busy_user'=>'Dear %s, whom calling you is buys wright now',
        'booking_email'=>'Hi %s,<br> Please find the booking details here:<br><br>•%s: %s <br>•Specialization:%s <br>• Time Slots:%s <br>• Amount:%s <br><br>',
        'user_ratting'=>'%s has left ratings & reviews on your profile',
        'incurrent_pass'=>'The current password is incorrect',
        'mismatch_pass'=>'The old and new password should not identical'
        
        
    ],
    'Ar'=>[
       
        'signup_email_to_user'=>'',
        'signup_email_to_consultant'=>'',
        'incurrent_pass'=>'كلمة المرور الحالية غير صحيحة',
        'mismatch_pass'=>'كلمة المرور القديمة والجديدة ليسوا متطابقين'
        

    ]
];
?>
