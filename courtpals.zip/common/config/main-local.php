<?php

return [
    'name' => 'Courtpals',
    'modules' => [
        'auth' => [
            'class' => 'frontend\modules\auth\AuthModule',
        ],
    ],
    'components' => [
        'db' => require(__DIR__ . '/../../common/config/database.php'),
        'mailer' => [
            'class' => 'yii\swiftmailer\Mailer',
            'viewPath' => '@common/mail',
//            'transport' => [
//                'class' => 'Swift_SmtpTransport',
//                'host' =>  'smtp.sendgrid.net',
//                'username' => 'apeerance-codiant',
//                //'password' => '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',
//                'password' => 'Apeerance12345',
//                'port' => '465',
//                'encryption' => 'ssl',
//                'streamOptions' => [
//                    'ssl' => [
//                        'verify_peer' => false,
//                        'allow_self_signed' => true
//                    ],
//                ],
//            ],
//            'transport' => [
//                'class' => 'Swift_SmtpTransport',
//                'host' =>  'smtp.mailgun.org',
//                'username' => 'postmaster@email.apeerance.com',
//                //'password' => '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',
//                'password' => '0851ae0bc25c4b0fc232e6819b7487af-833f99c3-81e1081c',
//                'port' => '587',
//                'encryption' => 'tls',
//                'streamOptions' => [
//                    'ssl' => [
//                        'verify_peer' => false,
//                        'allow_self_signed' => true
//                    ],
//                ],
//            ],
            'useFileTransport' => false,
        ],
        'session' => [
            'class' => 'yii\web\Session',
            'cookieParams' => ['httponly' => true, 'lifetime' => 3600 * 30 * 24 * 60 * 60],
            'timeout' => 3600 * 30 * 24 * 60 * 60,
            'useCookies' => true,
        ],
        'apns' => [
                    'class' => 'bryglen\apnsgcm\Apns',
                    'environment' => \bryglen\apnsgcm\Apns::ENVIRONMENT_SANDBOX,
                    'pemFile' => 'apnscert/apeerance_push.pem',
                    // 'retryTimes' => 3,
                    'options' => [
                        'sendRetryTimes' => 5
                    ]
                ],
        'gcm' => [
            'class' => 'bryglen\apnsgcm\Gcm',
// codiant           'apiKey' => 'AIzaSyDdNdaj-uiKkp2lcnDs4UnFsq5gfOMkvyY',
            'apiKey' => 'AIzaSyAhAMvNxA-_VRoCn5fRvgpDD15lRloXfjI',
        ],
        'user' => [
            'class' => 'common\components\WebUser',
            'identityClass' => 'common\models\User',
            'loginUrl' => ['/auth/login'],
        ],
        'request' => [
            'enableCsrfValidation' => false,
            'enableCsrfCookie' => false,
            'cookieValidationKey' => 'u3EUfh9N1GJoodoZ2rExif7CHxYDU5I4dfhg'
        ],
//        'urlManager' => [
//            'class' => 'yii\web\UrlManager',
//            'enablePrettyUrl' => true,
//            'showScriptName' => false,
//            'rules' => [
//                '<controller:\w+>/<action:\w+>' => '<controller>/<action>',
//                '<controller:\w+>/<action:\w+(-\w+)*>/<id:\d+>' => '<controller>/<action>',
//                '<module:\w+>/<controller:\w+>/<action:\w+(-\w+)*>/<id:\d+>' => '<module>/<controller>/<action>',
//            ],
//        ]
    ]
];
