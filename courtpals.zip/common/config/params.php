<?php

return [
    'adminEmail' => 'sachind@neuronsolutions.com',
    'supportEmail' => 'sachind@neuronsolutions.com',
    'user.passwordResetTokenExpire' => 3600,
    'loadMoreLimit' => 10,
    'defaultCommition'=>30,
    'stripe_secret_key' => 'sk_test_YgKUrVKz8tAZ9rDjde3Is31E',
    'client' => [
        'before24hour' => 100,
        'between24hour' => 50,
        'lessthen12hour' => 0,
    ],
    'peer' => [
        'before24hour' => 0,
        'between24hour' => 25,
        'lessthen12hour' => 50,
    ]
];
