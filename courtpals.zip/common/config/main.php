<?php
return [
    'vendorPath' => dirname(dirname(__DIR__)) . '/vendor',
    'components' => [
        'cache' => [
            'class' => 'yii\caching\FileCache',
        ],
        'log' => [
            'traceLevel' => YII_DEBUG ? 3 : 0,
            'flushInterval' => 1,
            'targets' => [
                [
                    'class' => 'yii\log\FileTarget',
                    'categories' => ['emails'],
                    'levels' => ['error', 'warning'],
                    'exportInterval' => 1,
                    'logFile' => '@app/runtime/logs/trace.log',
                ],
            ],
        ],
    ],
];
