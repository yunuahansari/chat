<?php
Yii::setAlias('common', dirname(__DIR__));
Yii::setAlias('api', dirname(dirname(__DIR__)) . '/api');
Yii::setAlias('frontend', dirname(dirname(__DIR__)) . '/frontend');
Yii::setAlias('backend', dirname(dirname(__DIR__)) . '/backend');
Yii::setAlias('console', dirname(dirname(__DIR__)) . '/console');
$baseurl='http://localhost/courtpals/';
Yii::setAlias('base_url',  $baseurl);
Yii::setAlias('images_url',  $baseurl.'images');
Yii::setAlias('profile_image',  $baseurl.'uploads/');
Yii::setAlias('media_url',  $baseurl.'api/web/uploads/media');
Yii::setAlias('upload_url',  $baseurl.'uploads');
Yii::setAlias('user_image_url',  $baseurl.'api/web/upload/user/profile');
Yii::setAlias('document_url',  $baseurl.'api/web/upload/document');
Yii::setAlias('service_image_url',  $baseurl.'api/web/uploads/services');
Yii::setAlias('message_file_url',  $baseurl.'api/web/uploads/user/messageFile');
Yii::setAlias('cv_url',  $baseurl.'api/web/uploads/user/cv');
Yii::setAlias('post_images',  $baseurl.'uploads/posts');
Yii::setAlias('js_url',  $baseurl.'frontend/web/js');
Yii::setAlias('css_url',  $baseurl.'frontend/web/css');

Yii::setAlias('frnt_image_url',  $baseurl.'frontend/web/images');
Yii::setAlias('frnt_video_url',  $baseurl.'frontend/web/video');