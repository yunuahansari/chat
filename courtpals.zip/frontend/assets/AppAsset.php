<?php

namespace frontend\assets;

use yii\web\AssetBundle;
use yii\web\View;
/**
 * Main frontend application asset bundle.
 */
class AppAsset extends AssetBundle
{
    public $basePath = '@webroot';
    public $baseUrl = '@web';
    public $css = [
        'css/themify-icons.css',
        'css/waves.min.css',
        'css/bootstrap.min.css',
        'css/font-awesome.min.css',
        'css/bootstrap-select.min.css',
        'css/custom.min.css',
        'css/toastr.min.css'
    ];
    public $js = [
       // 'js/jquery.min.js',
        'js/bootstrap.min.js',
        'js/waves.min.js',
        'js/bootstrap-select.min.js',
        'js/toastr.min.js',
        'js/authchoice.js'
    ];
    public $depends = [
        'yii\web\YiiAsset',
        //'yii\bootstrap\BootstrapAsset',
    ];
    public $jsOptions = array(
        'position' => View::POS_BEGIN
    );
}
