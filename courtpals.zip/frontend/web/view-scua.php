<?php include('include/header.php')?>
  <!-- left sidebar-->
  
<div class="maincontainer">
<div class="leftbar">
    <?php include('include/menu-admin.php')?>
  </div>
<!-- left sidebar--> 

<!-- right container -->
<div class="right-fullcontainer side-collapse-container">
    <div class="main-container p-l-0 manage_listingadd">
    <header class="top_header clearfix">
        <div class="col-lg-12">
        <h1>View S/C/U/A </h1>
        <div class="right-section hidden-xs">
            <ul class="nav nav-right ">
            <li> <a href="javascript:void(0);" data-toggle="modal" data-target="#settings"><i class="icon-setting"></i></a> </li>
            <li> <a href="index.php">Logout &nbsp; <i class="icon-logout"></i></a> </li>
          </ul>
          </div>
      </div>
      </header>
        
    <a href="manage-scua.php" class="back-btn"> <i class="fa fa-angle-left"></i>  Back</a>
               
    <div class="inner_section">
        <div class="row">
                <div class="col-md-12 col-sm-12 profile-info">
                    <div class="row">
                      
                      <div class="col-md-2 col-sm-2 student-profile-pic">
                         <img src="images/user7.jpg" class="img-thumbnail">
                      </div>
                        
                      <div class="col-md-10 col-sm-10">
                        <div class="table-responsive">
                          <table class="table table-bordered multide">
                            <tr>
                              <th>Name</th>
                              <th>Website</th>
                              <th>Email Address</th>
                            </tr>

                            <tr>
                              <td>Brian Inserra</td>
                              <td>Brian Inserra</td>
                              <td>abu@gmail.com</td>
                            </tr>
                          </table>
                        </div>
                      </div>
                </div>
                    
                    <!-- xxxxxxxxx -->
                    
                     <hr />


                    <div class="row">
                        <div class="col-md-2">
                          <div class="numbr">
                             <img src="images/post-event.png" alt="post-event" class="img-responsive">
                             <p>Number of Posted Events</p>
                            <span class="numbering">25</span>
                          </div>
                        </div>

                        <div class="col-md-2">
                          <div class="numbr">
                             <img src="images/post-moment.png" alt="post-moment" class="img-responsive">
                             <p>Number of posted Moments</p>
                            <span class="numbering">25</span>
                          </div>
                        </div>

                        <div class="col-md-2">
                          <div class="numbr">
                             <img src="images/post-update.png" alt="post-update" class="img-responsive">
                             <p>Number of posted Updates</p>
                            <span class="numbering">25</span>
                          </div>
                        </div>

                        <div class="col-md-2">
                          <div class="numbr">
                             <img src="images/post-news.png" alt="post-news" class="img-responsive">
                             <p>Number of posted News</p>
                            <span class="numbering">25</span>
                          </div>
                        </div>
                    </div>
                     
                 </div>
        </div>
    </div>
            
  </div>
  </div>
<?php include('include/footer.php')?>

<script>
$('#datetimepicker').datetimepicker({
      format: 'DD/MM/YYYY'
    });
	
	$('#datetimepicker1').datetimepicker({
      format: 'DD/MM/YYYY'
    });

</script>
