<?php

namespace frontend\modules\auth\controllers;

use Yii;
use common\models\LoginForm;
use \common\models\SignupForm;
use common\models\User;
use yii\widgets\ActiveForm;
use yii\web\Response;
use yii\filters\AccessControl;
use yii\web\Cookie;
use frontend\models\PasswordResetRequestForm;
use frontend\models\ResetPasswordForm;
use yii\base\InvalidParamException;

class AuthController extends \yii\web\Controller {

    // public $layout = 'main';
    public $enableCsrfValidation = false;

    public function behaviors() {
        return [
        ];
    }

    public function actionIndex() {
        return $this->render('index');
    }


    public function actionLoginForm() {
        $post = Yii::$app->request->post();
        $model = new LoginForm();
        if (!empty($post)) {
            if ($model->load($post)) {
                //For Ajax validation
                if (Yii::$app->request->isAjax) {
                    Yii::$app->response->format = Response::FORMAT_JSON;
                    return ActiveForm::validate($model); //Return errors
                }
                 $model->login();
                 $this->redirect(\Yii::$app->urlManager->createUrl("/"));
            }
        } else {
            return $this->renderAjax('_login_form', ['model' => $model]);
        }
    }

    public function actionLogout() {
        Yii::$app->user->logout();
        return $this->redirect(array('/'));
    }


    public function actionSignupForm() {
        $model = new SignupForm();
        $post = Yii::$app->request->post();
        if (!empty($post)) {
            if ($model->load($post)) {
                //For Ajax validation
                if (Yii::$app->request->isAjax) {
                    Yii::$app->response->format = Response::FORMAT_JSON;
                    return ActiveForm::validate($model); //Return errors
                }
                if ($model->signUp()) {
                    Yii::$app->session->setFlash('success', 'You have successfully signed up with Courtpals.A verification email has been sent to you.');
                    $this->redirect(\Yii::$app->urlManager->createUrl("/"));
                }
            }
        } else {
            return $this->renderAjax('_signup_form',['model'=> $model]);
       }
    }
    
     public function actionVerifyEmail() {
        $verified_code = Yii::$app->request->get('param');
        if (isset($verified_code) && !empty(trim($verified_code))) {
            $user = new User();
            $returndata = $user->verifyEmail($verified_code);
            if ($returndata == true) {
                Yii::$app->session->setFlash('success', 'Your Email is verifed now.');
            } else {
                Yii::$app->session->setFlash('error', 'Email is already verified');
            }
        }
        $this->redirect(\Yii::$app->urlManager->createUrl('/'));
    }
    
    /*
     * forget password 
     */

    public function actionForgotPasswordForm() {
        $data = Yii::$app->request->post();
        $model = new PasswordResetRequestForm();
        if ($model->load(Yii::$app->request->post())) {
            if (Yii::$app->request->isAjax) {
                    Yii::$app->response->format = Response::FORMAT_JSON;
                    return ActiveForm::validate($model); //Return errors
            }
            if ($model->sendEmail()) {
                Yii::$app->getSession()->setFlash('success', 'Request sent successfully ,Check your email for further instructions.');
                return $this->redirect(Yii::$app->urlManager->createUrl('/'));
            } else {
                Yii::$app->getSession()->setFlash('error', 'Sorry, we are unable to reset password for email provided.');
            }
        } else {
            return $this->renderAjax('_forget_password_form', ['model' => $model]);
        }
    }
    
    public function actionResetPassword($token) {
        try {
            $model = new ResetPasswordForm($token);
            
            if ($model->load(Yii::$app->request->post())) {
                if (Yii::$app->request->isAjax) {
                        Yii::$app->response->format = Response::FORMAT_JSON;
                        return ActiveForm::validate($model); //Return errors
                }
                if ($model->resetPassword()) {
                    Yii::$app->getSession()->setFlash('success', 'Password has been updated successfully.');
                    return $this->redirect(Yii::$app->urlManager->createUrl('/'));
                } else {
                    Yii::$app->getSession()->setFlash('error', 'Sorry, we are unable to reset password. Please try after some time.');
                    return $this->redirect(Yii::$app->urlManager->createUrl('/'));
                }
            }
            return $this->render('reset_password_form', ['model' => $model]);
        } catch (InvalidParamException $e) {
            Yii::$app->getSession()->setFlash('error', $e->getMessage());
            return $this->redirect(Yii::$app->urlManager->createUrl('/'));
        }
    }

    /*
     * change password
     */

    public function actionChangePassword($token) {
        $model = User::find()->where(['password_reset_token' => $token])->one();
        if (!empty($model)) {
            try {
                $model = new ResetPasswordForm($token);
            } catch (InvalidParamException $e) {
                throw new BadRequestHttpException($e->getMessage());
            }
            if ($model->load(Yii::$app->request->post()) && $model->validate() && $model->resetPassword()) {
                Yii::$app->getSession()->setFlash('success', 'Password has been changed.');
                return $this->redirect(\Yii::$app->urlManager->createUrl('/auth/login'));
            }
        } else {
            Yii::$app->getSession()->setFlash('alert', 'Your access token has expired');
            return $this->redirect(\Yii::$app->urlManager->createUrl('/auth/login'));
        }
        return $this->render('change_password', ['model' => $model]);
    }
    
}
