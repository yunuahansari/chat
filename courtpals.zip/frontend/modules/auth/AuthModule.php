<?php
namespace frontend\modules\auth;

class AuthModule extends \yii\base\Module
{
    public $controllerNamespace = 'frontend\modules\auth\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
