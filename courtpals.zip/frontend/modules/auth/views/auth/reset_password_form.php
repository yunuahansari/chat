<?php
use yii\widgets\ActiveForm;
?>
<div class="modal fade signup_modal reset_modal" tabindex="-1" role="dialog" data-backdrop="static" aria-labelledby="reset_modal" id="resetModal">

<div class="modal-dialog modal-lg" role="document">
    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <img src="<?php echo Yii::getAlias('@images_url'); ?>/close_icon.png" alt="close">
        </button>
            <div class="modal-content">
                <div class="modal-body clearfix">
                    <div class="col-lg-5 col-md-6 col-sm-12 col-xs-12 left_cnt p-0">
                        <div class="modal_header">
                            <img src="<?php echo Yii::getAlias('@images_url'); ?>/modal_logo.png" alt='logo' class="img-responsive center-block">
                            <p>PLEASE ENTER PASSWORD</p>
                        </div>
                        <div class="form_cnt">
                            <?php
                    $form = ActiveForm::begin(
                                    [
                                        'enableAjaxValidation' => true,
                                        'enableClientValidation' => false,
                                        'id' => 'reset-form',
                                        'options' => [
                                            'onsubmit' => '$(document).on("beforeSubmit","#reset-form", function () {
                                        $("#frgtBtn").attr("disabled",true);
                                        $("#sendLoader").show();
                                        });']
                    ]);
                    ?>
                    <div class="form-group input_item">
                        <?= $form->field($model, 'password')->passwordInput(['class' => 'form-control noradius input-lg', 'placeholder' => 'Password'])->label(false) ?>
                        <div class="input_icon email_icon">
                        </div>
                    </div>
                                <div class="form_footer">
                                    <button type="submit" class="btn btn-info login_btn" id="frgtBtn">SEND <i class="fa fa-spinner fa-pulse fa-1x" id="sendLoader" style="display: none"></i></button>
                                </div>
                            <?php ActiveForm::end(); ?>
                        </div>
                    </div>
                    <div class="right_cnt hidden-sm hidden-xs">
                    </div>
                </div>
            </div>
        </div>
</div>
<script>
$(document).ready(function(){
    $('#resetModal').modal('show');   
});
</script>