<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\base\view;
?> 
<div class="modal-dialog modal-lg" role="document">
    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <img src="<?php echo Yii::getAlias('@images_url'); ?>/close_icon.png" alt="close">
    </button>
    <div class="modal-content">
        <div class="modal-body p-0 clearfix">
            <div class="col-lg-5 col-md-6 col-sm-12 col-xs-12 left_cnt p-0">
                <div class="modal_header">
                    <img src="<?php echo Yii::getAlias('@images_url'); ?>/footer_logo.png" alt='logo' class="img-responsive center-block">
                    <p>PLEASE LOG IN TO GET STARTED</p>
                </div>
                <div class="form_cnt">
                    <?php
                    $form = ActiveForm::begin(
                                    [
                                        'enableAjaxValidation' => true,
                                        'enableClientValidation' => true,
                                        'id' => 'login-form',
                                        'options' => [
                                            'onsubmit' => '$(document).on("beforeSubmit","#login-form", function () {
                                        $(".submitBtn").attr("disabled",true);
                                        $("#sendLoader").show();
                                        });']
                    ]);
                    ?>
                    <div class="form-group input_item">
                        <?= $form->field($model, 'email')->textInput(['class' => 'form-control noradius input-lg', 'placeholder' => 'Email'])->label(false) ?>
                        <div class="input_icon email_icon">
                        </div>
                    </div>
                    <div class="form-group input_item">
                        <?= $form->field($model, 'password')->passwordInput(['class' => 'form-control noradius input-lg', 'placeholder' => 'Password'])->label(false); ?>
                        <div class="input_icon key_icon">
                        </div>
                    </div>
                    <div class="form_footer">
                        <!--<a href="#" class="forgot_password_btn" data-toggle='modal' data-target='.forget_modal' data-dismiss="modal" onclick="loadSignUpForm()">Forgot password?</a>-->
                        <a href="javascript:void(0)" class="forgot_password_btn" data-toggle='modal' data-dismiss="modal" onclick="loadForgotPasswordForm()">Forgot password?</a>
                        <button type="submit" class="btn btn-info login_btn" id="signupBtn">Log In <i class="fa fa-spinner fa-pulse fa-1x" id="sendLoader" style="display: none"></i></button>
                        
                        <div class="login_with">
                           <div class="devider clearfix">
                                    <img src="<?php echo Yii::getAlias('@images_url'); ?>/or.jpg" class="center-block img-responsive">
                           </div><br>

                            
                            <?= yii\authclient\widgets\AuthChoice::widget([
                                'baseAuthUrl' => ['/site/auth']])
                            ?>
                        </div>
                    </div>
<?php ActiveForm::end(); ?>
                </div>
                <div class="modal_footer">
                    DON’T HAVE ACCOUNT? <a href="javascript:void(0)" class="signup_btn" data-toggle='modal' onclick="loadSignUpForm()" data-dismiss="modal"> SIGN UP</a>
                </div>
            </div>
            <div class="right_cnt hidden-sm hidden-xs">
            </div>
        </div>
    </div>
</div>