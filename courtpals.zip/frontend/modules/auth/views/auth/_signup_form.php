<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\base\view;

?> 
<div class="modal-dialog modal-lg" role="document">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <img src="<?php echo Yii::getAlias('@images_url'); ?>/close_icon.png" alt="close">
        </button>
        <div class="modal-content">
            <div class="modal-body p-0 clearfix">
                <div class="col-lg-5 col-md-6 col-sm-12 col-xs-12 left_cnt p-0">
                    <div class="modal_header">
                        <img src="<?php echo Yii::getAlias('@images_url'); ?>/signup_logo.png" alt='logo' class="img-responsive center-block">
                        <p>PLEASE LOG IN TO GET STARTED</p>
                    </div>
                    <div class="form_cnt">
                        <?php
                     $form = ActiveForm::begin(
                                    ['id' => 'signUp',
                                        'enableAjaxValidation' => false,
                                        'enableClientValidation' => true,
                                        'options' => [
                                            'onsubmit' => '$(document).on("beforeSubmit","#signUp", function () {
                                        $(".submitBtn").attr("disabled",true);
                                        $("#loader").show();
                                        });']
                                    ]);
                         ?>
                            <div class="form-group input_item">
                                <?= $form->field($model, 'first_name')->textInput(['class' => 'form-control', 'placeholder' => 'First Name'])->label(false) ?>
                                <div class="input_icon user_icon">
                                </div>
                            </div>
                            <div class="form-group input_item">
                                <?= $form->field($model, 'last_name')->textInput(['class' => 'form-control', 'placeholder' => 'Last Name'])->label(false) ?>
                                <div class="input_icon user_icon">
                                </div>
                            </div>
                            <div class="form-group input_item">
                                <?= $form->field($model, 'email')->textInput(['class' => 'form-control', 'placeholder' => 'Email'])->label(false) ?>
                                <div class="input_icon email_icon">
                                </div>
                            </div>
                            <div class="form-group input_item">
                                <?= $form->field($model, 'password')->passwordInput(['class' => 'form-control', 'placeholder' => 'Password'])->label(false) ?>
                                <div class="input_icon key_icon">
                                </div>
                            </div>
                            <div class="form-group input_item">
                                <?= $form->field($model, 'confirm_password')->passwordInput(['class' => 'form-control', 'placeholder' => 'Confirm Password'])->label(false) ?>
                                <div class="input_icon key_icon">
                                </div>
                            </div>
                            <div class="form_footer">
                                <button type="submit" class="btn btn-info login_btn btn-block submitBtn">SIGN UP <i id="loader" style="display: none" class="fa fa-spin fa-spinner color-pink"></i></button>
                                <div class="devider clearfix">
                                    <img src="<?php echo Yii::getAlias('@images_url'); ?>/or.jpg" class="center-block img-responsive">
                                </div>
                                <div class="login_with">
                                    <?= yii\authclient\widgets\AuthChoice::widget([
                                                'baseAuthUrl' => ['/site/auth']])
                                    ?>
                                </div>
                            </div>
                            <?php ActiveForm::end(); ?>
                    </div>
                     <div class="modal_footer">
                      HAVE ACCOUNT? <a href="javascript:void(0)" class="signup_btn" data-toggle='modal' onclick="loadLoginForm()" data-dismiss="modal"> SIGN IN</a>
                     </div>
                </div>
                <div class="right_cnt hidden-xs hidden-sm">
                </div>
            </div>
        </div>
    </div>
<script>
$('#signUp').on('afterValidate', function (event, fields, errors) {
        if (errors.length > 0) {
            $('.submitBtn').attr('disabled',false);
        }
    });
    
  $('#signUp').on('beforeValidate', function (event, fields, errors) {
        $('.submitBtn').attr('disabled',true);
    });

</script>

