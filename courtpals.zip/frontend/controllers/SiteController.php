<?php

namespace frontend\controllers;

use Yii;
use yii\base\InvalidParamException;
use yii\web\BadRequestHttpException;
use yii\web\Controller;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;
use common\models\LoginForm;
use frontend\models\PasswordResetRequestForm;
use frontend\models\ResetPasswordForm;
use frontend\models\SignupForm;
use frontend\models\ContactForm;
use common\models\User;
use common\models\Auth;
use yii\base\ErrorException;
use common\models\ContactUs;
use api\models\signup\LinkedinSignup;
use common\models\StripeGateway;
use common\models\Settings;
use Zendesk\API\HttpClient as ZendeskAPI;

/**
 * Site controller
 */
class SiteController extends Controller {

    /**
     * @inheritdoc
     */
    public function behaviors() {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'only' => ['logout', 'signup'],
                'rules' => [
                    [
                        'actions' => ['signup'],
                        'allow' => true,
                        'roles' => ['?'],
                    ],
                    [
                        'actions' => ['logout'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'logout' => ['post'],
                ],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function actions() {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
            'captcha' => [
                'class' => 'yii\captcha\CaptchaAction',
                'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null,
            ],
            'auth' => [
                'class' => 'yii\authclient\AuthAction',
                'successCallback' => [$this, 'successCallback'],
            ],
        ];
    }

    /**
     * Displays homepage.
     *
     * @return mixed
     */
    public function actionIndex() {
        $model = new ContactUs();
        return $this->render('index', ['model' => $model]);
    }

    public function successCallback($client) {
        $attributes = $client->getUserAttributes();
        $connection = \Yii::$app->db;
        $transaction = $connection->beginTransaction();
        try {
            $userExist = Auth::find()->where(['source_id' => $attributes['id']])->one();
            if (!empty($userExist)) {
                $user = User::find()->where(['id' => $userExist->user_id])->one();
                $model = new LoginForm();
                $model->email = $user->email;
                $model->linkedInLogin();
                
            } else {
                $user = new User();
                $user->first_name = $attributes['first_name'];
                $user->last_name = $attributes['last_name'];
                $user->profile_pic = $attributes['public-profile-url'];
                $user->email = $attributes['email'];
                $user->type = 'linkedin';
                $user->status = 'active';
                $user->commition = Settings::getCommissionFromSettings();
                if ($user->save()) {
                    $customer = \common\models\StripeGateway::createCustomer(['email' => $user->email]);
                    if (!empty($customer) && $customer->id != '') {
                        User::updateAll(['stripe_customer_id' => $customer->id], ['id' => $user->id]);
                    }                   
                    $stripeAccount = \common\models\StripeGateway::createConnectAccount(['email' => $user->email]);
                    if (!empty($stripeAccount)) {
                        User::updateAll(['stripe_account_id' => $stripeAccount->id], ['id' => $user->id]);
                    }
                    // Save user LinkedId 
                    $auth = new Auth();
                    $auth->source_id = $attributes['id'];
                    $auth->user_id = $user->id;
                    $auth->save(false);
                    $hearing_types = \common\models\HearingType::find()->where(['status' => 'active','parent' => 0])->all();
                    if (!empty($hearing_types)) {
                        foreach ($hearing_types as $hearing_type) {
                            $hearingDetail = new \common\models\HearingDetail();
                            $hearingDetail->user_id = $user->id;
                            $hearingDetail->hearing_type = $hearing_type->id;
                            $hearingDetail->save(false);
                        }
                    }
                    $model = new LoginForm();
                    $model->email = $user->email;
                    $model->linkedInLogin();
                }
            }
            $transaction->commit();
            return true;
        } catch (ErrorException $e) {
            Yii::$app->session->setFlash('error', $e->getMessage());
            $transaction->rollBack();
            return false;
        }
    }

    /**
     * Logs in a user.
     *
     * @return mixed
     */
    public function actionLogin() {
        if (!Yii::$app->user->isGuest) {
            return $this->goHome();
        }

        $model = new LoginForm();
        if ($model->load(Yii::$app->request->post()) && $model->login()) {
            return $this->goBack();
        } else {
            return $this->render('login', [
                        'model' => $model,
            ]);
        }
    }

    /**
     * Logs out the current user.
     *
     * @return mixed
     */
    public function actionLogout() {
        Yii::$app->user->logout();

        return $this->goHome();
    }

    /**
     * Displays contact page.
     *
     * @return mixed
     */
    public function actionContact() {
        $model = new ContactForm();
        if ($model->load(Yii::$app->request->post()) && $model->validate()) {
            try{
                $post = Yii::$app->request->post('ContactForm');
                $data = array();
                $data['to'] = \Yii::$app->params['supportEmail'];
                $data['from'] = $post['email'];
                $data['subject'] = $post['subject'];
                $data['message'] = $post['body'];
                $transport = (new \Swift_SmtpTransport($post['host'], $post['port']))
                                                    ->setUsername($post['username'])
                                                    ->setPassword($post['password']);
                $mailer = new \Swift_Mailer($transport);
                $message = (new \Swift_Message($post['subject']))
                            ->setFrom([$post['email'] => $post['name']])
                            ->setTo([\Yii::$app->params['supportEmail'] => Yii::$app->name])
                            ->setBody($post['body']);

                          // Send the message
                    $numSent = $mailer->send($message);
                    if($numSent){
                        Yii::$app->session->setFlash('success', 'Thank you for contacting us. We will respond to you as soon as possible.');
                    }else{
                        Yii::$app->session->setFlash('error', 'Unable to send email!');
                    }
                }  catch (\Exception $e){
                    Yii::$app->session->setFlash('error', $e->getMessage());
                }
                return $this->refresh();
        } else {
            return $this->render('contact', [
                        'model' => $model,
            ]);
        }
    }

    public function actionAccountActivation() {
        $data = \yii::$app->request->get();
        $user = User::getUserByAttr(['verified_code' => $data['verified_code']]);
        if(!empty($user)){
            $user->status = 'active';
            $user->verified_code = '';

            if ($user->save(false)) {
                Yii::$app->session->setFlash('success', "Your account has been activated");
            }else{
                Yii::$app->session->setFlash('error', "Some thing went wrong when activating your account please try again after some time.");
            }
        }else{
            Yii::$app->session->setFlash('error', "Account is already activated or invalid verification code.");
        }
        return $this->goHome();
    }

    /**
     * Displays about page.
     *
     * @return mixed
     */
    public function actionAbout() {
        return $this->render('about');
    }

    /**
     * Signs user up.
     *
     * @return mixed
     */
    public function actionSignup() {
        $model = new SignupForm();
        if ($model->load(Yii::$app->request->post())) {
            if ($user = $model->signup()) {
                if (Yii::$app->getUser()->login($user)) {
                    return $this->goHome();
                }
            }
        }

        return $this->render('signup', [
                    'model' => $model,
        ]);
    }

    /**
     * Requests password reset.
     *
     * @return mixed
     */
    public function actionRequestPasswordReset() {
        $model = new PasswordResetRequestForm();
        if ($model->load(Yii::$app->request->post()) && $model->validate()) {
            if ($model->sendEmail()) {
                Yii::$app->session->setFlash('success', 'Check your email for further instructions.');

                return $this->goHome();
            } else {
                Yii::$app->session->setFlash('error', 'Sorry, we are unable to reset password for the provided email address.');
            }
        }

        return $this->render('requestPasswordResetToken', [
                    'model' => $model,
        ]);
    }

    /**
     * Resets password.
     *
     * @param string $token
     * @return mixed
     * @throws BadRequestHttpException
     */
    public function actionResetPassword($token) {
        try {
            $model = new ResetPasswordForm($token);
        } catch (InvalidParamException $e) {
            throw new BadRequestHttpException($e->getMessage());
        }

        if ($model->load(Yii::$app->request->post()) && $model->validate() && $model->resetPassword()) {
            Yii::$app->session->setFlash('success', 'New password saved.');

            return $this->goHome();
        }

        return $this->render('resetPassword', [
                    'model' => $model,
        ]);
    }

    public function actionAppearWithUs() {
        return $this->render('appearwithus');
    }

    public function actionCancellationPolicy() {
        return $this->render('cancellationpolicy');
    }
    public function actionPrivacyPolicy() {
        return $this->render('privacyPolicy');
    }
    public function actionTermsAndConditions() {
        return $this->render('termcondition');
    }
    

    public function actionContactUs() {

       
        $post = Yii::$app->request->post('ContactUs');
        $data = array();
        $data['to'] = \Yii::$app->params['supportEmail'];
        $data['from'] = $post['email'];
        $data['subject'] = $post['subject'];
        $data['message'] = $post['message'];
//      Yii::$app->mailer->compose(['html' => 'contactUsMail-html'], ['data' =>$data])
//                ->setFrom($data['from'])
//                ->setTo($data['to'])
//                ->setReplyTo([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
//                ->setSubject($data['subject'])
//                ->send();
        try {
            // $client = new ZendeskAPI(\Yii::$app->params['zendesk_subdomain']);
            // $client->setAuth('basic', ['username' => \Yii::$app->params['zendesk_username'], 'token' => \Yii::$app->params['zendesk_token']]);

            // $zendesk_user = $client->users()->createOrUpdate(['email' => $post['email'], 'name' => $post['email'], 'role' => 'end-user']);
            // $newTicket = $client->tickets()->create([
            //     'requester_id' => $zendesk_user->user->id,
            //     'submitter_id' => $zendesk_user->user->id,
            //     'subject' => $post['subject'],
            //     'comment' => ['body' => $post['message']],
            //     'priority' => 'normal'
            // ]);
            Yii::$app->session->setFlash('success', 'Your message was sent successfully.');
        } catch (\Exception $e) {
            echo "<pre>";
            print_r($e->getMessage());die;
            Yii::$app->session->setFlash('error', 'There is problem while submitting your request please try again after some time.');
        }
        $this->redirect(\Yii::$app->urlManager->createUrl("/"));
    }

}
