<?php

/* @var $this yii\web\View */
/* @var $form yii\bootstrap\ActiveForm */
/* @var $model \frontend\models\ContactForm */

use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
use yii\captcha\Captcha;

$this->title = 'Contact';
$this->params['breadcrumbs'][] = $this->title;
?>

<section class="contact_us section_pad" id="contact" data-anchor="contact">
    <div class="container">
        
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 left_cnt">
                <h2>Get in Touch</h2>
                <p>Got a question? Want to hear from us? 
                    Tell a bit about yourself and weâ€™ll get back to you as soon as we can.</p>
                <div class="info_item">
                    <div class="info_icon"><img src="<?php echo Yii::getAlias('@images_url'); ?>/mail_icon.png"></div>
                    <div class="info_text"><a href="mailto:support@courtpals.com">support@courtpals.com</a></div>
                </div>
                <div class="info_item">
                    <div class="info_icon"><img src="<?php echo Yii::getAlias('@images_url'); ?>/mobile_icon.png"></div>
                    <div class="info_text">510.952.PEER</div>
                </div>
                <div class="info_item">
                    <div class="info_icon"><img src="<?php echo Yii::getAlias('@images_url'); ?>/location_icon.png"></div>
                    <div class="info_text">237 Kearny Street #9187<br/> San Francisco California, 94108</div>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 right_cnt contact_form">
                <div class="form_box">
                    <div class="form_heading">
                        <h3>Email us</h3>
                    </div>
                        <div class="form_cnt">
                             <?php
                        $form = ActiveForm::begin(
                                        [ 'id' => 'contactUs',
                                            'action' => Yii::$app->urlManager->createUrl(['site/contact']),
                                            'enableAjaxValidation' => false,
                                            'enableClientValidation' => true,
                                            'options' => [
                                                'onsubmit' => '$(document).on("beforeSubmit","#contactUs", function () {
                                        $(".submitBtn").attr("disabled",true);
                                        $("#sendLoader").show();
                                        });']
                        ]);
                        ?>
                    
                    <?= $form->field($model, 'host')->textInput(['autofocus' => true]) ?>
                     
                    <?= $form->field($model, 'username')->textInput([]) ?>
                    <?= $form->field($model, 'password')->textInput([]) ?>
                    <?= $form->field($model, 'port')->textInput([]) ?>
                    <?= $form->field($model, 'encryption')->dropDownList(['tls' => 'tls','ssl' => 'ssl'],['class' => 'selectpicker form-control']) ?>
                    <?= $form->field($model, 'name')->textInput() ?>
                    <?= $form->field($model, 'email') ?>

                    <?= $form->field($model, 'subject') ?>

                    <?= $form->field($model, 'body')->textarea(['rows' => 6]) ?>

                    <div class="form-group">
                       <button class="btn btn-block btn-info submitBtn">SUBMIT<i class="fa fa-spinner fa-pulse fa-1x" id="sendLoader" style="display: none"></i></button>
                    </div>

                    <?php ActiveForm::end(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

