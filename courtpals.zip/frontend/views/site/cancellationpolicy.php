<?php $this->title = "Courtpals Contract Cancellation Policy" ?>
<main class="main inner_pages cacellation-page">
    <div class="container">
        <div class="static-page">
            <h1 class="text-center">Courtpals Contract Cancellation Policy</h1>
            <div class="para">
                <div class="ceation-heading">
                    <h2>All refunds are of course subject to any processing fees.</h2>
                    <h2>Unsuccessful contract completion of appearance prior to start of services</h2>
                    </div>
                </div>
                    <div class="para">
                        <p><strong><i>Canceling More than 24 Hours Before Courtpals</i></strong></p>
                        <p>If the pal initiates the cancellation, 100% refund to client will be provided, pal obviously gets nothing, and the client’s request will go back to the application to seek out a new pal to cover the matter.  </p>
                        <p>If matter cannot be re-placed, then 100% is refunded back to the client.</p>
                    </div>
                    <div class="para">
                    <p><strong><i>Canceling Less than 24 Hours But More than 12 Hours Before Schedule Courtpals</i></strong></p>
                    <p>If pal initiates the cancellation, pal will received no payment.  Pal will be banned from Courtpals indefinitely unless there is some legitimate, valid excuse for the failure to appear.</p>
                    <p>
                        Client’s request is placed back in the pool of requests and Courtpals attempts to re-place the case.  If the case cannot be re-placed, then 100% of the fee is refunded to client.</p>
                    <p>
                        If client initiates the cancellation, 50% refund will be provided.  If the case was placed with a pal attorney, Pal will receive 25% of the fee to be earned. If the case was not placed yet, the client will get 100% refund.</p>
                   </div>
                   <div class="para">
                       <p><strong><i>Canceling Less than 12 Hours Before</i></strong></p>
                    <p>
                        If pal initiates the cancellation, pal will received no payment.  Pal will be banned from Courtpals indefinitely unless there is some legitimate, valid excuse for the failure to appear.
                    </p>
                    <p>Client’s request is placed back in the pool of requests and Courtpals attempts to re-place the case.  If the case cannot be re-placed then 100% of the fee is refunded to client.</p>
                    <p>If client initiates the cancellation, no refund will be provided.  Pal will receive 50% of the fee to be earned. If case is not placed, the client will get 50% refund.</p>

                </div>
            
            <!-------------------------------------------------->
            <div class="para">
                <div class="ceation-heading">
                    <h3>Post completion/dissatisfied with the service refund procedure</h3>
                    <p>If you as the client are unsatisfied with the service you received, then during the review cycle, when 1 or 2 stars are given, you will be prompted to request refund.  At that point, the system will engage in an email exchange between the client and the pal to resolve the issue. </p>
                    <p>If a pal has completed the service, i.e., an appearance was made, then no guarantee of a refund can be promised.  As with all risks inherent to service transactions, there is a risk of poor performance that cannot be guaranteed.  Malpractice is covered by our malpractice policy.</p>
                </div>
            </div>
        </div>
    </div>
</main>