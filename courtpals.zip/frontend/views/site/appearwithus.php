<?php $this->title = "Appear With Us" ?>

                <section class="aap-feature">
                    <div class="container">
                        <div class="homepageheading">
                            <h2><span>App Feature</span></h2>
                            <p>Pellentesque in iHeading sum id orci porta dapibus uisque velit.</p>
                        </div>
                        <div class="row">

                            <div class="col-sm-4 col-xs-12">
                                <div class="content">
                                    <img src="<?php echo Yii::getAlias('@images_url'); ?>/feature-icon1.png" class="center-block img-responsive" alt="icon" />
                                    <h4>aap-feature</h4>
                                    <p>Trust verified pal attorneys to handle your court appearances</p>
                                </div>
                            </div>

                            <div class=" col-sm-4 col-xs-12">
                                <div class="content"> 
                                    <img src="<?php echo Yii::getAlias('@images_url'); ?>/feature-icon2.png" class="center-block img-responsive" alt="icon" />
                                    <h4>Pal Attorney</h4>
                                    <p>Pal attorneys are available on demand - verified and backed by malpractice insurance</p>
                                </div>
                            </div>

                            <div class=" col-sm-4 col-xs-12">
                                <div class="content">  
                                    <img src="<?php echo Yii::getAlias('@images_url'); ?>/feature-icon3.png" class="center-block img-responsive" alt="icon" />
                                    <h4>Simple & Secure</h4>
                                    <p>Pal attorneys securely handle hearings, communication is simple, and payments are safe</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>


                <section class="aboutus clearfix">
                    
                        <div class="col-md-6 pl-0 pr-0">
                            <div class="image">
                                <img src="<?php echo Yii::getAlias('@images_url'); ?>/about-us.jpg" class="img-responsive" alt="image" />
                            </div>
                        </div>
                        <div class="col-md-6 pl-0 pr-0 col-xs-12 ">
                            <div class="content"> 
                                <h2><span>About Us</span></h2>
                                <p>Courtpals believes that attorneys should work together and save time for their clients. The goal of Courtpals is to leverage special appearance attorneys for limited appearances.</p>
                                
                            </div>
                        </div>
                    
                </section>
