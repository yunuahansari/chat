<?php
/* @var $this yii\web\View */

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\base\view;

$this->title = 'Home';
?>
<section class="home_slider_section" id="home"  data-anchor="home">
    <div class="slider">
        <img src="<?php echo Yii::getAlias('@images_url'); ?>/slide01.jpg" class="img-responsive hidden-xs" alt="slide01">
    </div>
    <div class="slider_content">
        <div class="container">
            <h1>THE BEST HEARING <br class="visible-lg"> PLACEMENT TOOL </h1>
            <p>Save time in your busy day by placing
                <br>your hearings with special appearance counsel
            </p>
            <div class="app_download_btn">
                <a target="_blank" href="https://itunes.apple.com/us/app/apeerance/id1357534178?ls=1&mt=8"><img src="<?php echo Yii::getAlias('@images_url'); ?>/iphone_btn.png" alt='iphone app'></a>
                <a target="_blank" href="https://play.google.com/store/apps/details?id=com.apeerance"><img src="<?php echo Yii::getAlias('@images_url'); ?>/android_btn.png" alt='android app'></a>
            </div>
        </div>
    </div>

    <!-- xxxxxx -->


    <div class="apeerance_advantage section_pad">
        <div class="container">
            <div class="section_heading">
                <h2 class=" text-center">The Courtpals Advantage</h2>
                <p class="text-center">Saving time can be easy, secure and effective</p>
            </div>
            <div class="row">
                <div class="col-lg-4 col-sm-4 col-md-4 col-xs-12">
                    <div class="advantage_box">
                        <img src="<?php echo Yii::getAlias('@images_url'); ?>/place_hearing.jpg" alt="">
                        <h3>Place Hearings</h3>
                        <p>Trust verified pal attorneys to handle your court appearances</p>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-4 col-md-4 col-xs-12">
                    <div class="advantage_box">
                        <img src="<?php echo Yii::getAlias('@images_url'); ?>/peer_attorney.jpg" alt="">
                        <h3>Pal Attorney</h3>
                        <p>Pal attorneys are available on demand - verified and backed by malpractice insurance</p>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-4 col-md-4 col-xs-12">
                    <div class="advantage_box">
                        <img src="<?php echo Yii::getAlias('@images_url'); ?>/secure.jpg" alt="">
                        <h3>Simple & Secure</h3>
                        <p>Pal attorneys securely handle hearings, communication is simple, and payments are safe</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="about_us section_pad" id="about" data-anchor="about">
    <div class="left_cnt hidden-xs">
    </div>
    <div class="container"> 
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 col-lg-offset-6 right_cnt">
            <div class="section_heading">
                <h2>About Us</h2>   
                <p class="mb-0">Courtpals believes that attorneys should work together and save time for their clients.</p>
                 <p class="mt-0">The goal of Courtpals is to leverage special appearance  attorneys for limited-scope hearings.</p>
            </div>
        </div>
    </div>
</section>
<section class="whatis_app section_pad" id="features" data-anchor="features">
    <div class="container">
        <div class="section_heading">
            <h2 class=" text-center">Application Features</h2>
            <p class="text-center">In moments, have a case placed with a Pal attorney and save yourself time and money</p>
        </div>

        <!-- xxxxxxxx -->

        <div class="whatis_app whatis_app02">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 right_cnt">
                        <div class="section_heading">
                            <h2 class="">Our unique rating system ensures <br>
                                quality and dependability

                            </h2>
                            <p class="">In addition to our malpractice guarantee, our star rating
                                system ensures that Courtpals only works with the top
                                attorneys. </p>

                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 left_cnt">
                        <img src="<?php echo Yii::getAlias('@images_url'); ?>/app_2.png" class="img-responsive" alt="">
                    </div>
                </div>
            </div>
        </div>

        <!-- xxxxxxxx -->



        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 left_cnt">
                <img src="<?php echo Yii::getAlias('@images_url'); ?>/app_01.png" class="img-responsive" alt="">
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 right_cnt">
                <div class="section_heading">
                    <h2 class="">Place a case and save a court trip</h2>
                    <p class="">Courtpals will harness the power of the sharing
                        economy by working with hundreds of top-rated
                        attorneys in your area to cover your hearings.</p>

                </div>
            </div>
        </div>
    </div>


</section>

<section class="contact_us section_pad" id="contact" data-anchor="contact">
    <div class="container">
        <div class="section_heading">
            <h2 class=" text-center">Contact Us</h2>
        </div>
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 left_cnt">
                <h2>Get in Touch</h2>
                <p>Got a question? Want to hear from us? 
                    Tell a bit about yourself and we’ll get back to you as soon as we can.</p>
                <div class="info_item">
                    <div class="info_icon"><img src="<?php echo Yii::getAlias('@images_url'); ?>/mail_icon.png" alt=""></div>
                    <div class="info_text"><a href="mailto:support@courtpals.com">support@courtpals.com</a></div>
                </div>
                <div class="info_item">
                    <div class="info_icon"><img src="<?php echo Yii::getAlias('@images_url'); ?>/mobile_icon.png" alt=""></div>
                    <div class="info_text">510.952.PEER</div>
                </div>
                <div class="info_item">
                    <div class="info_icon"><img src="<?php echo Yii::getAlias('@images_url'); ?>/location_icon.png" alt=""></div>
                    <div class="info_text">248 3rd Street, Suite 480<br/> Oakland, CA 94607</div>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 right_cnt contact_form">
                <div class="form_box">
                    <div class="form_heading">
                        <h3>Email us</h3>
                    </div>
                    <div class="form_cnt">
                        <?php
                        $form = ActiveForm::begin(
                                        [ 'id' => 'contactUs',
                                            'action' => Yii::$app->urlManager->createUrl(['site/contact-us']),
                                            'enableAjaxValidation' => false,
                                            'enableClientValidation' => true,
                                            'options' => [
                                                'onsubmit' => '$(document).on("beforeSubmit","#contactUs", function () {
                                        $(".submitBtn").attr("disabled",true);
                                        $("#sendLoader").show();
                                        });']
                                       ]);
                        ?>
                        <div class="form-group">
                            <?= $form->field($model, 'email')->textInput(['class' => 'form-control', 'placeholder' => 'Email'])->label(false) ?>
                        </div>
                        <div class="form-group">
                            <?= $form->field($model, 'subject')->textInput(['class' => 'form-control', 'placeholder' => 'Subject'])->label(false) ?>
                        </div>
                        <div class="form-group">
                            <?= $form->field($model, 'message')->textarea(['class' => 'form-control', 'placeholder' => 'Message'])->label(false) ?>
                        </div>
                        <button class="btn btn-block btn-info submitBtn">SUBMIT<i class="fa fa-spinner fa-pulse fa-1x" id="sendLoader" style="display: none"></i></button>
                            <?php ActiveForm::end(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
