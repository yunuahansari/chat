<?php
/* @var $this yii\web\View */

$this->title = 'Terms & Conditions';
?>
<main class="main inner_pages terms-conditions">
    <section class="terms-content">
        <h1> terms & conditions</h1>
        <div class="container">
            <div class="para">
                <h2></h2>
                <p>These Terms of Service ("Terms") govern the access and use of the Courtpals application ("App" or "Licensed Application"), communications and agreements created therein, products, services, and websites (collectively, "Services") offered by Courtpals, Inc. ("Courtpals").
                    Courtpals offers a platform that connects attorneys seeking special appearance coverage for court appearances ("Clients") with available one-time appearance attorneys ("pals"). Clients and pals (collectively, "Members") are independent licensed attorneys in good standing with their respective state bars who are registered with Courtpals. Members are able to assign court appearances to pals. pals meet certain professional requirements and may therefore review and accept appearances for which they are qualified.  Courtpals covers liability insurance for these one-time appearances that are scheduled through the Courtpals product.
                </p>
                <p>COURTPALS IS NOT A LAW FIRM OR LAWYER REFERRAL SERVICE AND DOES NOT PRACTICE LAW, PROVIDE LEGAL ADVICE, MAKE APPEARANCES IN COURT, OR EMPLOY ANY INDIVIDUALS TO MAKE APPEARANCES IN COURT. COURTPALS IS SOLELY AN ELECTRONIC VEHICLE TO CONNECT TWO ATTORNEYS TOGETHER TO MAKE THE WORLD A BETTER PLACE.</p>
                <p>MEMBERS WHO REQUEST, ACCEPT, AND PROVIDE SERVICES THROUGH THE PLATFORM DO SO AT THEIR OWN DISCRETION AS INDEPENDENT CONTRACTING PARTIES AND AT THEIR OWN RISK. THE PRINCIPAL ASSIGNING THE APPEARANCE AND PAL WHO ACCEPTS THE ASSIGNED APPERANCE CREATE THEIR OWN SEPARATE AGREEMENT AND ASSUME ALL RESPONSIBILITY AND LIABILITY FOR THE PROPER CLASSIFICATION OF THEIR RELATIONSHIP. NO JOINT VENTURE, FRANCHISOR-FRANCHISEE, PARTNERSHIP, EMPLOYMENT, OR AGENCY RELATIONSHIP WITH COURTPALS IS INTENDED OR CREATED BY MEMBERS’ ACCESS OR USE OF THE SERVICES OR ACCEPTANCE OF THESE TERMS.</p>
                <p>YOUR ACCESS AND USE OF THE SERVICES CONSTITUTES YOUR AGREEMENT AND INTENT TO BE BOUND BY THE TERMS. PLEASE READ THEM CAREFULLY.</p>
            </div>

            <div class="para">
                <h2><strong>1.</strong> Acceptance Of Agreements</h2>
                <p>The Terms, as amended from time to time and published at (courtpals.com/terms), is a legal agreement between Courtpals and you, enforceable like any written negotiated agreement signed by you. The Terms include and hereby incorporate by reference Courtpals’s Privacy Policy.</p>
                <p>By creating an account, accessing, or using the Services, you expressly acknowledge that you have read, understand, and accept the Terms. If you do not agree to any part of the Terms, do not access or use the Services.</p>
                <p>You are responsible for regularly reviewing the Terms as it may be modified at any time. All such modifications will be effective upon posting at (Courtpals.com/terms). If you are not satisfied with any update to the Terms, your sole remedy is to discontinue your use of the Services. Your continued use of the Services after an update constitutes your acceptance of the updated Terms.</p>
            </div>

            <div class="para">
                <h2><strong>2.</strong> License</h2>
                <p>Subject to your compliance with these Terms, Courtpals grants you a non-exclusive, non-transferable, non-sublicensable, non-commercial license for use on your personal device solely in connection with work you perform through the Services. All rights not specifically granted under this Agreement are reserved by Courtpals and Courtpals’s licensors. Your license confers no title or ownership in the App and should not be construed as a sale of any rights in the App. Courtpals reserves the right to revoke this license for cause or breach of the Terms.</p>
            </div>


            <div class="para">
                <h2><strong>3.</strong> No Offer of Legal Services</h2>
                <p>Courtpals is not a law firm or lawyer referral service and does not practice law, give legal advice or make appearances in court. Courtpals has no relationship with any Members’ clients and owes no duties to any such clients. Courtpals does not review any information Members provide through the Services for legal or factual accuracy or sufficiency, draw legal conclusions, or provide opinions about any case or legal matter. Members who submit appearances and pals who accept appearances do so entirely at their own discretion and risk. Apart from offering, maintaining, and facilitating the operation of the platform, Courtpals does not participate in the communication, interaction, relationship or work performed by Members. Courtpals does not have the right to, and shall not be deemed to, direct or control Member with regard to the provision of any services. Members retain the sole right to determine if, when, where, and for how long to utilize the Courtpals App or Services.</p>
            </div>


            <div class="para">
                <h2><strong>4.</strong> Eligibility</h2>
                <p>YOU MUST BE A LICENSED ATTORNEY IN GOOD STANDING OF THE STATE BAR WHERE YOU PRACTICE TO USE THE SERVICES AS A MEMBER. </p>
                  <p>  By using the Services, you also represent and warrant that </p>
                <ul>
                    <li>You are 21 years of age or older. </li>
                    <li>You are legally able to enter into a contract.</li>
                    <li>You are a licensed attorney in good standing of the state bar where you practice.</li>
                    <li>You are not currently involved in or subject to any legal disciplinary proceeding or any action alleging legal malpractice or negligence in the performance of your services as an attorney anywhere in the world. </li>
                    <li>All information you submit to Courtpals is truthful and accurate. </li>
                    <li>You will maintain the accuracy of such information. </li>
                    <li>You will not share your account with anyone else.</li>
                    <li>Your use of the Services conforms to the purpose of the Services, complies with these Terms, and does not violate any applicable law or regulation. If you do not meet the eligibility requirements set forth above, you may not use the Services or App.  ALTHOUGH WE WILL ATTEMPT TO MONITOR YOUR BAR MEMBERSHIP STATUS YOU ARE OBLIGATED TO COME FORTH WITH ANY DEROGATORY INFORMATION AS IT MAY ARISE.</li>   
                </ul>
            </div>

            <div class="para">
                <h2><strong>5.</strong> Modification of Agreements Outside of the App</h2>
                <p>Actions you take outside of the App can affect the terms and legal status of agreements you have created through the App. This can result in obligations, terms, or conditions not reflected in the App. For example, if you make an agreement with another Member through the App and later exchange communications modifying the agreement outside of the App, the resulting agreement may not be consistent with agreement delineated through the App.
                    You acknowledge that removing the App from your device or otherwise deactivating your Courtpals account does not terminate or otherwise affect the legal status of agreements you are party to or have offered through Courtpals.
                </p>
            </div>

            <div class="para">
                <h2><strong>6.</strong> Intellectual Property Rights</h2>
                <p><strong>(A)</strong> Ownership. All title, ownership rights and intellectual property rights in and to the App (including but not limited to any patches and updates) and any and all copies thereof (including but not limited to any titles, computer code, themes, objects, catchphrases, locations, concepts, artwork, animation, sounds, musical compositions, audiovisual effects, methods of operation, moral rights, any related documentation, and “applets” incorporated into the Licensed Application) are owned by Courtpals, affiliates of Courtpals or Courtpals’s licensors. The Licensed Application is protected by the copyright laws of the United States, international copyright treaties and conventions and other laws. You acknowledge that Courtpals owns all rights in and to the App, including, but not limited to worldwide statutory and common law rights associated with</p>
                <ul class="">
                    <li>Patents and patent applications. </li>
                    <li>Works of authorship, including copyrights, copyright applications, copyright registrations and "moral rights". </li>
                    <li>The protection of trade and industrial secrets and confidential information.</li>
                    <li>Trademarks.</li>
                    <li>Divisions, continuations, renewals, derivative works, and re-issuances of any of the foregoing, now existing or acquired in the future.</li>
                </ul>
                <p><strong>(B)</strong> Feedback. We may provide you with a mechanism to provide feedback, suggestions, and ideas on Courtpals’s products and services. You grant us the irrevocable right to use your feedback and incorporate your suggestions into our products and services without any obligation to provide attribution or compensation to you or any third party.</p>
            </div>

            <div class="para">
                <h2><strong>7.</strong> No Incorporation of the Services or Licensed Application</h2>
                <p>Including our products and Services within any third-party service is not permitted without our prior written consent.</p>
            </div>

            <div class="para">
                <h2><strong>8.</strong>  Automatic Monitoring/Audits</h2>
                <div class="sub-para">
                    <p><strong>(A)</strong> You acknowledge that Courtpals reserves the right, at any time and without notice, to monitor compliance with the terms of this Agreement and to otherwise protect its rights in the Licensed Application by incorporating license management technology into the Licensed Application and monitoring usage, including, without limitation, time, date, access or other controls, counters, serial numbers, and/or other security devices. The App may also include product activation and other security technology that is designed to prevent the unauthorized access, use and/or copying of the App, including any violations of this Agreement. This technology may cause your device to automatically connect to the Internet, may transmit information about you and the device used to access the App (including personal information) to Courtpals, and may prevent uses of the App that are not authorized or permitted pursuant to the terms of this Agreement.</p>
                    <p><strong>(B)</strong> Courtpals reserves the right, with reasonable notice, to audit or have audited your use of the App to verify compliance with the terms of this Agreement. Such audit shall be at Courtpals’s expense unless noncompliance by you is found by the auditor, in which case, you shall reimburse Courtpals for the reasonable costs of the audit in addition to payment of all fees necessary to obtain valid licenses to bring your use back into compliance.</p>
                </div>

            </div>

            <div class="para">
                <h2><strong>9.</strong> Consent to Use of Data</h2>
                <p>Your access and use of the App is not private or confidential and is governed by Courtpals’s Privacy Policy (Privacy Policy) which is incorporated herein by this reference. You agree that Courtpals may collect and use technical data and related information, including but not limited to, technical information about your device, system and application software, and peripherals, that is gathered periodically to facilitate the provision of software updates, product support and other services to you (if any) related to the App. Courtpals may use this information, as long as it is in a form that does not personally identify you, to improve its products or to provide services or technologies to you.</p>
            </div>

            <div class="para">
                <h2><strong>10.</strong> Prohibited Uses</h2>
                <p>You hereby acknowledge and agree that you shall not use the App for any purpose other than for personal use, and that you shall use the App in accordance with all applicable laws, rules, and regulations. Except as expressly provided herein you shall not, and shall not permit any third party to:</p>
                <ul class="">
                    <li>Exploit the App or any of its parts commercially. Notwithstanding, in certain circumstances, Courtpals may offer a separate license Agreement to permit you to make the Licensed Application available for commercial use. If you seek such license, contact Courtpals through the contact information below.</li>
                    <li>Use the App, or permit use of the App, on more than one device at the same time.</li>
                    <li>Make copies of the App or any part thereof, or make copies of the materials accompanying the App.</li> 
                    <li>Copy the App onto a hard drive or other storage device except as specifically permitted herein.</li>
                    <li>Use the App, or permit use of the App, in a network, multi-user arrangement or remote access arrangement, including any online use, except as otherwise expressly provided by the App.</li>
                    <li>Sell, rent, lease, license, distribute or otherwise transfer the App, or any copies of the App, without the express prior written consent of Courtpals.</li>
                    <li>Reverse engineer, derive source code, modify, decompile, disassemble, or create derivative works of the App, in whole or in part.</li>
                    <li>Remove, disable or circumvent any proprietary notices or labels contained on or within the App.</li>
                    <li>Hack or modify (or attempt to hack or modify) the App, or create, develop, modify, distribute or use any software programs, in order to gain (or allow others to gain) advantage of or access to the App in any online multiplayer game settings, including but not limited to local area network or any other network play or on the Internet.</li>
                    <li>Export the App or any copy or adaptation in violation of any applicable laws or regulations.</li>


            </div>

            <div class="para">
                <h2><strong>11.</strong> Charges and Billing</h2>
                <p>You agree that to the extent you provide Courtpals and/or its licensors or affiliates any payment information, you represent that you are an authorized user of the chosen method of payment, and that all payment information you provide, including but not limited to your name, credit card or other payment account identifying number, expiration date, security codes, billing address, and any other payment information will be current, complete, true and accurate. All expenses and costs incurred by you in connection with its activities hereunder, if any, are your sole responsibility. You are not entitled to reimbursement from Courtpals for any expenses, and you will hold Courtpals harmless therefrom.</p>
            </div>

            <div class="para">
                <h2><strong>12.</strong> Vetting</h2>
                <p>pals must meet certain requirements before they can receive, review, and/or accept appearances through Courtpals. The vetting requirements include, but are not limited to, verification of identity, state bar licensing history and status, and extent of experience within particular areas of law.</p>
                <p>pal candidates may be asked to provide information such as work history that Courtpals cannot confirm. Thus, Courtpals cannot and does not assume any responsibility for the accuracy or reliability of self-reported information. You should always exercise professional judgment and common sense when interacting with other Members, just as you would when interacting with other persons you do not know.</p>
                <p>COURTPALS IS NOT RESPONSIBLE FOR THE CONDUCT OF ANY MEMBER AND YOU HEREBY RELEASE COURTPALS FROM ANY LIABILITY RELATED THERETO. COURTPALS WILL NOT BE LIABLE FOR ANY CLAIM, INJURY OR DAMAGE ARISING IN CONNECTION WITH YOUR USE OF THE COURTPALS APP OR SERVICES.</p>
            </div>

            <div class="para">
                <h2><strong>13.</strong> Fees, Disputes, and Refunds Between Members</h2>
                <p>As a Client and/or pal, you understand that use of the Services may result in charges to you (the "Charges") which include the fee for the services of Client/pal plus an administrative cost for the service provided by Courtpals. You will be advised of the Charges and asked to confirm before assigning an appearance through the Services. The Charges are subject to Courtpals’s Cancellation Policy (courtpals.com/cancellation). Those fees are subject to change without prior specific notice and you are responsible for knowing them.  The Courtpals application may or may not properly advise you of the fees.</p>
                <p>After you have received services from a pal through your use of the Services, Courtpals will facilitate your payment of the applicable charges on behalf of the pal. Stripe or other similar service, a third-party payments processor used by Courtpals, will charge the payment card you have added to your profile for this purpose. The Charges paid by you are final and non-refundable, unless otherwise determined by Courtpals.</p>
                <p>After the Charges have been charged to your payment card you will receive a receipt from Courtpals by email. If your payment card is determined to be expired, invalid or otherwise not able to be charged, you agree to update your payment card so that Courtpals may successfully complete the transaction and compensate your pal accordingly.</p>
                <p>Courtpals reserves the right to establish, remove and/or revise the Charges at any time in Courtpals’s sole discretion. Courtpals may from time to time provide certain members with promotional offers that may result in different amounts charged for the same or similar services obtained through the use of the Services, and you agree that such promotional offers and discounts, unless also made available to you, shall have no bearing on your use of the Services or the Charges applied to you. You may elect to cancel your request for services from a pal at any time prior to the time of the assigned appearance, in which case you may be charged a cancellation fee. This payment structure is intended to fully compensate “pals” for the services provided.</p>
                <p>You acknowledge and agree that Courtpals only facilitates the connection, communication, and payment between Client and pal. Any and all substantive communication, services, and work relating to an appearance is between you and your pal. Courtpals cannot and does not make any representations or guarantees concerning the quality and/or nature of the services provided by pals. Courtpals does not have the right to, and shall not be deemed to, direct or control you with regard to your provision of any pal services. Courtpals may, in Courtpals’s sole discretion, investigate any concern regarding an appearance and determine whether or not to issue a partial or full refund of paid Charges.</p>
                <p>After you have received services from a pal, you will have the opportunity to rate your experience and leave additional feedback about your pal. Any dispute regarding the quality and/or nature of services provided by a pal must be addressed directly between you and your pal unless otherwise provided for under these Terms.</p>
            </div>

            <div class="para">
                <h2><strong>14.</strong> No Warranty</h2>
                <p>Because Courtpals App and Services provide a do-it-yourself tool, the accuracy and sufficiency of agreements produced using Courtpals ultimately depends on user input, which input Courtpals does not review. Moreover, practicing law is complex, and no general tool like Courtpals is appropriate in every circumstance. Therefore, Courtpals does not make any claims about quality, accuracy, legal sufficiency, legal enforceability, or appropriateness of Courtpals App or Services for your needs. If you require legal advice or help on your specific situation, you should consult a licensed attorney in your area.</p>
                <p>Courtpals offers no guarantees or warranties regarding the quality, dependability or competence of any Member. Any Member ratings or other information about Members that Courtpals provides are offered solely for convenience of other Members and should not be relied upon as endorsements. Courtpals does not conduct any conflict of interest checks. Members bear sole responsibility to determine whether any attorney using the App or Services will be appropriate for their matter.</p>
                <p>YOU EXPRESSLY ACKNOWLEDGE AND AGREE THAT USE OF THE APP AND SERVICES IS AT YOUR SOLE RISK AND THAT YOU BEAR THE ENTIRE RISK AS TO SATISFACTORY QUALITY, PERFORMANCE, ACCURACY AND EFFORT. TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, THE LICENSED APPLICATION AND SERVICES ARE PROVIDED “AS IS” AND “AS AVAILABLE”, WITH ALL FAULTS AND WITHOUT WARRANTY OF ANY KIND, AND COURTPALS HEREBY DISCLAIMS ALL WARRANTIES AND CONDITIONS WITH RESPECT TO THE LICENSED APPLICATION AND ANY SERVICES, EITHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES AND/OR CONDITIONS OF MERCHANTABILITY, OF SATISFACTORY QUALITY, OF FITNESS FOR A PARTICULAR PURPOSE, OF ACCURACY, OF QUIET ENJOYMENT, AND NON-INFRINGEMENT OF THIRD PARTY RIGHTS. COURTPALS DOES NOT WARRANT AGAINST INTERFERENCE WITH YOUR ENJOYMENT OF THE LICENSED APPLICATION, THAT THE FUNCTIONS CONTAINED IN, OR SERVICES PERFORMED OR PROVIDED BY, THE LICENSED APPLICATION WILL MEET YOUR REQUIREMENTS, THAT THE OPERATION OF THE LICENSED APPLICATION OR SERVICES WILL BE UNINTERRUPTED OR ERROR-FREE, OR THAT DEFECTS IN THE LICENSED APPLICATION OR SERVICES WILL BE CORRECTED. NO ORAL OR WRITTEN INFORMATION OR ADVICE GIVEN BY COURTPALS OR ITS AUTHORIZED REPRESENTATIVE(S) SHALL CREATE A WARRANTY. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OF IMPLIED WARRANTIES OR LIMITATIONS ON APPLICABLE STATUTORY RIGHTS OF A CONSUMER, SO THE ABOVE EXCLUSION AND LIMITATIONS MAY NOT APPLY TO YOU.</p>
                <p>Any end-user questions, complaints or claims with respect to the Licensed Application or Services should be directed to mpre@courtpals.com.</p>
                <p>Courtpals is responsible for providing any maintenance and support services with respect to the Licensed Application, as specified herein, or as required under applicable law. You acknowledge that neither Courtpals nor any other party has any obligation whatsoever to furnish any maintenance and support services with respect to the Licensed Application.</p>
            </div>


            <div class="para">
                <h2><strong>15.</strong> Limitation of Liability</h2>
                <p>ANY CLAIM OR CAUSE OF ACTION ARISING OUT OF OR RELATED TO THIS AGREEMENT MUST BE FILED WITHIN 1 YEAR AFTER SUCH CLAIM OR CAUSE OR ACTION AROSE REGARDLESS OF ANY STATUTES OR LAW TO THE CONTRARY. IN THE EVENT ANY SUCH CLAIM OR CAUSE OF ACTION IS NOT FILED WITHIN SUCH 1 YEAR PERIOD, SUCH CLAIM OR CAUSE OF ACTION IS FOREVER BARRED.</p>
                <p>COURTPALS DISCLAIMS LIABILITY FOR ANY LOSS, INJURY, CLAIM OR DAMAGE RELATED TO YOUR USE OF THE APP OR THE SERVICES, INCLUDING WITHOUT LIMITATION, THOSE RESULTING FROM ERRORS OR OMISSIONS, A SITE OR APPLICATION BEING DOWN, OR DATA LOSS. YOU AGREE THAT COURTPALS WILL NOT BE LIABLE FOR INDIRECT, SPECIAL, INCIDENTAL, EXEMPLARY, PUNITIVE OR CONSEQUENTIAL DAMAGES, INCLUDING BUT NOT LIMITED TO LOST PROFITS, LOSS OF GOODWILL, DAMAGES FOR THE DELETION, CORRUPTION OR LOSS OF DATA OR PROGRAMS, FAILURE TO STORE ANY INFORMATION OR OTHER CONTENT MAINTAINED OR TRANSMITTED BY THE COURTPALS APP OR SERVICES, SERVICE INTERRUPTIONS, OR FOR THE COST OF PROCURING SUBSTITUTE SERVICES, PERSONAL INJURY, OR PROPERTY DAMAGE RELATED TO, IN CONNECTION WITH OR RESULTING FROM YOUR USE OF OR RELIANCE ON THE APP OR ANY SERVICES, YOUR INABILITY TO ACCESS OR USE THE SERVICES, OR ANY TRANSACTION OR RELATIONSHIP BETWEEN YOU AND A MEMBER, HOWEVER ARISING, INCLUDING NEGLIGENCE, EVEN IF COURTPALS KNOWS OR HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES, TO THE FULLEST EXTENT PERMITTED BY LAW. IN NO EVENT SHALL COURTPALS’S LIABILITY TO YOU EXCEED THE ACTUAL PRICE PAID BY YOU TO COURTPALS TO USE THIS LICENSED APPLICATION. CERTAIN JURISDICTIONS MAY NOT ALLOW THE EXCLUSION OR LIMITATIONS OF CERTAIN LIABILITIES OR DAMAGES. IF THESE LAWS APPLY TO YOU, SOME OR ALL OF THE ABOVE DISCLAIMERS, LIMITATIONS AND/OR EXCLUSION OR LIMITATION OF LIABILITY MAY NOT APPLY TO YOU AND YOU MAY HAVE ADDITIONAL RIGHTS.</p>

            </div>


            <div class="para">
                <h2><strong>16.</strong> Term & Termination</h2>
                <p>This Agreement shall commence on the date your account is created. Courtpals may immediately terminate these Terms or any Services with respect to you, or generally cease offering or deny access to the Services or any portion thereof, at any time for any reason. Without prejudice to any other rights of Courtpals, this Agreement will terminate automatically if you fail to comply with its terms and conditions. In such event, you must destroy all copies of the Licensed Application and all of its component parts. Additionally, Courtpals and/or its licensors, reserve the right to change, suspend, remove, or disable access to or elements of the Licensed Application at any time without notice. In no event will Courtpals be liable for the removal of or disabling of access to the Licensed Application or any elements or portions thereof. Courtpals may also impose limits on the use of or access to certain elements or portions of the Licensed Application, in any case and without notice or liability. You agree that Courtpals shall not be liable for any loss or damage caused, directly or indirectly, by any such termination and/or suspension. IN THE EVENT THAT YOUR ACCOUNT IS TERMINATED, YOU WILL HAVE NO FURTHER ACCESS TO THE LICENSED APPLICATION AND YOU WILL NOT RECEIVE ANY REFUND OR REIMBURSEMENT FOR ANY PAYMENTS ASSOCIATED WITH YOUR ACCOUNT.</p>
            </div>

            <div class="para">
                <h2><strong>17.</strong> Injunction</h2>
                <p> Because Courtpals would be irreparably damaged if the terms of this Agreement were not specifically enforced, you agree that Courtpals shall be entitled, without bond, other security or proof of damages, to appropriate equitable remedies with respect to breaches of this Agreement, in addition to such other remedies as Courtpals may otherwise have under applicable laws.</p>
            </div>

            <div class="para">
                <h2><strong>18.</strong> Indemnification</h2>
                <p>You agree to indemnify, defend and hold Courtpals, its partners, affiliates, contractors, officers, directors, employees and agents harmless from all claims, demands, liabilities, damages, losses and expenses (including attorney’s fees) arising directly or indirectly out of or in connection with </p>
                <ol>
                    <li>Your use of Courtpals’s App or Services, or services you obtained or provided through your use of Courtpals's App or Services. </li>
                    <li>Your breach or violation of any of these Terms (including any updates or documents incorporated by reference). </li>
                    <li>Your violation of any rights of or obligations owed any other party, including any other Member.</li>
                </ol>
            </div>

            <div class="para">
                <h2><strong>19.</strong> Assignment</h2>
                <p>Courtpals may assign this Agreement, in whole or in part, at any time. Notwithstanding, you may not assign, transfer or sublicense any or all of your rights or obligations under the Agreement and/or Licensed Application without Courtpals’s express prior written consent.</p>
            </div>

            <div class="para">
                <h2><strong>20.</strong> Dispute Resolution / Governing Law</h2>
                <p>Any dispute, claim or controversy arising out of or relating to this Agreement or the breach, termination, enforcement, interpretation or validity thereof, including the determination of the scope or applicability of this agreement to arbitrate, shall be determined by arbitration in Alameda County, California before one arbitrator. The arbitrator may not consolidate more than one person’s claims, and may not preside over any form of a representative or class proceeding. The arbitration shall be administered in accordance with the Commercial Arbitration Rules and Procedures of the American Arbitration Association (“AAA”) then in effect, by the single arbitrator who shall be selected from the appropriate list of AAA arbitrators. The determination of whether a dispute is subject to arbitration shall be governed by the Federal Arbitration Act and determined by an arbitrator rather than a court. The prevailing party in any arbitration or other proceeding arising under this Agreement shall be entitled to receive reimbursement of its reasonable expenses (including reasonable attorneys’ fees, expert witness fees and all other expenses) incurred in connection therewith. Judgment on the award of the arbitrator may be entered in any court having jurisdiction. Either party may, without waiving any remedy under this agreement, seek from any court having jurisdiction any interim or provisional relief that is necessary to protect the rights or property of that party, pending resolution of the arbitration on the merits of the dispute.
                    This Agreement and the rights of the parties hereunder shall be governed by and construed in accordance with the laws of the State of California, exclusive of conflict or choice of law rules. Notwithstanding the provision in the preceding paragraph with respect to applicable substantive law, any arbitration conducted pursuant to the terms of this Agreement shall be governed by the Federal Arbitration Act (9 U.S.C., Secs. 1-16).
                </p>
            </div>

            <div class="para">
                <h2><strong>21.</strong> Miscellaneous</h2>
                <p>These Terms represent the complete agreement between the parties and supersedes all prior agreements, arrangements and representations between them. If any provision of this Agreement is held to be unenforceable for any reason, such provision shall be reformed or stricken only to the extent necessary to make it enforceable and the remaining provisions of this Agreement shall not be affected. Courtpals’s failure to enforce any right or provision in these Terms shall not constitute a waiver of such right or provision unless acknowledged and agreed to by Courtpals in writing. Headings are for reference purposes only, and do not define, limit or explain any section or provision hereof. In addition to your obligations to pay Courtpals all amounts due under this Agreement, Sections 3 (Ownership), 5 (Consent to Use of Data), 8 (Charges and Billing), 10 (Limitation on Damages), 14 (Indemnity), and 16 (Dispute Resolution) shall expressly survive termination of the Agreement.</p>
            </div>

            <div class="para">
                <h2><strong>22.</strong> Apple App Store Terms</h2>
                <p>This Agreement is between you and Courtpals only, and not with Apple, and Courtpals, not Apple, is solely responsible for the Licensed Application and the content thereof. You acknowledge that Courtpals, not Apple, is responsible for addressing any of your claims or any third party claims relating to the Licensed Application or your possession and/or use of the Licensed Application, including, but not limited to: </p>
                <div class="sub-para">
                    <ol>
                        <li>Product liability claims.</li>
                        <li>Any claim that the Licensed Application fails to conform to any applicable legal or regulatory requirement. </li>
                        <li>Claims arising under consumer protection or similar legislation. In the event of any third party claim that the Licensed Application or the end-user’s possession and use of that Licensed Application infringes that third party’s intellectual property rights, Courtpals, not Apple, will be solely responsible for the investigation, defense, settlement and discharge of any such intellectual property infringement claim. You acknowledge and agree that Apple, and Apple’s subsidiaries, are third party beneficiaries of this Agreement, and upon your acceptance of the terms and conditions of this Agreement, Apple will have the right (and will be deemed to have accepted the right) to enforce this Agreement against you as a third party beneficiary thereof.</li>
                    </ol>
                </div>
            </div>

            <div class="para">
                <h2><strong>23.</strong> Google Play Terms</h2>
                <p>This Agreement is between you and Courtpals only, and not with Google, and Courtpals, not Google, is solely responsible for the Licensed Application and the content thereof. You acknowledge that Courtpals, not Google, is responsible for addressing any of your claims or any third party claims relating to the Licensed Application or your possession and/or use of the Licensed Application, including, but not limited to:</p>
              <div class="sub-para">
                    <ol>
                        <li>Product liability claims. </li>
                        <li>Any claim that the Licensed Application fails to conform to any applicable legal or regulatory requirement. </li>
                        <li>Claims arising under consumer protection or similar legislation. In the event of any third party claim that the Licensed Application or the end-user’s possession and use of that Licensed Application infringes that third party’s intellectual property rights, Courtpals, not Google, will be solely responsible for the investigation, defense, settlement and discharge of any such intellectual property infringement claim. You acknowledge and agree that Google, and Google’s subsidiaries, are third party beneficiaries of this Agreement, and upon your acceptance of the terms and conditions of this Agreement, Google will have the right (and will be deemed to have accepted the right) to enforce this Agreement against you as a third party beneficiary thereof.</li>
                    </ol>
                </div>
            </div>

            <div class="para">
                <h2><strong>24.</strong> Contact</h2>
                <p>You can email Courtpals at <a href="mailto:support@courtpals.com">support@courtpals.com</a> or through our <a href="<?php echo \yii\helpers\Url::toRoute("/#contact") ?>" data-scroll="contact">Online Portal.</a></p>
            </div>

        </div>
    </section>
</main>