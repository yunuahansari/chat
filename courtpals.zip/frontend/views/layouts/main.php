<?php
/* @var $this \yii\web\View */
/* @var $content string */

use yii\helpers\Html;
use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;
use yii\widgets\Breadcrumbs;
use frontend\assets\AppAsset;
use common\widgets\Alert;

AppAsset::register($this);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
    <head>
        <meta charset="<?= Yii::$app->charset ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="apple-touch-icon" sizes="180x180" href="<?php echo Yii::getAlias('@base_url'); ?>/images/favicons/apple-touch-icon.png">
        <link rel="icon" type="image/png" sizes="32x32" href="<?php echo Yii::getAlias('@base_url'); ?>/images/favicons/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="16x16" href="<?php echo Yii::getAlias('@base_url'); ?>/images/favicons/favicon-16x16.png">
        <link rel="manifest" href="<?php echo Yii::getAlias('@base_url'); ?>/images/favicons/manifest.json">
        <link rel="mask-icon" href="<?php echo Yii::getAlias('@base_url'); ?>/images/favicons/safari-pinned-tab.svg" color="#5bbad5">
        <meta name="theme-color" content="#ffffff">
        <?= Html::csrfMetaTags() ?>
        <title><?= Yii::$app->name . ' | ' . Html::encode($this->title) ?></title>
        <?php $this->head() ?>
    </head>
    <body class="frontend">
       
        <?php $this->beginBody() ?>
        <?php
            //echo $this->render('//layouts/header');
        if (yii::$app->controller->action->id == 'index') {
            echo $this->render('//layouts/header');
        } else {
            echo $this->render('//layouts/inner_header');
        }
        ?>

        <?= $content ?>

        <?php
        if (yii::$app->controller->action->id == 'index') {
            echo $this->render('//layouts/footer');
        } else {
            echo $this->render('//layouts/inner_footer');
        }
        ?>
        
        <?php $this->endBody() ?>
         <?php \common\components\Utility::flashMessage(); ?>
    </body>
</html>
<?php $this->endPage() ?>
