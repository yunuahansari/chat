<div class="modal fade login_modal" tabindex="-1" role="dialog" aria-labelledby="login_modal" id="loginModal">
</div>
<div class="modal fade forget_modal" tabindex="-1" role="dialog" aria-labelledby="forget_modal" id="forgetModal">
</div>
<div class="modal fade signup_modal" tabindex="-1" role="dialog" aria-labelledby="signup_modal" id="signupModal">
</div>
<footer class="footer_frontend">
    <div class="container">
        <div class="footer_cnt">
            <img src="<?php echo Yii::getAlias('@images_url'); ?>/white_blue.png" alt='logo' class="logo">
            <h2>THE BEST HEARING PLACEMENT TOOL</h2>
            <div class="app_download_btn">
                <a target="_blank" href="https://itunes.apple.com/us/app/apeerance/id1357534178?ls=1&mt=8"><img src="<?php echo Yii::getAlias('@images_url'); ?>/iphone_btn.png" alt='iphone app'></a>
                <a target="_blank" href="https://play.google.com/store/apps/details?id=com.apeerance"><img src="<?php echo Yii::getAlias('@images_url'); ?>/android_btn.png" alt='android app'></a>
            </div>
        </div>
        <div class="footer_shor_link row">
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 p-0">
                <ul class="list-inline">
                    <li>
                        <a href="#"><img src="<?php echo Yii::getAlias('@images_url'); ?>/facebook.png" alt=""></a>
                    </li>
<!--                    <li>
                        <a href="javascript:void(0);"><img src="<?php echo Yii::getAlias('@images_url'); ?>/twitter.png"></a>
                    </li>
                    <li>
                        <a href="javascript:void(0);"><img src="<?php echo Yii::getAlias('@images_url'); ?>/google_plus.png"></a>
                    </li>-->
                </ul>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 right_cnt p-0">
                <ul class="list-inline">
                    <li><a data-scroll="home" href="<?php echo \yii\helpers\Url::toRoute("/#home") ?>">Home</a></li>
                    <li><a data-scroll="" href="<?php echo \yii\helpers\Url::toRoute("/privacy-policy") ?>">Privacy Policy</a></li>
                    <li><a data-scroll="" href="<?php echo \yii\helpers\Url::toRoute("/cancellation-policy") ?>">Cancellation Policy</a></li>
                    <li><a data-scroll="" href="<?php echo \yii\helpers\Url::toRoute("/terms-and-conditions") ?>">Terms & Conditions</a></li>
                   
                </ul>
            </div>
        </div>
    </div>
</footer>
<script>
    $('#forgetModal').on('shown.bs.modal', function (e) {
        $('body').addClass('modal-open');
    });
    $('#forgetModal').on('hidden.bs.modal', function (e) {
        $('body').removeClass('modal-open');
    });
    
    $('#resetModal').on('shown.bs.modal', function (e) {
        $('body').addClass('modal-open');
    });
    
    $('#resetModal').on('hidden.bs.modal', function (e) {
        $('body').removeClass('modal-open');
    });

    $('#signupModal').on('shown.bs.modal', function (e) {
        $('body').addClass('modal-open');
    });
    $('#signupModal').on('hidden.bs.modal', function (e) {
        $('body').removeClass('modal-open');
    });

    $('#loginModal').on('shown.bs.modal', function (e) {
        $('body').addClass('modal-open');
    });
    $('#loginModal').on('hidden.bs.modal', function (e) {
        $('body').removeClass('modal-open');
    });
</script>

<!-- xxxxxxx -->

<script>
     $('.nav a, .right_cnt a').on('click', function() {

            var scrollAnchor = $(this).attr('data-scroll');
            var href = $(this).attr('href');
            if(scrollAnchor){
                scrollPoint = $('section[data-anchor="' + scrollAnchor + '"]').offset().top - 50;
                $('body,html').animate({
                    scrollTop: scrollPoint
                }, 500);
                return false;
            }else if(href !== ""){
                window.location.href = $(this).attr('href');
                return false;
            }
            return false;
        });

        $(window).scroll(function() {

            if ($(this).scrollTop() < $('section[data-anchor="home"]').offset().top - 80) {
                $('.nav a, .right_cnt a').removeClass('active');
            }

            if ($(this).scrollTop() >= $('section[data-anchor="home"]').offset().top - 80) {
                $('.nav a, .right_cnt a').removeClass('active');
                $('.nav a:eq(0), .right_cnt a:eq(0)').addClass('active');
            }
            if ($(this).scrollTop() >= $('section[data-anchor="about"]').offset().top - 80) {
                $('.nav a').removeClass('active');
                $('.nav a:eq(1), .right_cnt a:eq(1)').addClass('active');
            }
            if ($(this).scrollTop() >= $('section[data-anchor="features"]').offset().top - 80) {
                $('.nav a').removeClass('active');
                $('.nav a:eq(2), .right_cnt a:eq(2)').addClass('active');
            }
            if ($(this).scrollTop() >= $('section[data-anchor="contact"]').offset().top - 80) {
                $('.nav a').removeClass('active');
                $('.nav a:eq(3), .right_cnt a:eq(3)').addClass('active');
            }

        });
    
    function loadLoginForm() {
        $.ajax({
            type: 'GET',
            url: '<?php echo yii::$app->urlManager->createUrl(['auth/auth/login-form']) ?>',
            success: function (result) {
                $('.signup_modal').modal('hide');
                $("#loginModal").html(result);
                $('.login_modal').modal('show');
            }
        });
    }
    
    function loadSignUpForm() {
        $.ajax({
            type: 'GET',
            url: '<?php echo yii::$app->urlManager->createUrl(['auth/auth/signup-form']) ?>',
            success: function (result) {
                $("#signupModal").html(result);
                $('.signup_modal').modal('show');
            }
        });
    }
    
    function loadForgotPasswordForm(){
        $.ajax({
            type: 'GET',
            url: '<?php echo yii::$app->urlManager->createUrl(['auth/auth/forgot-password-form']) ?>',
            success: function (result) {
                $('.login_modal').modal('hide');
                $("#forgetModal").html(result);
                $('.forget_modal').modal('show');
            }
        });
    }


</script>