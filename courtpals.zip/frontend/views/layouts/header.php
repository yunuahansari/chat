<header class="frontend_header">
        <nav class="navbar navbar-default" data-spy="affix" data-offset-top="50">
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="<?php echo \yii\helpers\Url::toRoute("/") ?>"><img src="<?php echo Yii::getAlias('@images_url'); ?>/white_blue.png" class="img-responsive" alt='logo'></a>
                </div>
                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="<?php echo \yii\helpers\Url::toRoute("/#home") ?>" data-scroll="home">Home</a></li>
                        <li><a href="<?php echo \yii\helpers\Url::toRoute("/#about") ?>" data-scroll="about">About Us</a></li>
                        <li><a href="<?php echo \yii\helpers\Url::toRoute("/#features") ?>" data-scroll="features">Features</a></li>
                        <li><a href="<?php echo \yii\helpers\Url::toRoute("/#contact") ?>" data-scroll="contact">Contact Us</a></li>
                       <?php  if (!empty(yii::$app->user->identity->id)) { ?>
                            <li><a href="<?php echo \yii\helpers\Url::toRoute("/auth/auth/logout") ?>" class="btn btn-warning" data-toggle="modal">Log Out</a></li>
                       <?php } else{ ?>
                           <li><a href="" data-scroll="" class="btn btn-warning" data-toggle="modal" onclick="loadSignUpForm()">SIGN UP</a></li>
                      <?php } ?>
                    </ul>
                </div>
                <!-- /.navbar-collapse -->
            </div>
            <!-- /.container-fluid -->
        </nav>
    </header>
