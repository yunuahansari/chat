<?php
return [
    'adminEmail' => 'admin@example.com',
    'zendesk_subdomain' => 'codianthelp',
    'zendesk_username' => 'courtpals@mailinator.com',
    'zendesk_token' => 'wuwYfl8Xd9lS0ng3XGDmzc48sU5g7ZfLaMMo32HF',
];
