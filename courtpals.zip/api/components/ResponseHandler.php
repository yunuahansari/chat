<?php

namespace api\components;

/**
 * Description of ResponseHandler
 *
 * @author hp
 */
class ResponseHandler {

    public $event;
    
    public function formatResponse() {
   
        $response = $this->event->sender;
        if(is_array($response->extraData) && !empty($response->extraData)){
           $data = \yii\helpers\ArrayHelper::merge($response->data, $response->extraData);
           
        } else {
            $data = $response->data;
        }
        if ($response->statusCode === 200) {
            $response->data = [
                'success' => true,
                'data' => $data,
                'error' => []
            ];
        } elseif ($response->statusCode === 401) {
            $response->data = [
                'success' => false,
                'data' => null,
                'error' => [
                    'field' => 'access_token',
                    'message' => 'Invalid access token'
                ]
            ];
        } elseif ($response->statusCode === 500) {
            $response->data = [
                'success' => false,
                'data' => null,
                'error' => [
                    'field' => 'server_error',
                    'message' => $data
                ]
            ];
        } elseif ($response->statusCode === 404) {
            $response->data = [
                'success' => false,
                'data' => null,
                'error' => [
                    'field' => 'page_not_found',
                    'message' => 'page not found'
                ]
            ];
        } elseif (YII_DEBUG) {
            $response->data = [
                'success' => false,
                'data' => null,
                'error' => $data
            ];
            $response->statusCode = 200;
        }
    }

}
