<?php

namespace api\components;

use Yii;
use yii\filters\AccessControl;
use api\components\QueryParamAuth;
use yii\helpers\ArrayHelper;




/**
 * Site controller
 */
class Controller extends \yii\rest\Controller {
    
    public $enableCsrfValidation = false;
    
    public $requestParams;

    public function behaviors() {
        return ['authenticator' => [
                'class' => QueryParamAuth::className(),
                'tokenParam' => 'access-token'
            ],
             'corsFilter'  => [
            'class' => \yii\filters\Cors::className(),
            'cors'  => [
                // restrict access to domains:
                      'Origin'                           => ['*'],
                    'Access-Control-Request-Method'    => ['POST'],
                    'Access-Control-Request-Headers'    => ['access_token','Content-Type'],
                    'Access-Control-Allow-Credentials' => true,
                    'Access-Control-Max-Age'           => 3600,                 // Cache (seconds)          => 3600,                 // Cache (seconds)
              ],
        ],
        ];
        
    }
    
    public function init()
    {
        if(Yii::$app->request->get())
            $this->requestParams = Yii::$app->request->get();
        if(Yii::$app->request->getRawBody())
            $this->requestParams = json_decode(Yii::$app->request->getRawBody(),true);
        
    }
}
