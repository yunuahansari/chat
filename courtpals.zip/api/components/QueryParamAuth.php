<?php

namespace api\components;


/**
 * Description of QueryParamAuth
 *
 * @author hp
 */
class QueryParamAuth extends \yii\filters\auth\QueryParamAuth {
    
   

    public function authenticate($user, $request, $response) {
       
       $accessToken = $request->getHeaders()->get('access-token') ? $request->getHeaders()->get('access-token') : $request->getBodyParams($this->tokenParam);
        if (is_string($accessToken)) {
            $identity = $user->loginByAccessToken($accessToken,  get_class($this));
            if (null !== $identity) {
                return $identity;
            }
        }
        if ($accessToken !== null) {
            $this->handleFailure($response);
        }
        return null;
    }

}
