<?php

namespace api\components;


class Response extends \yii\web\Response
{
    public $extraData = null;
    
    
} 