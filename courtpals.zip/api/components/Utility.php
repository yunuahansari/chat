<?php

namespace api\components;

use yii;
//use yii\web\Response;
use common\models\User;

final class Utility
{

    public static function apiError ($errorCode, $message)
    {
        Yii::$app->response->statusCode = $errorCode;
        return [['message' => $message]];
    }

    /**
     * Function for sending push notification to a single user
     * @param integer $id user_id
     * @param string $message
     * @param array $responseData
     * @return boolean
     */
    public static function sendPushNotification ($id, $message, $responseData)
    {

        $userDeviceData = \common\models\UserDevices::find()->select('*')->where(['user_id' => $id])->distinct()->all();
        foreach ($userDeviceData as $userDevice) {
            if (!empty($userDevice)) {
                $deviceId = $userDevice->device_id;
                if (!empty($deviceId)) {

                    if ($userDevice->device_type == 'ios' && strlen($deviceId) == 64) {

                        if ($userDevice->certification_type == 'development') {
                            \Yii::$app->apns->environment = \bryglen\apnsgcm\Apns::ENVIRONMENT_SANDBOX;
                            \Yii::$app->apns->pemFile = 'apnscert/courtpals.pem';
                            $apns = \Yii::$app->apns;
                            $apns->send($deviceId, strip_tags($message), $responseData, [
                                'sound' => 'default',
                                'badge' => 1
                                    ]
                            );
                        } else if ($userDevice->certification_type == 'live' || $userDevice->certification_type == 'distribution') {
                            \Yii::$app->apns->environment = \bryglen\apnsgcm\Apns::ENVIRONMENT_PRODUCTION;
                            \Yii::$app->apns->pemFile = 'apnscert/courtpals.pem';
                            $apns = \Yii::$app->apns;
                            $apns->send($deviceId, strip_tags($message), $responseData, [
                                'sound' => 'default',
                                'badge' => 1
                                    ]
                            );
                        }
                    }

                    if ($userDevice->device_type == 'android') {
                        $gcm = Yii::$app->gcm;
                        $result = $gcm->send($deviceId, strip_tags($message), $responseData, [
                            'timeToLive' => 3
                                ]
                        );
                    }
                }
            }
        }

        return true;
    }

    /**
     * Function for sending push notifications to multiple users at a time 
     * @param array $ids Array of user Ids
     * @param string $message
     * @param array $responseData
     * @return boolean
     */
    public static function sendMultiPushNotification ($ids, $message, $responseData)
    {
        try {
            $androidDeviceIds = [];
            $iosLiveDeviceIds = [];
            $iosDevDeviceIds = [];
            $userDeviceData = \common\models\UserDevices::find()->select('*')->where(['user_id' => $ids, 'is_loggedin' => 1])->distinct()->all();
            foreach ($userDeviceData as $userDevice) {
           $approved = User::find()->where(['AND', ['=', 'id', $userDevice->user_id], ['=', 'approved', 'yes']])->one();
            if (!empty($approved)) {
                if (!empty($userDevice) && $userDevice->device_type == 'android' && !empty($userDevice->device_id)) {
                        $androidDeviceIds[] = $userDevice->device_id;
                    }
                    if (!empty($userDevice) && $userDevice->device_type == 'ios' && !empty($userDevice->device_id)) {
                        if (($userDevice->certification_type == 'prod' || $userDevice->certification_type == 'distribution') && (strlen($userDevice->device_id) == 64)) {
                            $iosLiveDeviceIds[] = $userDevice->device_id;
                        } elseif (($userDevice->certification_type == 'dev' || $userDevice->certification_type == 'development') && (strlen($userDevice->device_id) == 64)) {
                            $iosDevDeviceIds[] = $userDevice->device_id;
                        }
                    }
                }
            }
            if (!empty($androidDeviceIds)) {
                $gcm = Yii::$app->gcm;
                $result = $gcm->sendMulti($androidDeviceIds, strip_tags($message), $responseData, [
                    'timeToLive' => 3
                        ]
                );
            }
            if (!empty($iosDevDeviceIds)) {
                \Yii::$app->apns->environment = \bryglen\apnsgcm\Apns::ENVIRONMENT_SANDBOX;
                \Yii::$app->apns->pemFile = 'apnscert/courtpals.pem';
                $apns = \Yii::$app->apns;

                $apns->sendMulti($iosDevDeviceIds, strip_tags($message), $responseData, [
                    'sound' => 'default',
                    'badge' => 1
                        ]
                );
            }

            if (!empty($iosLiveDeviceIds)) {
                \Yii::$app->apns->environment = \bryglen\apnsgcm\Apns::ENVIRONMENT_PRODUCTION;
                \Yii::$app->apns->pemFile = 'apnscert/courtpals.pem';
                $apns = \Yii::$app->apns;
                $apns->sendMulti($iosLiveDeviceIds, strip_tags($message), $responseData, [
                    'sound' => 'default',
                    'badge' => 1
                        ]
                );
            }
            return true;
        } catch (Exception $Ex) {
            
        }
    }

    public static function sendMessagePushNotification($id, $message, $responseData) {

        $userDeviceData = \common\models\UserDevices::find()->select('*')->where(['user_id' => $id, 'is_loggedin' => 1])->distinct()->all();    
        
        foreach ($userDeviceData as $userDevice) {
           $approved = User::find()->where(['AND',['=','id', $userDevice->user_id],['=','approved','yes']])->one() ;
           if(!empty($approved)){
            if (!empty($userDevice) && $userDevice->device_type == 'android' && !empty($userDevice->device_id)) {
                $androidDeviceIds[] = $userDevice->device_id;
            }
            
            if (!empty($userDevice) && $userDevice->device_type == 'ios' && !empty($userDevice->device_id)) {
                    if (($userDevice->certification_type == 'prod' || $userDevice->certification_type == 'distribution') && (strlen($userDevice->device_id) == 64)) {
                        $iosLiveDeviceIds[] = $userDevice->device_id;
                    } elseif (($userDevice->certification_type == 'dev' || $userDevice->certification_type == 'development') && (strlen($userDevice->device_id) == 64)) {
                        $iosDevDeviceIds[] = $userDevice->device_id;
                    }
            }
        }
        }
        
        if (!empty($androidDeviceIds)) {
                $gcm = Yii::$app->gcm;
                $result = $gcm->sendMulti($androidDeviceIds, strip_tags($message), $responseData, [
                    'timeToLive' => 3
                    ]
                );
        }
        
        if (!empty($iosDevDeviceIds)) {
            \Yii::$app->apns->environment = \bryglen\apnsgcm\Apns::ENVIRONMENT_SANDBOX;
            \Yii::$app->apns->pemFile = 'apnscert/courtpals.pem';
            $apns = \Yii::$app->apns;
            
                $apns->sendMulti($iosDevDeviceIds, strip_tags($message), $responseData, [
                        'sound' => 'default',
                        'contentAvailable' => TRUE, 
                        'badge' => 1
                    ]
                );
           
        }

        if (!empty($iosLiveDeviceIds)) {
            \Yii::$app->apns->environment = \bryglen\apnsgcm\Apns::ENVIRONMENT_PRODUCTION;
            \Yii::$app->apns->pemFile = 'apnscert/courtpals.pem';
            $apns = \Yii::$app->apns;
            $apns->sendMulti($iosLiveDeviceIds, strip_tags($message), $responseData, [
                    'sound' => 'default',
                    'contentAvailable' => TRUE,  
                    'badge' => 1
                ]
            );
        }
        return true;
    }
    public static function sendWithoutAlertMessagePushNotification($id, $message, $responseData) {

     $userDeviceData = \common\models\UserDevices::find()->select('*')->where(['user_id' => $id, 'is_loggedin' => 1])->distinct()->all();
        foreach ($userDeviceData as $userDevice) {
            $approved = User::find()->where(['AND', ['=', 'id', $userDevice->user_id], ['=', 'approved', 'yes']])->one();
            if (!empty($approved)) {
                if (!empty($userDevice) && $userDevice->device_type == 'android' && !empty($userDevice->device_id)) {
                    $androidDeviceIds[] = $userDevice->device_id;
                }

                if (!empty($userDevice) && $userDevice->device_type == 'ios' && !empty($userDevice->device_id)) {
                    if (($userDevice->certification_type == 'prod' || $userDevice->certification_type == 'distribution') && (strlen($userDevice->device_id) == 64)) {
                        $iosLiveDeviceIds[] = $userDevice->device_id;
                    } elseif (($userDevice->certification_type == 'dev' || $userDevice->certification_type == 'development') && (strlen($userDevice->device_id) == 64)) {
                        $iosDevDeviceIds[] = $userDevice->device_id;
                    }
                }
            }
        }

        if (!empty($androidDeviceIds)) {
                $gcm = Yii::$app->gcm;
                $result = $gcm->sendMulti($androidDeviceIds, strip_tags($message), $responseData, [
                    'timeToLive' => 3
                    ]
                );
        }
        
        if (!empty($iosDevDeviceIds)) {
            \Yii::$app->apns->environment = \bryglen\apnsgcm\Apns::ENVIRONMENT_SANDBOX;
            \Yii::$app->apns->pemFile = 'apnscert/courtpals.pem';
            $apns = \Yii::$app->apns;
            
                $apns->sendMulti($iosDevDeviceIds, "", $responseData, [
                        'contentAvailable' => TRUE, 
                        'badge' => 1
                    ]
                );
           
        }

        if (!empty($iosLiveDeviceIds)) {
            \Yii::$app->apns->environment = \bryglen\apnsgcm\Apns::ENVIRONMENT_PRODUCTION;
            \Yii::$app->apns->pemFile = 'apnscert/courtpals.pem';
            $apns = \Yii::$app->apns;
            $apns->sendMulti($iosLiveDeviceIds, "", $responseData, [
                    'contentAvailable' => TRUE,  
                    'badge' => 1
                ]
            );
        }
        return true;
    }
    
    public static function generateCaseId ()
    {
        $randomString = substr(str_shuffle("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 7);
        return $randomString;
    }
    
    public static function getlatitudeLongitude($address) {
        
        //$address = $address->court_name.$address->address;
        $prepAddr = str_replace(' ', '+', $address);
      
        $geocode = file_get_contents('https://maps.google.com/maps/api/geocode/json?address=' . $prepAddr . '&sensor=false');
        $output = json_decode($geocode);

        // If Status Code is ZERO_RESULTS, OVER_QUERY_LIMIT, REQUEST_DENIED or INVALID_REQUEST        
        if ($output->status != 'OK') {
            return null;
        }
        $latLng['latitude'] = $output->results[0]->geometry->location->lat;
        $latLng['longitude'] = $output->results[0]->geometry->location->lng;

        return $latLng;
    }
    
    public static function getDateByTimezone($timezone, $date, $format = "Y-m-d H:i:s"){
        $serverTimezone = \Yii::$app->getTimeZone();
        $fromDate = new \DateTime($date, new \DateTimeZone($serverTimezone));
        $fromDate->setTimeZone(new \DateTimeZone($timezone));
        $current_time = $fromDate->format("Y-m-d H:i:s");
        return $current_time;
    }
    
    public static function getUserMedia($imageName,$type){
        $url = "";
        if(!empty($imageName))
        {
            if($type == 'image'){
                if(file_exists('../../api/web/uploads/media/'.$type.'/'.$imageName))
                    $url = Yii::getAlias('@media_url').'/'.$type.'/'.$imageName;
                else
                    $url = "";
            }else if($type == 'document'){
                if(file_exists('../../api/web/uploads/media/'.$type.'/'.$imageName))
                    $url = Yii::getAlias('@media_url').'/'.$type.'/'.$imageName;
                else
                    $url = "";
            }
            else if($type == 'thumb'){
                if(file_exists('../../api/web/uploads/media/image/thumb/'.$imageName))
                    $url = Yii::getAlias('@media_url').'/image/thumb/'.$imageName;
                else
                    $url = "";
            }
        }
        return $url;
    }
    
}
