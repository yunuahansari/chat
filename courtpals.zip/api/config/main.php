<?php

$params = array_merge(
        require(__DIR__ . '/../../common/config/params.php'), 
        require(__DIR__ . '/../../common/config/params-local.php'), 
        require(__DIR__ . '/params.php'), 
        require(__DIR__ . '/../../common/config/message.php'), 
        require(__DIR__ . '/params-local.php')
);

return [
    'id' => 'app-api',
    'name' => 'Courtpals',
    'basePath' => dirname(__DIR__),
    'bootstrap' => ['log'],
    'controllerNamespace' => 'api\controllers',
    'modules' => [
         'admin' => [
            'class' => 'app\modules\admin\Module',
        ],
    ],
    'components' => [
        'response' => [
            'class' => 'api\components\Response',
            'on beforeSend' => function ($event) {
                \yii::createObject([
                    'class' => 'api\components\ResponseHandler',
                    'event' => $event
                ])->formatResponse();
            },
                    'format' => 'json'
                ],
                'urlManager' => [
                    'enablePrettyUrl' => true,
                    'showScriptName' => false,
                    'rules' => [
                        [
                            'class' => 'yii\rest\UrlRule',
                            'controller' => ['account','list','transactions','messages'],
                        ],
                        '<controller>' => '<controller>/create',
                        '<controller>/<id:\d+>/<action:(update|delete)>' => '<controller>/<action>',
                        '<controller:\w+>/<id:\d+>' => '<controller>/view',
                        '<controller:\w+>s' => '<controller>/index',
                        '<controller:\w+>/<action:[\w.\-]+>/<id:\w+>' => '<controller>/<action>',
                    ]
                ],
                'user' => [
                    'identityClass' => 'api\models\User',
                    'enableAutoLogin' => true,
                ],
                'httpcookie' => [
                    'class' => 'yii\web\cookie',
                    'httponly' => true,
                ],
                'log' => [
                    'traceLevel' => YII_DEBUG ? 3 : 0,
                    'targets' => [
                        [
                            'class' => 'yii\log\FileTarget',
                            'levels' => ['error', 'warning'],
                        ],
                    ],
                ],
                'urlManagerFrontEnd' => [
                    'class'=>'\yii\web\urlManager',
                    'enablePrettyUrl' => true,
                    'showScriptName' => false,
                    'baseUrl'=>'http://courtpals.codiant.com/',
                    'rules' => [
                    ],
                ],
//                'errorHandler' => [
//                    'errorAction' => 'site/error',
//                ],
            ],
            'params' => $params,
        ];
        