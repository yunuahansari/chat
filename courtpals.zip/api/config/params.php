<?php

return [
    'adminEmail' => 'admin@example.com',
    'perPage' => 10,
    'defaultCommition'=>30,
    'GCM_API_KEY' => 'AIzaSyBKXwuz3WhMittrR_2ECeCVfbgRu6_zHq8',
    'zendesk_subdomain' => 'codianthelp',
    'zendesk_username' => 'courtpals@mailinator.com',
    'zendesk_token' => 'wuwYfl8Xd9lS0ng3XGDmzc48sU5g7ZfLaMMo32HF',
    
];
