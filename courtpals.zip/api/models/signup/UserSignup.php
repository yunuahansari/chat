<?php

namespace api\models\signup;

use yii\base\Model;
use yii;
/**
 * Description of NormalSignup
 *
 * @author hp
 */
class UserSignup extends SignupAbstract {

    public function rules()
    {
        return [
            [['first_name', 'last_name', 'email', 'password'], 'required', 'message' => '{attribute} is required.', 'on' => 'signup'],
            [['email'], 'email', 'message' => '{attribute} is not a valid email address.'],
            [['email'], 'unique', 'targetClass' => 'common\models\User', 'message' => '{attribute} is already registered with us', 'on' => 'signup'],
            [['first_name', 'last_name', 'email', 'device_id', 'device_type', 'certification_type', 'password'], 'safe'],
        ];
    }
    
    public function attributeLabels ()
    {
        return [            
            'first_name' => 'First Name',
            'last_name' => 'Last Name',
            'email' => 'Email',
            'password' => 'Password',            
        ];
    }
   
}
