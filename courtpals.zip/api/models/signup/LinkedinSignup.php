<?php

namespace api\models\signup;

use yii;
use yii\base\Model;
use api\models\User;
use api\models\UserDevices;
use common\models\StripeGateway;
use common\models\Settings;

/**
 * Description of NormalSignup
 *
 * @author hp
 */
class LinkedinSignup extends SignupAbstract {

    public $source_id;
    public $status = 'active';

    public function rules() {
        return [
            [['first_name', 'last_name'], 'required', 'message' => '{attribute} is required.', 'on' => 'signup'],
            [['email'], 'email', 'message' => '{attribute} is not a valid email address.'],
            [['email'], 'unique', 'filter' => ['status' => ['active', 'inactive']], 'targetClass' => 'common\models\User', 'message' => '{attribute} is already registered with us', 'on' => 'signup',],
            [['first_name', 'last_name', 'user_name', 'email', 'password', 'role', 'device_id', 'device_type', 'certification_type', 'profile_pic', 'type', 'source_id'], 'safe'],
        ];
    }

    public function attributeLabels() {
        return [
            'first_name' => 'First name',
            'last_name' => 'Last name',
            'email' => 'Email',
        ];
    }

    public function saveUser() {
       
        $connection = \Yii::$app->db;
        $transaction = $connection->beginTransaction();
        try {
            $authModel = \common\models\Auth::find()->where(['source_id' => $this->source_id])->one();
            if (empty($authModel)) {
                $model = new User();
                $model->attributes = $this->attributes;
                $check_exist_email = \common\models\User::find()->where(['email'=> $this->email])->one();
                if(!empty($check_exist_email)){
                    return \api\components\Utility::apiError(201, 'This email is already registered with us.');
                }
                //$model->commition = yii::$app->params['defaultCommition'];
                $model->commition = Settings::getCommissionFromSettings();
                $model->profile_pic = $this->profile_pic;
                $model->type = 'linkedin';
                $model->created_at = date('Y-m-d H:i:s');
                $model->scenario = 'signup';
                
                if ($this->validate() && $model->save(false)) {    
                    $customer = \common\models\StripeGateway::createCustomer(['email' => $model->email]);
                    if (!empty($customer) && $customer->id != '') {
                        User::updateAll(['stripe_customer_id' => $customer->id], ['id' => $model->id]);
                    }                   
                                        
                    $auth = new \common\models\Auth();
                    $auth->user_id = $model->id;
                    $auth->source_id = $this->source_id;
                    $auth->save(false);
                    $hearing_types = \common\models\HearingType::find()->where(['status' => 'active','parent' => 0])->all();

                    if (!empty($hearing_types)) {
                        foreach ($hearing_types as $hearing_type) {
                            $hearingDetail = new \common\models\HearingDetail();
                            $hearingDetail->user_id = $model->id;
                            $hearingDetail->hearing_type = $hearing_type->id;
                            $hearingDetail->save(false);
                        }
                    }

                    $userDevice = UserDevices::addUserDevice($model, $this->attributes);

                    $transaction->commit();
                    if (!$userDevice) {
                        return false;
                    } else {
                        $this->user = $userDevice;
                    }

//                    \Yii::$app->mailer->compose(['html' => 'userSignUp-html'], ['user' => $model])
//                            ->setFrom([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
//                            ->setTo($this->email)
//                            ->setReplyTo([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
//                            ->setSubject('Welcome to ' . \Yii::$app->name)
//                            ->send();
                }
            } else {
                $model = \common\models\User::findByAttr(['id' => $authModel->user_id]);
                 if(!$model || ($model->role == 'user' && $model->status == 'active' && $model->approved == 'no' && $model->profile_completed == 'yes')){
                     return \api\components\Utility::apiError(201, 'Your account is under review.');
                 }
                $model->attributes = $this->attributes;
                $userDevice = UserDevices::updateUserDevice($model, $this->attributes);
                $transaction->commit();
                if (!$userDevice) {
                    return false;
                } else {
                    $this->user = $userDevice;
                }
            }
            return $this->user;
        } catch (\Exception $e) {
            $this->addError('error', $e->getMessage());
            $transaction->rollBack();
            return $this;
        }
    }

}
