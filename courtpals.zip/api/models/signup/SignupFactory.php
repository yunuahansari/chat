<?php

namespace api\models\signup;

/**
 * Description of SignupFactory
 *
 * @author hp
 */
class SignupFactory {

    const TYPE_USER = 'user';
    const TYPE_AVVO = 'avvo';
    const TYPE_LINKEDIN = 'linkedin';  

    public static function create($provider = TYPE_USER) {
        if ($provider === static::TYPE_AVVO) {
            return new AvvoSignup();
        } else if ($provider === static::TYPE_LINKEDIN) {
            return new LinkedinSignup();
        }  else {
            return new UserSignup();
        }
    }

}
