<?php

namespace api\models\signup;

use yii;
use yii\base\Model;
use api\models\User;
use api\models\UserDevices;
use common\models\LoginForm;
use common\components\Utility;
use common\models\Settings;


/**
 * Description of SignupAbstract
 *
 * @author hp
 */
abstract class SignupAbstract extends Model {

    public $first_name;
    public $last_name;
    public $email;
    public $address;
    public $city;
    public $state;
    public $mobile;
    public $password;
    public $device_id;
    public $profile_pic;
    public $device_type;
    public $type;
    public $certification_type;
    public $role = User::ROLE_USER;
    public $status = 'inactive';
    protected $user;

    public function getUser() {
        return $this->user;
    }
    
    public function validateEmail($attribute, $param) {
        $user_id = yii::$app->user->identity->id;
        $sql = "SELECT * FROM user WHERE email = '" . $this->email . "' AND id != $user_id";
        $userDetail = Yii::$app->db->createCommand($sql)->queryAll();

        if (count($userDetail)) {
            $this->addError($attribute, 'Email '.$this->email.' has already been taken.');
        } else {
            return true;
        }
    }
    
    public static function login($data){
        $model = new LoginForm();
        $model->load($data, '');
        $model->login();
        if ($model->login()) {
            return true;
        }
    }
    
    public function saveUser() {
        $connection = \Yii::$app->db;
        $transaction = $connection->beginTransaction();
        try {
            if ($this->validate()) {
                $model = new User;
                $model->attributes = $this->attributes;
                //$model->commition = yii::$app->params['defaultCommition'];
                $model->commition = Settings::getCommissionFromSettings();
                $model->setPassword($this->password);
                $model->created_at = date('Y-m-d H:i:s');
                $model->verified_code = Utility::generateVerificationCode();
                if ($model->save(false)) {
                    $customer = \common\models\StripeGateway::createCustomer(['email' => $model->email]);
                    if(!empty($customer) && $customer->id != ''){
                        User::updateAll(['stripe_customer_id' => $customer->id], ['id' => $model->id]);
                    }
                    
                    $hearing_type = \common\models\HearingType::find()->where(['status' => 'active','parent' => 0])->all();
                    if(!empty($hearing_type)){
                        foreach ($hearing_type as $hearing_type){
                            $hearingDetail = new \common\models\HearingDetail();
                            $hearingDetail->user_id = $model->id;
                            $hearingDetail->hearing_type = $hearing_type->id;
                            $hearingDetail->save(false);
                        }
                    }
                    try{
                        \Yii::$app->mailer->compose(['html' => 'userSignUp-html'], ['user' => $model])
                        ->setFrom([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
                        ->setTo($this->email)
                        ->setReplyTo([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
                        ->setSubject('Welcome to ' . \Yii::$app->name)
                        ->send();
                    }catch (\Exception $e){

                    }
                    $transaction->commit();
                    
                    return true;
                } else {
                    return false;
                }
                
            }
        } catch (\Exception $e) {
            $this->addError('error', $e->getMessage());
            $transaction->rollBack();
            return false;
        }
    }
    
}
