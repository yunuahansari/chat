<?php

namespace api\models\signup;

use yii;
use yii\base\Model;
use api\models\User;
use api\models\UserDevices;
use common\models\Settings;

/**
 * Description of NormalSignup
 *
 * @author hp
 */
class AvvoSignup extends SignupAbstract
{

    public $source_id;
    public $status = 'active';
    
    public function rules ()
    {
        return [
            [['first_name', 'last_name'], 'required', 'message' => '{attribute} is required.', 'on' => 'signup'],
            [['email'], 'email', 'message' => '{attribute} is not a valid email address.'],
            [['email'], 'unique', 'targetClass' => 'common\models\User', 'message' => '{attribute} is already registered with us', 'on' => 'signup',],
            [['first_name', 'last_name', 'user_name', 'email', 'password', 'role', 'device_id', 'device_type', 'certification_type', 'profile_pic', 'type', 'source_id'], 'safe'],
        ];
    }

    public function attributeLabels ()
    {
        return [

            'user_name' => 'User name',
            'first_name' => 'First name',
            'last_name' => 'Last name',
            
        ];
    }

    public function saveUser ()
    {
        $connection = \Yii::$app->db;
        $transaction = $connection->beginTransaction();
        try {
            if ($this->validate()) {
                $authModel = \common\models\Auth::find()->where(['source_id' => $this->source_id])->one();

                if (empty($authModel)) {
                    $model = new User();
                    $model->attributes = $this->attributes;
                    //$model->commition = yii::$app->params['defaultCommition'];
                    $model->commition = Settings::getCommissionFromSettings();
                    $model->profile_pic = $this->profile_pic;
                    $model->type = 'avvo';
                    $model->created_at = date('Y-m-d H:i:s');
                    if($model->save(false)){
                        $customer = \common\models\StripeGateway::createCustomer(['email' => $model->email]);
                        if(!empty($customer) && $customer->id != ''){
                            User::updateAll(['stripe_customer_id' => $customer->id], ['id' => $model->id]);
                        }
                        $stripeAccount = \common\models\StripeGateway::createConnectAccount(['email' => $model->email]);
                        if(!empty($stripeAccount)){
                            User::updateAll(['stripe_account_id' => $stripeAccount->id], ['id' => $model->id]);
                        }
                    }
                    $auth = new \common\models\Auth();
                    $auth->user_id = $model->id;
                    $auth->source_id = $this->source_id;
                    $auth->save(false);
                    
                    $hearing_type = \common\models\HearingType::find()->where(['status' => 'active','parent' => 0])->all();
                    if(!empty($hearing_type)){
                        foreach ($hearing_type as $hearing_type){
                            $hearingDetail = new \common\models\HearingDetail();
                            $hearingDetail->user_id = $model->id;
                            $hearingDetail->hearing_type = $hearing_type->id;
                            $hearingDetail->save(false);
                        }
                    }
//                    \Yii::$app->mailer->compose(['html' => 'userSignUp-html'], ['user' => $model])
//                            ->setFrom([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
//                            ->setTo($this->email)
//                            ->setReplyTo([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
//                            ->setSubject('Welcome to ' . \Yii::$app->name)
//                            ->send();
                    $userDevice = UserDevices::addUserDevice($model, $this->attributes);
                    $transaction->commit();
                    if (!$userDevice) {
                        return false;
                    } else {
                        $this->user = $userDevice;
                    }
                } else {
                    $model = \common\models\User::findByAttr(['id' => $authModel->user_id]);
                    $model->first_name = $this->first_name;
                    $model->last_name = $this->last_name;
                    $model->email = $this->email;
                    $model->save(false);
                    $userDevice = UserDevices::updateUserDevice($model, $this->attributes);
                    $transaction->commit();
                    if (!$userDevice) {
                        return false;
                    } else {
                        $this->user = $userDevice;
                    }
                }

                return $this->user;
            }
        } catch (\Exception $e) {
            $this->addError('error', $e);
            $transaction->rollBack();
            return false;
        }
    }

}
