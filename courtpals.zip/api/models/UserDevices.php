<?php
namespace api\models;

use Yii;
use common\components\Utility;
use common\models\Notification;
use common\models\Message;

/**
 * This is the model class for table "user_devices".
 *
 * @property integer $id
 * @property integer $user_id
 * @property string $device_id
 * @property integer $is_loggedin
 * @property string $device_type
 * @property string $certification_type
 * @property string $access_token
 * @property string $created_at
 * @property string $updated_at
 *
 * @property User $user
 */
class UserDevices extends \common\models\UserDevices
{
   

    public static function tableName()
    {
        return 'user_devices';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['user_id', 'is_loggedin'], 'integer'],
            [['device_id', 'device_type'], 'string'],
            [['created_at', 'updated_at'], 'safe'],
            [['certification_type', 'access_token'], 'string', 'max' => 255]
        ];
    }
    
    public function fields() 
    {
        $fields = parent::fields();
        $fields = [
            'device_id',
            'device_type',
            'certification_type',
            'access_token',
            'is_loggedin',
            'unread_notification_count'=>function($model){
                return Notification::newNotification($model->user_id);
            },
            'unread_thread_count' => function($model){
                        return Message::unreadThreadCount($model->user_id);
            },
            'user' => function($model){
                return $model->user;                      
            },
            
        ];
        return $fields;
    }
    

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'user_id' => 'User ID',
            'device_id' => 'Device ID',
            'is_loggedin' => 'Is Loggedin',
            'device_type' => 'Device Type',
            'certification_type' => 'Certification Type',
            'access_token' => 'Access Token',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUser()
    {
        return $this->hasOne(User::className(), ['id' => 'user_id']);
    }
    
    public function generateAccessToken()
    {
       $this->access_token = Yii::$app->security->generateRandomString(50);
    }
    
    public static function addUserDevice($user, $data) 
    {
       
        $userDevices = new UserDevices();
        $userDevices->generateAccessToken();
        $userDevices->attributes = $data;
        $userDevices->is_loggedin = 1;
        $userDevices->user_id = $user->id;
       
        if ($userDevices->save(false))
            return $userDevices;
        else
            return false;
    }
    
    public static function updateUserDevice($user, $data)
    {
        if(!isset($data['device_id'])){
          $data['device_id']= null;  
        }
        $userDevices = self::getUserDeviceByAttr(['user_id'=> $user->id]);
        if(empty($userDevices)){
            $userDevices = new \api\models\UserDevices();
        }
        $userDevices->generateAccessToken();
        $userDevices->attributes = $data;
        $userDevices->is_loggedin = 1;
        $userDevices->updated_at = date('Y-m-d H:i:s');
        $userDevices->user_id = $user->id;
        if ($userDevices->save(false))
            return $userDevices;
        else
            return false;
    }

    public static function getUserDeviceByAttr($attr)
    {
        return self::find()->where($attr)->one();
    }
    
    public static function logout($access_token)
    {
        $userDevices = self::getUserDeviceByAttr(['access_token'=> $access_token]);
        $userDevices->access_token = '';
        $userDevices->is_loggedin = 0;
        \Yii::$app->user->logout();
        return $userDevices->save(false);
    }
    
}
