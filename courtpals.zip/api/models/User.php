<?php

namespace api\models;

use yii;
use yii\helpers\ArrayHelper;
use yii\data\SqlDataProvider;
use api\components\Utility;
use yii\imagine\Image;
use yii\web\UploadedFile;
use common\models\UserSpecialization;
use common\models\UserSubSpecialization;
use common\models\Blog;
use common\models\Review;

/**
 * Description of User
 *
 * @author hp
 */
class User extends \common\models\User
{

    const ROLE_USER = 'user';
    
    public function rules ()
    {
        return ArrayHelper::merge(parent::rules(), [
                    [['first_name', 'last_name', 'email', 'password'], 'safe']
        ]);
    }

    public function fields ()
    {

        $fields = parent::fields();
        $fields1 = [
            
        ];
        unset($fields['password'], $fields['type'], $fields['verified_code'], $fields['auth_key'], $fields['created_at'], $fields['updated_at']);
        return ArrayHelper::merge($fields, $fields1);
    }

   

    public static function getUserByAttr ($attr)
    {
        return self::find()->where($attr)->one();
    }

    public static function getAllUserByAttr ($attr)
    {
        return self::find()->where($attr)->all();
    }

    public static function checkEmailExists ($email)
    {
        $model = User::findOne(['email' => $email]);
        if ($model === null) {
            return false;
        } else {
            return true;
        }
    }

    public static function logout ($accesstoken)
    {
        $user = self::getUserByAttr(['access_token' => $accesstoken]);
        if (!empty($user)) {
            $user->access_token = null;
            if ($user->save(false)) {
                if (Yii::$app->user->logout()) {
                    return true;
                }
            }
        }
        return false;
    }

    public static function adminDashboard ()
    {
        $sql = "SELECT  (SELECT COUNT(*) FROM user WHERE user_role='user' AND status!='deleted') AS users, (SELECT COUNT(*) FROM user WHERE user_role='agent' AND status!='deleted') AS agents, (SELECT COUNT(*) FROM job WHERE status!='deleted' ) AS jobs FROM dual";
        $result = yii::$app->db->createCommand($sql)->queryOne();
        return $result;
    }

    public static function changeUserStatus ($post)
    {
        $user = self::getUserByAttr(['id' => $post['id']]);
        if (!empty($user)) {
            $user->status = $post['status'];
            $user->save(false);
            return true;
        } else {
            return false;
        }
    }

    public static function saveImage ()
    {
        $user = self::getUserByAttr(['id' => \Yii::$app->user->identity->id]);
        $file = UploadedFile::getInstanceByName('image');
        if (!empty($file)) {
            if ($imagename = self::uploadImage($file)) {
                return $imagename;
            } else {
                return false;
            }
        }
    }

    public static function uploadImage ($file)
    {
        $filePath = './upload/user/profile/';
        if (!is_dir($filePath)) {
            mkdir($filePath, 0777, true);
        }
        $name = strtolower($file->baseName) . time() . '.' . $file->extension;
        if ($file->saveAs($filePath . $name)) {
            return $name;
        }
        return false;
    }

    public static function uploadCv ($file)
    {
        $filePath = './uploads/user/cv/';
        if (!is_dir($filePath)) {
            mkdir($filePath, 0777, true);
        }
        if (!empty($file)) {
            $name = strtolower($file->baseName) . time() . '.' . $file->extension;
            if ($file->saveAs($filePath . $name)) {
                return $name;
            }
        }
        return false;
    }

    public function setPassword ($password)
    {
        $this->password = Yii::$app->security->generatePasswordHash($password);
    }

    public function getUserSpecializations ()
    {
        return $this->hasMany(UserSpecialization::className(), ['user_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUserSubSpecializations ()
    {
        return $this->hasMany(UserSubSpecialization::className(), ['user_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getBlogs ()
    {
        return $this->hasMany(Blog::className(), ['user_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getReviews0 ()
    {
        return $this->hasMany(Review::className(), ['to_user_id' => 'id']);
    }

}
