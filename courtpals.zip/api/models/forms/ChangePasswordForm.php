<?php
namespace api\models\forms;
use yii;
use yii\base\Model;
use api\models\User;
use api\models\UserDevices;
use common\components\Utility;

class ChangePasswordForm extends User {

    public $password;
    public $new_password; 
    public function rules() {
        return [
            [['password', 'new_password'], 'required' ,'message' => '{attribute} is required'],
            [['password'], 'validate_current_pasword'],
        ];
    }
    
   public function validate_current_pasword($attribute, $param) {
        $request = Yii::$app->request->headers;
      
        $user = \common\models\User::getUserByAttr(['id'=>  \Yii::$app->user->id]);
        $incurrect_message = 'Current Password is incorrect';
        if (!Yii::$app->getSecurity()->validatePassword($this->password, $user->password)){
            $this->addError($attribute, $incurrect_message);
        }
        $identical_message = 'Current Password and New Password should not be Identical';
        if($this->password == $this->new_password){
            $this->addError($attribute, $identical_message);
        }
    }
    
    public static function changeUserPassword($id,$data){
   
        $user_model = User::getUserByAttr(['id'=>$id]);
        $user_model->password = \Yii::$app->security->generatePasswordHash($data['new_password']);
        $user_model->save(false);
        return $user_model;
    }
}

