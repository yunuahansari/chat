<?php
namespace api\models\forms;
use yii;
use yii\base\Model;
use api\models\User;
use common\components\Utility;

class ForgotPasswordForm extends User {
  
    public function rules() {
        return [
            [['email'], 'required', 'on' => 'forgot', 'message' => '{attribute} is required.'],
            [['email'], 'email', 'on' => 'forgot', 'message' => '{attribute} is not a valid email address.'],
            [['email'], 'validate_user_by_email', 'on' => 'forgot'],
            [['verified_code', 'new_password'], 'required', 'on' => 'reset'],
            [['new_password', 'confirm_password'], 'required', 'on' => 'reset-web', 'message' => '{attribute} is required.'],
            [['verified_code'], 'validate_user_by_code', 'on' => 'reset'],
            [['confirm_password'], 'compare', 'compareAttribute' => 'new_password', 'operator' => '==', 'message' => '{attribute}  must be same.', 'on' => 'reset'],
            [['email', 'verified_code', 'new_password', 'confirm_password'], 'safe'],
        ];
    }
    
    /**
     * @inheritdoc
     */
    public function attributeLabels ()
    {
        return [
            'email' => 'Email',
            'new_password' => 'New password',
            'confirm_password' => 'Confirm password',
        ];
    }
    
    public function validate_user_by_email($attribute, $param) {
     $attribute = 'Email';
     $message = 'Email does not exist';
     $user = User::getUserByAttr(['email' => $this->email]);
        if (empty($user)){
            $this->addError($attribute, $message);
        }
    }
    public function validate_user_by_code($attribute, $param) {
     $attribute = 'Verification code';
     $message = 'Verification code is not valid';
     $user = User::getUserByAttr(['verified_code' => $this->verified_code]);
        if (empty($user)){
            $this->addError($attribute, $message);
        }
    }
    
     public function sendResetCode(){
        $user = User::findByEmail($this->email);
        $user->verified_code = Utility::generateVerificationCode();
        if($user->save(false)){
            try{
                return \Yii::$app->mailer->compose(['html' => 'passwordResetToken-html'], ['user' => $user])
                    ->setFrom([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
                    ->setTo($this->email)
                    ->setReplyTo([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
                    ->setSubject('Password reset for ' . \Yii::$app->name)
                    ->send();  
            }catch (\Exception $e){
        
            }
        }
        return true;
    }
    public function resetPassword($token){
        $user = User::getUserByAttr(['verified_code' => $token]);
            if (!empty($user)) {
                $user->password = \Yii::$app->getSecurity()->generatePasswordHash($this->new_password);
                $user->verified_code = '';
                if($user->save(false))
                return true;
            }return false;
    }
        
}