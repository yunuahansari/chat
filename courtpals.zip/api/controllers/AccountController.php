<?php

namespace api\controllers;

use yii;
use yii\helpers\ArrayHelper;
use yii\web\Response;
use yii\filters\AccessControl;
use common\models\Notification;
use common\models\LoginForm;
use api\components\Controller;
use api\models\User;
use api\models\signup\SignupFactory;
use api\models\forms\ChangePasswordForm;
use api\models\UserDevices;
use api\models\forms\ForgotPasswordForm;
use api\models\ResetPasswordForm;

class AccountController extends Controller
{

    public static function allowedDomains() {
    return [
     '*',                        // star allows all domains
     'http://localhost/courtpals',
   
     ];
      }
    public function behaviors ()
    {
        return ArrayHelper::merge(parent::behaviors(), [
            'authenticator' => [
                'except' => ['index', 'signup', 'login', 'forgot', 'forgot-password', 'reset-password','send-email']
            ],
        ]);
    }

    public function actionSignup ($id = 'user')
    {
        $model = SignupFactory::create($id);
        $data = $this->requestParams;
        $model->load($data, '');
        $model->scenario = 'signup';
        if ($return = $model->saveUser()) {
            return $return;
        } else {
            return $model;
        }
    }

    /*
     * User login
     */

    public function actionLogin ()
    {
        $model = new LoginForm();
        $data = $data = $this->requestParams;
        $model->load($data, '');
        if ($model->login()) {
            $user = $model->getUser();
            $userDevice = UserDevices::getUserDeviceByAttr(['user_id' => $user->id]);
            if (empty($userDevice)) {
                $userDevice = UserDevices::addUserDevice($user, $data);
            } else {
                $userDevice = UserDevices::updateUserDevice($user, $data);
            }
            return $userDevice;
        } else {
            return $model;
        }
    }

    public function actionForgotPassword ()
    {
        $model = new ForgotPasswordForm();
        $rawData = Yii::$app->request->getRawBody();
        $data = json_decode($rawData, true);
        $model->load($data, '');
        $model->scenario = 'forgot';
        if ($model->validate() && $model->sendResetCode()) {
            return TRUE;
        } else {
            return $model;
        }
    }

    /*
     * Reset Password
     */

    public function actionResetPassword ()
    {
      
        $model = new ForgotPasswordForm();
        $rawData = Yii::$app->request->getRawBody();
        $data = json_decode($rawData, true);
        $model->load($data, '');
        $model->scenario = 'reset';
        if ($model->validate()) {
            $user = User::getUserByAttr(['verified_code' => $data['verified_code']]);

            if (!empty($user)) {
                $user->password = \Yii::$app->getSecurity()->generatePasswordHash($data['new_password']);
                $user->verified_code = '';
                $user->save(false);
            }
            return true;
        } else {
            return $model;
        }
    }
    
    public function actionSendEmail(){
        $data = $data = $this->requestParams;
        try{
            Yii::$app->mailer->compose(['html' => 'contactUsMail-html'], ['data' =>$data])
              ->setFrom([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
              ->setTo($data['email'])
              ->setReplyTo([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
              ->setSubject('testing email')
              ->send();
        echo 'email sent';
        exit;
        }catch(\Exception $e){
            echo $e->getMessage(); exit;
        }
    }
    
}
