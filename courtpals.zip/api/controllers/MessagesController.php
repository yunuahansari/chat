<?php
namespace api\controllers;

use yii;
use api\components\Controller;
use yii\filters\AccessControl;
use yii\helpers\ArrayHelper;
use common\models\Message;

class MessagesController extends Controller
{

    public $serializer = [
        'class' => 'yii\rest\Serializer',
        'collectionEnvelope' => 'items',
    ];
     
    public function behaviors ()
    {
        return ArrayHelper::merge(parent::behaviors(), [
            'authenticator' => [
                'except' => []
            ]
        ]);
    }

    public function actionIndex(){
        $data = $this->requestParams;
        return Message::getInbox($data);
    }
   
    public function actionDetail(){
        $data = $this->requestParams;
        return Message::getDetail($data);
    }
    
    public function actionSendMultiMediaMessage(){
        $data = \Yii::$app->request->getBodyParams();
        return Message::saveMultiMediaMessage($data);
    }
    
    public function actionSaveMessage(){
        $data = $this->requestParams;
        return Message::saveMessage($data);
    }

    public function actionReadMessage(){
        $data = $this->requestParams;
        return Message::readMessage($data);
    }
    public function actionDelete(){
        $data = $this->requestParams;
        return Message::deleteMessage($data);
    }
    public function actionDeleteAll(){
        $data = $this->requestParams;
        return Message::deleteAlleMessage($data);
    }
    public function actionDeleteAllThread(){
        $data = $this->requestParams;
        return Message::deleteAlleMessage();
    }

}

?>