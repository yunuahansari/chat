<?php

namespace api\controllers;

use yii;
use api\components\Controller;
use yii\filters\AccessControl;
use yii\helpers\ArrayHelper;
use common\models\Transactions;

class TransactionsController extends Controller
{
    public $serializer = [
        'class' => 'yii\rest\Serializer',
        'collectionEnvelope' => 'items',
    ];
    
    public function behaviors ()
    {
        return ArrayHelper::merge(parent::behaviors(), [
            'authenticator' => [
                'except' => []
            ]
        ]);
    }
    
    public function actionIndex(){
        $data = $this->requestParams;
        return Transactions::getTransactions($data);
    }
    
    public function actionCreate(){
        $data = $this->requestParams;
        return Transactions::addTransaction($data);
    }
    
    public function actionTotals(){
        return Transactions::getTransactionTotals();
    }

}

?>