<?php
namespace api\controllers;

use yii;
use yii\helpers\ArrayHelper;
use api\components\Controller;
use common\models\Address;
use common\models\CaseRequest;

class CronController extends Controller
{
     public function behaviors ()
    {
        return ArrayHelper::merge(parent::behaviors(), [
            'authenticator' => [
                'except' => ['run','add-card','create-token','delete-past-caserequest']
            ]
        ]);
    }
    
    public function actionRun(){
        //Address::saveLatLong();
        CaseRequest::cancelPastRequest();
        CaseRequest::deletePastCase();
    }
   
    public function actionCreateToken(){
        \Stripe\Stripe::setApiKey("sk_test_YgKUrVKz8tAZ9rDjde3Is31E");

        $result = \Stripe\Token::create(array(
          "card" => array(
            "number" => "4242424242424242",
            "exp_month" => 10,
            "exp_year" => 2018,
            "cvc" => "314"
          )
        ));
        
        echo '<pre>';
        print_r($result);
        exit;
    }
        
}