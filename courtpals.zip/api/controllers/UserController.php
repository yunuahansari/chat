<?php

namespace api\controllers;

use yii;
use api\components\Controller;
use yii\filters\AccessControl;
use common\models\LoginForm;
use common\models\Review;
use api\models\User;
use api\models\signup\SignupFactory;
use api\models\forms\ChangePasswordForm;
use api\models\UserDevices;
use api\models\forms\ForgotPasswordForm;
use api\models\ResetPasswordForm;
use yii\helpers\ArrayHelper;
use yii\web\Response;
use common\models\Address;
use common\models\AddressFav;
use common\models\BankAccountDetail;
use common\models\CaseCancelledRequest;
use common\models\Notification;

class UserController extends Controller
{

    public function behaviors ()
    {
        return ArrayHelper::merge(parent::behaviors(), [
            'authenticator' => [
                'except' => ['index']
            ]
        ]);
    }

    /*
     * User change password
     */

    public function actionChangePassword ()
    {
        
        $model = new ChangePasswordForm();
        $model->load($this->requestParams, '');
        if($model->validate()) {
            $user_id = \Yii::$app->user->getId();
            $data = $this->requestParams;
            return ChangePasswordForm::changeUserPassword($user_id,$data);
            return true;
        } else {
            return $model;
        }
    }

    public function actionLogout ()
    {
        $access_token = \Yii::$app->request->getHeaders()->get('access-token');
        if (UserDevices::logout($access_token))
            return true;
        else
            return false;
    }

    
    public function actionUpdate()
    {
        $data = \yii::$app->request->getBodyParams();
        return \common\models\User::updateUserDetail($data);
    }

    
    public function actionProfile ($id)
    {
        
        $data = $this->requestParams;
        if(!empty($data) && !empty($data['case_id'])){
            return Review::getCaseDetail($data);
        }else{
            $profile_data = \api\models\UserDevices::getUserDeviceByAttr(['user_id' => $id]);
            if(!empty($profile_data)){
             return $profile_data;   
            }
        }
        return false;
    }

    public function actionAddAddress(){
        $data = $this->requestParams;
        return Address::addAddress($data);
        
    }
    
    public function actionRatingReview(){
        $data = $this->requestParams;
        return Review::giveRating($data);
        
    }
    
    public function actionGetRatingStatus(){
        return Notification::checkRatingRequest();      
    }
    
    public function actionRefundRequest($id){
        return CaseCancelledRequest::addCancelRequest($id);
        
    }
    
    public function actionFavouriteAddress(){
        $data = $this->requestParams;
        return AddressFav::favouriteUnfavourite($data);
        
    }
    
    public function actionAddBankDetail(){
        
        $data = $this->requestParams;
        return BankAccountDetail::addBankDetail($data);
        
    }
    
    public function actionSettings(){
        $data = $this->requestParams;
        return \common\models\User::saveSettings($data);
    }
    public function actionFavouriteAddressList(){
     
        return AddressFav::getListOfFavouriteAddress();
    }
    public function actionContactUs(){
           $data = $this->requestParams;
        return \common\models\User::sendContactUsMail($data);
    }
    public function actionEditBankDetail(){
           $data = $this->requestParams;
        return BankAccountDetail::editBankDetail($data);
    }
    public function actionDeleteBankDetail($id){
        return BankAccountDetail::deleteBankDetail($id);
    }

}

?>