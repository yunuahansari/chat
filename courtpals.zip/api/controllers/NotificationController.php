<?php

namespace api\controllers;

use yii;
use api\components\Controller;
use yii\filters\AccessControl;
use yii\helpers\ArrayHelper;
use common\models\Notification;



class NotificationController extends Controller
{

     public $serializer = [
        'class' => 'yii\rest\Serializer',
        'collectionEnvelope' => 'items',
    ];
    public function behaviors ()
    {
        return ArrayHelper::merge(parent::behaviors(), [
            'authenticator' => [
                'except' => ['index']
            ]
        ]);
    }

    /*
     * User change password
     */

    public function actionAll(){
        $data = $this->requestParams;
        return Notification::getAllNotification($data);
    }
    public function actionDelete($id){
        return Notification::deleteNotification($id);
    }
    public function actionDeleteAll(){
        return Notification::deleteAllNotification();
    }



}

?>