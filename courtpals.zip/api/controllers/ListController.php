<?php

namespace api\controllers;

use yii;
use api\components\Controller;
use yii\filters\AccessControl;
use yii\helpers\ArrayHelper;
use common\models\Cities;



class ListController extends Controller
{

     public $serializer = [
        'class' => 'yii\rest\Serializer',
        'collectionEnvelope' => 'items',
    ];
    public function behaviors ()
    {
        return ArrayHelper::merge(parent::behaviors(), [
            'authenticator' => [
                'except' => ['index','cities']
            ]
        ]);
    }

    /*
     * User change password
     */

    public function actionCities(){
        $data = $this->requestParams;
        return Cities::getListOfCities();
    }
   
    public function actionAddress(){
        $data = $this->requestParams;
        return \common\models\Address::getAddress($data);
    }


}

?>