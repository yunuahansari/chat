<?php

namespace api\controllers;

use yii;
use api\components\Controller;
use yii\filters\AccessControl;
use yii\helpers\ArrayHelper;
use common\models\CaseRequest;


class RequestController extends Controller
{

     public $serializer = [
        'class' => 'yii\rest\Serializer',
        'collectionEnvelope' => 'items',
    ];
    public function behaviors ()
    {
        return ArrayHelper::merge(parent::behaviors(), [
            'authenticator' => [
                'except' => ['index','departments']
            ]
        ]);
    }

    /*
     * User change password
     */
    
    public function actionDepartments($id){
        return \common\models\Departments::getAllDepartments($id);
    }
    
    public function actionHearingType(){
        return \common\models\HearingType::getAllHearingType();
    }

    public function actionSubHearingType($id){
        return \common\models\HearingType::getAllSubHearingType($id);
    }
    
    public function actionList(){
        $data = $this->requestParams;
        return CaseRequest::getRequestList($data);
    }
    public function actionView($id){
        return CaseRequest::getRequestDetail($id);
    }

    public function actionCreate ()
    {
        $data = \Yii::$app->request->getBodyParams();
        return CaseRequest::postCaseRequest($data);
        
    }
    public function actionGenerateCaseId()
    {
        return CaseRequest::generateCaseId();
  
    }
    public function actionAcceptReject(){
        $data = $this->requestParams;
        return CaseRequest::cancelAcceptRequest($data);
    }
    
    public function actionCaseReview()
    {
        $data = $this->requestParams;
        return \common\models\CaseReviews::caseReview($data);
    }
    
    public function actionCaseCancelMessage()
    {
        $data = $this->requestParams;
        return CaseRequest::caseCancelMessage($data);
    }

}

?>