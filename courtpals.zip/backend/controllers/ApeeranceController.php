<?php

namespace backend\controllers;

use yii;
use yii\web\Controller;
use yii\filters\AccessControl;
use api\models\forms\ChangePasswordForm;
use common\models\CaseRequest;
use yii\web\Response;
use yii\widgets\ActiveForm;
use common\models\User;


Class ApeeranceController extends Controller
{
    public function behaviors() {

        return [
            'access' => [
                'class' => AccessControl::className(),
                'rules' => [
                    [
                        'allow' => Yii::$app->user->isAdmin(),
                    ],
                ],
            ],
        ];
    }
  public function actionIndex ()
    {
      
        return $this->render('index');
    }
    public function actionApeeranceList(){
          $post = \yii::$app->request->get();
          $users_cases = CaseRequest::apeeranceList($post);
          return $this->renderPartial('_apeerance_list',['apeerances'=>$users_cases]);
    }

    public function actionApeeranceDetail($id){
        $user = User::find()->where(['id' => $id])->one();
        return $this->render('apeerance',['user'=>$user]);
    }
    public function actionAttorneyCases(){
        $detail =  CaseRequest::attorneyCases();
        if(!empty($detail)){
           return $this->renderPartial('_case_request',['cases'=>$detail]);
        }
    }
    
    
}
?>