<?php

namespace backend\controllers;

use yii;
use yii\web\Controller;
use yii\filters\AccessControl;
use yii\web\Response;
use yii\widgets\ActiveForm;
use common\models\Transactions;
use common\models\User;
use common\models\StripeGateway;
use backend\models\Refund;

Class PaymentController extends Controller
{

    public function behaviors() {

        return [
            'access' => [
                'class' => AccessControl::className(),
                'rules' => [
                    [
                        'allow' => Yii::$app->user->isAdmin(),
                    ],
                ],
            ],
        ];
    }
    
    public function actionIndex ()
    {
        return $this->render('payment');
    }

    public function actionReceivedPaymentList ()
    {
        $post = \yii::$app->request->get();
        $model = Transactions::getReceivedPayment($post);
        return $this->renderPartial('_received_payment', ['model' => $model]);
    }

    public function actionSentPaymentList ()
    {
        $post = \yii::$app->request->get();
        $model = Transactions::getSentPayment($post);
        return $this->renderPartial('_sent_payment', ['model' => $model]);
    }

    public function actionReceiverVeiw ($id,$timezone)
    {
        $user = Transactions::getReceiverUserDetail($id,$timezone);
        if (!empty($user)) {
            return $this->renderPartial('receiver_veiw', ['user' => $user]);
        }
    }
    
    public function actionSenderVeiw ($id,$timezone)
    {
        $user = Transactions::getSenderUserDetail($id,$timezone);
        if (!empty($user)) {
            return $this->renderPartial('sender_veiw', ['user' => $user]);
        }
    }
    
    public function actionMakePayment(){
        $requestId = \Yii::$app->request->get('requestId');
        $data = Transactions::getPeerAttorneyPaymentData($requestId);
        $model = new Transactions();
        return $this->renderAjax('_payment-peer-attorney',['data' => $data, 'model' => $model]);
    }
    
    public function actionProcessRefund(){
        $requestId = \Yii::$app->request->get('requestId');
        $model = new Refund();
        if(\Yii::$app->request->isAjax && !empty(\Yii::$app->request->post())){
            $response = Refund::processRefund(\Yii::$app->request->post('Refund'));
            if($response){
                Yii::$app->session->setFlash('success', "Refund processed successfully.");
            }
            return json_encode($response);
        }
        $data = Refund::getRefundData($requestId);
        return $this->renderAjax('_process-refund',['data' => $data, 'model' => $model]);
    }

    public function actionMakeAttorneyPayment(){
        $post = \Yii::$app->request->post('Transactions');
        if (Yii::$app->request->isAjax) {
            $return = Transactions::addTransfer($post);
            if($return){
                Yii::$app->session->setFlash('success', "Payment processed successfully.");
            }
            return json_encode(array('success' => true));
        }
        
    }
    
    public function actionDeleteConnectAccount(){
        StripeGateway::deleteConnectAccount();
    }
    
    public function actionCancelRequestList ()
    {
        $post = \yii::$app->request->get();
        $model = \common\models\CaseCancelledRequest::getCancelRequest($post);
        return $this->renderPartial('_cancel_request', ['model' => $model]);
    }

}

?>