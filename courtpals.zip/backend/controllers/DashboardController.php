<?php

namespace backend\controllers;

use yii;
use yii\web\Controller;
use yii\filters\AccessControl;
use api\models\forms\ChangePasswordForm;
use common\models\User;
use yii\web\Response;
use yii\widgets\ActiveForm;
use common\models\CaseRequest;
use common\models\Settings;

Class DashboardController extends Controller {

    public function behaviors() {

        return [
            'access' => [
                'class' => AccessControl::className(),
                'rules' => [
                    [
                        'allow' => Yii::$app->user->isAdmin(),
                    ],
                ],
            ],
        ];
    }

    public function actionIndex() {
        $deatil = CaseRequest::findDashBoardDetail();
        return $this->render('index', ['deatil' => $deatil]);
    }

    public function actionSettings() {
        if (!empty(Yii::$app->request->post())) {
            $model = new Settings();
            if (Yii::$app->request->isAjax && !$model->validate()) {
                Yii::$app->response->format = Response::FORMAT_JSON;
                return ActiveForm::validate($model);
            }
            $post = Yii::$app->request->post('Settings');
            $model->saveSettings($post);
            Yii::$app->session->setFlash('success', "Your settings were saved successfully");
            return $this->redirect('settings');
        } else {
            $model = Settings::find()->all();
            return $this->render('_settings', ['model' => $model]);
        }
    }

}

?>