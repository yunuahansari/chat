<?php

namespace backend\controllers;

use yii;
use yii\web\Controller;
use yii\filters\AccessControl;
use api\models\forms\ChangePasswordForm;
use common\models\User;
use yii\web\Response;
use yii\widgets\ActiveForm;
use common\models\Review;
use common\models\BankAccountDetail;
use DateTime;

Class AttorneyController extends Controller
{

    public function behaviors ()
    {

        return [
            'access' => [
                'class' => AccessControl::className(),
                'rules' => [
                    [
                        'allow' => Yii::$app->user->isAdmin(),
                    ],
                ],
            ],
        ];
    }

    public function actionIndex ($tab = "")
    {
        return $this->render('index', ['tab' => $tab]);
    }

    public function actionAttorneyList ($timezone)
    {
        $post = \yii::$app->request->get();
        $users = User::allAttornyList($post, $timezone);
        return $this->renderPartial('_attorney_list', ['users' => $users, 'type' => $post['type']]);
    }

    public function actionNotApprovedAttorneyList ($timezone)
    {
        $post = \yii::$app->request->get();
        $users = User::allAttornyList($post, $timezone);
        return $this->renderPartial('_attorney_list', ['users' => $users, 'type' => $post['type']]);
    }

    public function actionNotEmailVerifiedAttorneyList ($timezone)
    {
        $post = \yii::$app->request->get();
        $users = User::allAttornyList($post, $timezone);
        return $this->renderPartial('_attorney_list', ['users' => $users, 'type' => $post['type'], 'tab' => '']);
    }

    public function actionBannedAttorneyList ($timezone)
    {
        $post = \yii::$app->request->get();
        $users = User::allAttornyList($post, $timezone);
        return $this->renderPartial('_banned_attorney_list', ['users' => $users, 'type' => $post['type']]);
    }

    public function actionActiveInactiveAttorny ()
    {
        $post = $_POST;
        $result = User::activeInactiveAttorny($post);

        if ($result) {
            if ($result == 'active') {
                \Yii::$app->session->setFlash('active_success', "Account has been activated");
                return 'active';
            } else {
                \Yii::$app->session->setFlash('inactive_success_inactive', "Account has been deactivated");
                return 'inactive';
            }
        }
    }

    public function actionAttorneyView ($id)
    {

        $model = User::find()->select('user.*')->join('left join', 'bank_account_detail', 'user.id=bank_account_detail.user_id')->where(['user.id' => $id])->one();
        $bank_detail = BankAccountDetail::find()->where(['user_id' => $id])->one();
        return $this->render('attorney-view', ['user' => $model, 'bank_detail' => $bank_detail, 'tab' => 'approved']);
    }

    public function actionUnverifiedAttorneyView ($id)
    {

        $model = User::find()->select('user.*')->join('left join', 'bank_account_detail', 'user.id=bank_account_detail.user_id')->where(['user.id' => $id])->one();
        $bank_detail = BankAccountDetail::find()->where(['user_id' => $id])->one();
        return $this->render('unverified_attorney_view', ['user' => $model, 'bank_detail' => $bank_detail, 'tab' => 'unverified']);
    }

    public function actionPendingAttorneyView ($id)
    {

        $model = User::find()->select('user.*')->join('left join', 'bank_account_detail', 'user.id=bank_account_detail.user_id')->where(['user.id' => $id])->one();
        $bank_detail = BankAccountDetail::find()->where(['user_id' => $id])->one();
        return $this->render('pending_attorney_view', ['user' => $model, 'bank_detail' => $bank_detail, 'tab' => 'pending']);
    }

    public function actionBannedAttorneyView ($id)
    {

        $model = User::find()->select('user.*')->join('left join', 'bank_account_detail', 'user.id=bank_account_detail.user_id')->where(['user.id' => $id])->one();
        $bank_detail = BankAccountDetail::find()->where(['user_id' => $id])->one();
        return $this->render('banned_attorney_view', ['user' => $model, 'bank_detail' => $bank_detail, 'tab' => 'banned']);
    }

    public function actionAttorneyEdit ($id)
    {
        $model = User::findByAttr(['id' => $id]);
        $model->scenario = 'update_approved_attorney';
        if ($model->load(Yii::$app->request->post()) && $model->validate()) {
            $model->dob = date('Y-m-d', strtotime($model->dob));
            $model->save(false);
            Yii::$app->session->setFlash('updateAttorney', "Attorney has been update");
            return $this->redirect(['attorney-edit', 'id' => $id]);
        }
        return $this->render('attorny', ['user' => $model]);
    }

    public function actionPendingAttorneyEdit ($id)
    {
        $model = User::findByAttr(['id' => $id]);
        $model->scenario = 'update_pending_attorney';
        if ($model->load(Yii::$app->request->post()) && $model->validate()) {

            $model->dob = date('Y-m-d', strtotime($model->dob));

            $model->save(false);
            Yii::$app->session->setFlash('updateAttorney', "Attorney has been update");
            return $this->redirect(['pending-attorney-edit', 'id' => $id]);
        }
        return $this->render('edit-pending-attorney', ['user' => $model]);
    }

    public function actionUnverifiedAttorneyEdit ($id)
    {
        $model = User::findByAttr(['id' => $id]);
        $model->scenario = 'create_attorney';
        if ($model->load(Yii::$app->request->post()) && $model->validate()) {
            $model->dob = date('Y-m-d', strtotime($model->dob));
            $model->save(false);
            Yii::$app->session->setFlash('updateAttorney', "Attorney has been update");
            return $this->redirect(['unverified-attorney-edit', 'id' => $id]);
        }
        return $this->render('edit-unverified', ['user' => $model]);
    }

    public function actionDelete ($id)
    {
        $attorny = User::deleteAll(['id' => $id]);
        if ($attorny) {
//            \Yii::$app->session->setFlash('delete', "Record has been deleted");
            return true;
        }
    }

    public function actionRatingReviews ()
    {
        $data = \Yii::$app->request->get();
        $detail = Review::getRattingAndReview($data);
        return $this->renderPartial('_rating_review_list', ['reviews' => $detail]);
    }

    public function actionCreateAttorney ()
    {
        $model = new User();
        $post = Yii::$app->request->post();
        $model->load($post, 'User');
        $model->scenario = 'create_attorney';
        if (!empty(Yii::$app->request->post()) && $model->validate()) {
            $model->password = Yii::$app->security->generatePasswordHash($post['User']['password']);
            $model->role = 'user';
            $model->status = 'active';
            $model->dob = date('Y-m-d', strtotime($model->dob));
            if ($model->save(false)) {
                $hearing_types = \common\models\HearingType::find()->where(['parent' => 0])->all();
                foreach ($hearing_types as $hearing_type) {
                    $hearing_detail = new \common\models\HearingDetail();
                    $hearing_detail->user_id = $model->id;
                    $hearing_detail->hearing_type = $hearing_type->id;
                    $hearing_detail->save(false);
                }
                $customer = \common\models\StripeGateway::createCustomer(['email' => $model->email]);
                if (!empty($customer) && $customer->id != '') {
                    User::updateAll(['stripe_customer_id' => $customer->id], ['id' => $model->id]);
                }
                try {
                    \Yii::$app->mailer->compose(['html' => 'welcomeMail-html'], ['user' => $model, 'password' => $post['User']['password']])
                            ->setFrom([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
                            ->setTo($model->email)
                            ->setReplyTo([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
                            ->setSubject('Welcome to ' . \Yii::$app->name)
                            ->send();
                } catch (\Exception $e) {
                    
                }
                Yii::$app->session->setFlash('createAttorny', "New attorney has been created");
                $this->redirect('index');
            }
        }
        return $this->render('attorny', ['user' => $model]);
    }

    public function actionDownloadAttorneyList ()
    {

        $post = Yii::$app->request->post();
        if ($post['type'] == 'Select') {
            $query = User::find()->where(['id' => explode(',', $post['attorney-id'])])->all();
        } else {
            $query = User::find()->all();
        }
        if (!empty($query)) {
            \moonland\phpexcel\Excel::export([
                'models' => $query,
                'columns' => ['id', 'first_name', 'last_name', 'bar_number', 'email', 'commition', 'status'], //without header working, because the header will be get label from attribute label. 
                'headers' => ['id' => 'Unique ID', 'first_name' => 'First Name', 'last_name' => 'Last Name', 'bar_number' => 'BAR No.', 'email' => 'Email Address', 'commition' => 'Commission', 'status' => 'Status'],
            ]);
        } else {
            \Yii::$app->session->setFlash('blanck_sheet', "There are no record to export");
            $this->redirect('index');
        }
    }

    public function actionPermintCasePalce ($id)
    {
        $model = User::findByAttr(['id' => $id]);
        if ($model->can_place == 'no') {
            $model->can_place = 'yes';
        } else {
            $model->can_place = 'no';
        }
        if ($model->save(false)) {
//           \common\components\Utility::flashMessage();
//             \Yii::$app->session->setFlash('success', "Status has been changed");
            return 'true';
        }
    }

    public function actionApprove ($id)
    {
        $model = User::findByAttr(['id' => $id]);
        if ($model->approved == 'no') {
            $model->approved = 'yes';
         
            \Yii::$app->mailer->compose(['html' => 'admin-approver-attorney-html'], ['user' => $model])
                    ->setFrom([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
                    ->setTo($model->email)
                    ->setSubject('Courtpals Account Activated')
                    ->send();
        } else {
//           Yii::$app->session->setFlash('not_approved', "");
            $model->approved = 'no';
        }
        if ($model->save(false)) {
//             \Yii::$app->session->setFlash('approved', "Attorney has been Approved");
            return true;
        }
    }

    public function actionPermitAllForCase ()
    {
        $post = yii::$app->request->post();
        foreach ($post['ids'] as $id) {
            $user = User::find()->where(['id' => $id])->one();
            if($post['type']=='permit'){
            $user->can_place = 'yes';
            }else{
            $user->can_place = 'no';   
            }
           $user->save(false);
        }
        if($post['type']=='permit'){
        return 'true';
        }else{
        return 'false';  
        }
    }

}

?>