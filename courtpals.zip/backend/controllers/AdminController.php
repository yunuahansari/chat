<?php

namespace backend\controllers;

use yii;
use yii\web\Controller;
use yii\filters\AccessControl;
use api\models\forms\ChangePasswordForm;
use common\models\User;
use yii\web\Response;
use yii\widgets\ActiveForm;
use frontend\models\PasswordResetRequestForm;

Class AdminController extends Controller
{
    
    public function behaviors() {

        return [
            'access' => [
                'class' => AccessControl::className(),
                'rules' => [
                    [
                        'allow' => Yii::$app->user->isAdmin(),
                    ],
                ],
            ],
        ];
    }

    public function actionIndex ()
    {

        Yii::$app->params['title'] = "Manage Student";
        return $this->render('index');
    }

    public function actionChangePassword ()
    {
       
        $model = new User();
        $model->scenario = 'changePassword';
        $model->load(yii::$app->request->post());
       
        if (!empty(\Yii::$app->request->post()) && $model->validate()) {
            $user = \common\models\User::changePassword($model);
            if ($user) {
                $model = new User();
                Yii::$app->session->setFlash('success', "Your password has been changed");
                 return $this->render('_change_password', ['changePassword' => $model]);
            }
        }

        return $this->render('_change_password', ['changePassword' => $model]);
    }

    public function actionEditeProfileModel ()
    {

        Yii::$app->params['title'] = "Manage Student";
        $model = \api\models\User::getUserById(yii::$app->user->id);
        return $this->renderAjax('_edite_profile', ['model' => $model]);
    }

    public function actionUpdateProfile ()
    {

        $model = new User();
        $model->scenario = 'edite_profile';
        $model->load(yii::$app->request->post());
        if (\Yii::$app->request->isAjax) {
           
            $this->layout = null;
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
        if ($model->validate()) {
            
            $user = \common\models\User::editeProfile($model, yii::$app->request->post());
            if ($user) {
                $model = new User();
                 Yii::$app->params['title'] = "Manage Student";
                Yii::$app->session->setFlash('success', "Your profile has been changed");
                return $this->render('_edite_profile', ['model' => $model]);
            }
        }
    }
    
    public function actionUpdateCommition(){
        $data = \Yii::$app->request->post();
        $user = User::find()->where(['id' => $data['userId']])->one();
        $user->commition = $data['commition'];
        if($user->save(false)){
            return true;
        }
        return false;
    }
    
  
}
?>

