<?php

namespace backend\controllers;

use yii;
use yii\web\Controller;
use yii\filters\AccessControl;
use yii\web\Response;
use yii\widgets\ActiveForm;
use common\models\HearingType;
use common\models\Departments;

Class OtherController extends Controller {

    public function behaviors() {

        return [
            'access' => [
                'class' => AccessControl::className(),
                'rules' => [
                    [
                        'allow' => Yii::$app->user->isAdmin(),
                    ],
                ],
            ],
        ];
    }
    
    public function actionIndex() {
        return $this->render('other');
    }

    public function actionHearingType() {
        $hearing_model = new HearingType();
        $post = \yii::$app->request->get();
        $hearings = HearingType::allHearingType($post);
        return $this->renderPartial('_hearing_type', ['hearingTypes' => $hearings, 'hearing_model' => $hearing_model]);
    }


    public function actionAddEditHearingType( $id = 0 ) {
        $add = true;
        if ($id) {
            $model = HearingType::find()->where(['id' => $id])->one();
            $add = false;
        } else {
            $model = new HearingType();
        }
        if ($model->load(\Yii::$app->request->post()) && $model->validate()) {
            $add_hearing = HearingType::addHearingType($model);
            if ($add_hearing) {
                if(!$add)
                        Yii::$app->session->setFlash('message', "Hearing type updated scuccessfully!");
                    else
                        Yii::$app->session->setFlash('message', "Hearing type added scuccessfully!");
                return $this->redirect(['index', 'id' => 'hearing_type']);
            }
        }
        return $this->renderAjax('_add_hearing_type', ['model' => $model]);
        
    }


    public function actionDeleteHearingType($id) {
        $hearing = HearingType::deleteAll(['id' => $id]);
        if ($hearing) {
            Yii::$app->session->setFlash('delete', "Your record has been deleted");
            return true;
        }
    }

    public function actionAddresses() {
        $post = \yii::$app->request->get();
        $addresses = \common\models\Address::allAddresses($post);
        return $this->renderPartial('_address', ['addresses' => $addresses]);
    }

    public function actionAddEditAddress($id = 0) {
        $add = true;
        if (!empty($id)) {
            $model = \common\models\Address::find()->where(['id' => $id])->one();
            $add = false;
        } else {
            $model = new \common\models\Address();
        }
        if ($model->load(yii::$app->request->post())) {
            $post = yii::$app->request->post();
            if($add){
                $lata_long = \api\components\Utility::getlatitudeLongitude($post['Address']['address']);
                if (!empty($lata_long)) {
                    $model->latitude = $lata_long['latitude'];
                    $model->longitude = $lata_long['longitude'];
                }
            }
            if ($model->validate()) {
                if ($model->save(false)) {
                    if(!$add)
                        Yii::$app->session->setFlash('message', "Address updated scuccessfully!");
                    else
                        Yii::$app->session->setFlash('message', "Address added scuccessfully!");
                    
                    return $this->redirect(['index', 'id' => 'address']);
                }
            }
        }
        return $this->renderAjax('_add_address', ['model' => $model]);
        
    }

    public function actionDeleteAddress($id) {
        $address = \common\models\Address::deleteAll(['id' => $id]);
        if ($address) {
            Yii::$app->session->setFlash('delete', "Your record has been deleted");
            return true;
        }
    }

    public function actionDepartment() {
        $departments_model = new Departments();
        $post = \yii::$app->request->get();
        $departments = Departments::allDepartment($post);
        return $this->renderPartial('_department', ['departments' => $departments, 'departments_model' => $departments_model]);
    }

    public function actionAddEditDepartment( $id = 0 ) {
        $add = true;
        if (!empty($id)) {
            $model = Departments::find()->where(['id' => $id])->one();
            $add = false;
        } else {
            $model = new Departments();
        }
        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
        if ($model->load(yii::$app->request->post())) {
            $add_departments = Departments::actionNewDepartment($model);
            if ($add_departments) {
                if(!$add)
                        Yii::$app->session->setFlash('message', "Department updated scuccessfully!");
                    else
                        Yii::$app->session->setFlash('message', "Department added scuccessfully!");
                return $this->redirect(['index', 'id' => 'deparments']);
            }
        }
        return $this->renderAjax('_add_department', ['model' => $model]);
        
    }

    public function actionDeleteDepartment($id) {
        $departments = Departments::deleteAll(['id' => $id]);
        if ($departments) {
            Yii::$app->session->setFlash('delete', "Your record has been deleted");
            return true;
        }
    }

}

?>