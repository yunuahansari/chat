<?php

namespace backend\controllers;

use yii;
use yii\web\Controller;
use yii\filters\AccessControl;
use yii\web\Response;
use yii\widgets\ActiveForm;
use common\models\Transactions;
use common\models\User;
use common\models\Message;


Class CommunicationsController extends Controller
{

    public function behaviors() {

        return [
            'access' => [
                'class' => AccessControl::className(),
                'rules' => [
                    [
                        'allow' => Yii::$app->user->isAdmin(),
                    ],
                ],
            ],
        ];
    }
    
    public function actionIndex ()
    {
        return $this->render('index');
    }
    public function actionInboxList(){
         $post = \yii::$app->request->get();
         $inbox =  Message::getAllChat($post);
         return $this->renderPartial('_chat_list',['inbox'=>$inbox]);
    }
    public function actionIndexInbox(){
         $post = \yii::$app->request->get();
         $inbox =  Message::getAllChat($post);
         return $this->renderPartial('inbox',['inbox'=>$inbox]);
    }

    public function actionChatOfAttorney(){
       $post = \yii::$app->request->get();
       $chat = Message::getAllChatOfCase($post);
       return $this->renderPartial('chat',['chats'=>$chat]);
    }
}

?>