<?php
namespace backend\models;
use Yii;
use yii\data\ActiveDataProvider;
use yii\helpers\ArrayHelper;
use api\components\Utility;
use common\models\StripeGateway;
use common\models\CaseCancelledRequest;
use common\models\Transactions;
use common\models\User;
use common\models\Notification;

class Refund extends \yii\base\Model
{
    public $client_first_name;
    public $client_last_name;
    public $client_id;
    public $client_stripe_account_id;
    public $client_stripe_customer_id;
    public $peer_id;
    public $peer_first_name;
    public $peer_last_name;
    public $peer_stripe_account_id;
    public $peer_stripe_customer_id;
    public $transaction_id;
    public $peer_amount;
    public $client_amount;
    public $total_amount;
    public $request_id;
    public $ccr_id;
   
    public static function getRefundData($requestId)
    {
        $sql = "SELECT  ccr.id as ccr_id, ccr.client_amount, ccr.peer_amount, t.amount as total_amount, t.transaction_id, case_request.id as request_id,
                        client.id as client_id, CONCAT(client.first_name,' ',client.last_name) as client_name, client.stripe_account_id as client_stripe_account_id, client.stripe_customer_id as client_stripe_customer_id,
                        peer.id as peer_id, CONCAT(peer.first_name,' ',peer.last_name) as peer_name, peer.stripe_account_id as peer_stripe_account_id, peer.stripe_customer_id as peer_stripe_customer_id
                        FROM case_request
                        LEFT JOIN transactions t ON t.request_id = case_request.id
                        LEFT JOIN case_cancelled_request ccr ON ccr.request_id = case_request.id
                        LEFT JOIN user client ON client.id = case_request.from_id
                        LEFT JOIN user peer ON peer.id = case_request.to_id
                        WHERE case_request.id = {$requestId} AND case_request.status = 'cancelled'";
        return \yii::$app->db->createCommand($sql)->queryOne();
    }
    
    public static function processRefund($data){
        $return = false;
        if(!empty($data)){
            if($data['client_amount'] > 0 && $data['peer_amount'] > 0){
                $refundResponse = StripeGateway::refund(array('charge_id' => $data['transaction_id'],'amount'=>$data['client_amount']));
                if(!empty($refundResponse)){
                    self::clientRefund($refundResponse, array('request_id' => $data['request_id'],'client_id' => $data['client_id']));
                }
                $param = array('amount' => $data['peer_amount'], 'account_id' => $data['peer_stripe_account_id']);
                $transferResponse = StripeGateway::transferToPeerAttorney($param);
                if(!empty($transferResponse)){
                    self::attorneyRefund($transferResponse, array('request_id' => $data['request_id'],'peer_id' => $data['peer_id']));
                }
                $return = true;
            }
            else if($data['client_amount'] > 0){
                $refundResponse = StripeGateway::refund(array('charge_id' => $data['transaction_id'],'amount'=>$data['client_amount']));
                if(!empty($refundResponse)){
                    self::clientRefund($refundResponse, array('request_id' => $data['request_id'],'client_id' => $data['client_id']));
                }
                $return = true;
            }else if($data['peer_amount'] > 0){
                $param = array('amount' => $data['peer_amount'], 'account_id' => $data['peer_stripe_account_id']);
                $transferResponse = StripeGateway::transferToPeerAttorney($param);
                if(!empty($transferResponse)){
                    self::attorneyRefund($transferResponse, array('request_id' => $data['request_id'],'peer_id' => $data['peer_id']));
                }
                $return = true;
            }else if($data['client_amount'] > 0 && $data['peer_amount'] = 0){
                $refundResponse = StripeGateway::refund(array('charge_id' => $data['transaction_id'],'amount'=>$data['client_amount']));
                if(!empty($refundResponse)){
                    self::clientRefund($refundResponse, array('request_id' => $data['request_id'],'client_id' => $data['client_id']));
                }
                $return = true;
            }
            if($return){
                $cancelModel = CaseCancelledRequest::find()->where(['id' => $data['ccr_id']])->one();
                if(!empty($cancelModel)){
                    
                    $cancelModel->status = 'Complete';
                    $cancelModel->save(false);
                }
                return $response = array('success' => true);
            }
        }
        return false;
    }
    
    public static function attorneyRefund($charge,$opt){
        $transactionModel = new Transactions();
            $loggedInUser = \Yii::$app->user->getId();
            if(!$loggedInUser){
                $admin = User::find()->where(['role' => 'admin','status' => 'active'])->one();
                $loggedInUser = $admin->id;
            }
            if (isset($charge->id)) {
                $request = \common\models\CaseRequest::find()->where(['id' => $opt['request_id']])->one();
                 
                $transactionModel->amount = $charge->amount / 100;
                $transactionModel->request_id = $opt['request_id'];
                $transactionModel->from_user_id = $loggedInUser;
                $transactionModel->to_user_id = $opt['peer_id'];
                $transactionModel->status = ($charge->status == "succeeded") ? 'success' : "failed";
                $transactionModel->transaction_id = $charge->id;
                $transactionModel->commition = $request->from->commition;
                
                if ($transactionModel->save(false)) {
                        $user_data = User::userDataForNotification($loggedInUser);
                       
                        $title = 'Payment Recieved';

                        $type = 'refund_processed';
                        $message = 'Your refund of $ '.$transactionModel->amount.' has been initiated for case ID ' . $request->case_id . ' and it will reflect in your bank account within 2-4 working days ';
                        $toUser = \common\models\User::find()->where(['id' => $request->to_id])->one();
                        $notification_data = ['title' => $title, 'type' => $type, 'from_id' => $loggedInUser, 'to_id' => $request->from_id, 'user_name' => $user_data['user_name'],
                            'profile_image' => $user_data['profile_image'], 'request_id' => $request->id,'notification_receive_status' => $toUser->notification];
                        Notification::saveNotification(['to_id' => [$request->to_id], 'from_id' => \yii::$app->user->id, 'type' => $type, 'message' => $message,
                                        'request_id' => $request->id, 'notification_data' => json_encode($notification_data)]);
                        if ($toUser['notification'] == 'enable') {
                            $notification_data['unread_notification_count'] = Notification::newNotification($request->to_id);
                            \api\components\Utility::sendMultiPushNotification($request->to_id, $message, $notification_data);
                        }
                        if ($toUser['notification'] == 'disable') {
                            $notification_data['unread_notification_count'] = Notification::newNotification($request->to_id);
                            \api\components\Utility::sendWithoutAlertMessagePushNotification($request->to_id, $message, $notification_data);
                        }
                return true;
                    
                }
                
            }
    }
    
    public static function clientRefund($charge,$opt){
        $transactionModel = new Transactions();  
            $loggedInUser = \Yii::$app->user->getId();
            if(!$loggedInUser){
                $admin = User::find()->where(['role' => 'admin','status' => 'active'])->one();
                $loggedInUser = $admin->id;
            }
            if (isset($charge->id)) {
                $request = \common\models\CaseRequest::find()->where(['id' => $opt['request_id']])->one();
                $transactionModel->amount = $charge->amount / 100;
                $transactionModel->request_id = $opt['request_id'];
                $transactionModel->from_user_id = $loggedInUser;
                $transactionModel->to_user_id = $opt['client_id'];
                $transactionModel->status = ($charge->status == "succeeded") ? 'success' : "failed";
                $transactionModel->transaction_id = $charge->id;
                $transactionModel->commition = $request->from->commition;
                
                if ($transactionModel->save(false)) {
                        $user_data = User::userDataForNotification($loggedInUser);
                        
                        $title = 'Payment Recieved';

                        $type = 'refund_processed';
                        $message = 'Your refund of $ '.$transactionModel->amount.' has been initiated for case ID ' . $request->case_id . ' and it will reflect in your bank account within 2-4 working days ';
                        $toUser = \common\models\User::find()->where(['id' => $request->from_id])->one();
                        $notification_data = ['title' => $title, 'type' => $type, 'from_id' => $loggedInUser, 'to_id' => $request->from_id, 'user_name' => $user_data['user_name'],
                            'profile_image' => $user_data['profile_image'], 'request_id' => $request->id,'notification_receive_status' => $toUser->notification];
                         Notification::saveNotification(['to_id' => [$request->from_id], 'from_id' => \yii::$app->user->id, 'type' => $type, 'message' => $message,
                                        'request_id' => $request->id, 'notification_data' => json_encode($notification_data)]);
                        if ($toUser['notification'] == 'enable') {
                            $notification_data['unread_notification_count'] = Notification::newNotification($request->from_id);
                            \api\components\Utility::sendMultiPushNotification($request->from_id, $message, $notification_data);
                        }
                        if ($toUser['notification'] == 'disable') {
                            $notification_data['unread_notification_count'] = Notification::newNotification($request->from_id);
                            \api\components\Utility::sendWithoutAlertMessagePushNotification($request->from_id, $message, $notification_data);
                        }
                        return true;
                }
                return true;
            }
    }
    
}

