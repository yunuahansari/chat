<?php

namespace backend\models;

use yii\base\Model;
use common\components\Utility;

/**
 * Password reset form
 */
class ForgotPasswordForm extends Model
{

    public $email;
    
    /**
     * @inheritdoc
     */
    public function rules ()
    {
        return [
            ['email', 'required'],
            ['email', 'exist',
                'targetClass' => '\common\models\User',
                'message' => 'There is no user with such email.','on'=>'forgot'
            ],
        ];
    }

    public function sendEmail ()
    {
        
        $user = \common\models\User::findByAttr(['email'=>$this->email,'role'=>'admin']);
      
        $return = 0;
            if(!empty($user)){
                $user->verified_code = Utility::generateVerificationCode();
                $user->save(false);
                try{
               
                $retrun = \Yii::$app->mailer->compose(['html' => 'forgotPasswordLink-html'], ['user' => $user])
                    ->setFrom([\Yii::$app->params['supportEmail'] => \Yii::$app->name])
                    ->setTo($this->email)
                    ->setSubject('Password reset for ' . \Yii::$app->name)
                    ->send();
                }catch (\Exception $e){
               
                }
         
                if($retrun)
                    return true;
             
            }
            return false;
    }

}
