<?php 
//echo "<pre>";
//print_r($user);die;
?>

<div id="content">                   
            <main class="main-content common-grid-page view-page">
                <div class="container-fluid">
                    <div class="page-title" id="pageTitle">
                        <h4>View Sender</h4>
                    </div>
                    <div class="panel panel-primary filter-panel" id="panel-height">
                        <div class="panel-heading clearfix filter-heading">
                            <h4 class="panel-title"><i class="ti-eye" aria-hidden="true"></i> View Sender</h4>
                            <a href="<?php echo yii::$app->urlManager->createAbsoluteUrl('/payment')?>" class="back-btn"><i class="ti-hand-point-left" aria-hidden="true"></i> Back</a>
                            <div class="clearfix"></div>
                        </div>
                        <div class="panel-body">

                            <div class="form-horizontal">
                                <div class="form-group">
                                    <label class="control-label col-sm-2 col-md-2 col-lg-2">Case ID   <span>:</span></label>
                                    <div class="col-sm-10 col-md-10 col-lg-10">
                                        <p class="form-control-static"><?php echo $user['case_id'];?></p>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-sm-2 col-md-2 col-lg-2">BAR Number   <span>:</span></label>
                                    <div class="col-sm-10 col-md-10 col-lg-10">
                                        <p class="form-control-static"><?php echo $user['bar_number'];?></p>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-sm-2 col-md-2 col-lg-2">SSN Number  <span>:</span></label>
                                    <div class="col-sm-10 col-md-10 col-lg-10">
                                        <p class="form-control-static"><?php echo $user['ssn_number'];?></p>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-sm-2 col-md-2 col-lg-2">Full Name  <span>:</span></label>
                                    <div class="col-sm-10 col-md-10 col-lg-10">
                                        <p class="form-control-static"><?php echo $user['first_name'].' '.$user['last_name'];?></p>
                                    </div>
                                </div>                    
                                <div class="form-group">
                                    <label class="control-label col-sm-2 col-md-2 col-lg-2">Email Address <span>:</span></label>
                                    <div class="col-sm-10 col-md-10 col-lg-10">
                                        <p class="form-control-static">
                                            <?php echo $user['email'];?>
                                        </p>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-sm-2 col-md-2 col-lg-2">DOB <span>:</span></label>
                                    <div class="col-sm-10 col-md-10 col-lg-10">
                                        <p class="form-control-static">
                                            <?php echo date("F  d ,Y",  strtotime($user['dob'])); ?>
                                        </p>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-sm-2 col-md-2 col-lg-2">Phone Number <span>:</span></label>
                                    <div class="col-sm-10 col-md-10 col-lg-10">
                                        <p class="form-control-static">
                                           <?php echo $user['mobile'];?>
                                        </p>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="control-label col-sm-2 col-md-2 col-lg-2">Amount Send <span>:</span></label>
                                    <div class="col-sm-10 col-md-10 col-lg-10">
                                        <p class="form-control-static">
                                           <?php echo $user['amount'];?>
                                        </p>
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <label class="control-label col-sm-2 col-md-2 col-lg-2">Admin's Commission(%) <span>:</span></label>
                                    <div class="col-sm-10 col-md-10 col-lg-10">
                                        <p class="form-control-static">
                                          <?php echo ($user['commition']);?>
                                        </p>
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <label class="control-label col-sm-2 col-md-2 col-lg-2">Admin's Earning($) <span>:</span></label>
                                    <div class="col-sm-10 col-md-10 col-lg-10">
                                        <p class="form-control-static">
                                          <?php echo ($user['admin_earning']);?>
                                        </p>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="control-label col-sm-2 col-md-2 col-lg-2">Date of Sent  <span>:</span></label>
                                    <div class="col-sm-10 col-md-10 col-lg-10">
                                        <p class="form-control-static">
                                            <?php 
                                             $date_time = str_replace('/', '-', $user['created_at']);
                                             echo date("F  d ,Y", strtotime($date_time));?>
                                        </p>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="control-label col-sm-2 col-md-2 col-lg-2">Time of Sent  <span>:</span></label>
                                    <div class="col-sm-10 col-md-10 col-lg-10">
                                        <p class="form-control-static">
                                            <?php 
                                           $date_time = str_replace('/', '-', $user['created_at']);
                                           echo date('h:i A', strtotime($date_time));?>
                                        </p>
                                    </div>
                                </div>


                                
                                
                            </div>
                        </div>                        
                    </div>
                </div>
            </main>
        </div>