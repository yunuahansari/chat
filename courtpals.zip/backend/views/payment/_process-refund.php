<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
?>

<?php $form = ActiveForm::begin(['id' => 'refund-form',
                                 'action' => Yii::$app->urlManager->createAbsoluteUrl('payment/process-refund')
                                ]); 
?>
<?= $form->field($model, 'request_id')->hiddenInput(['value' => $data['request_id']])->label(false); ?>
<?= $form->field($model, 'client_id')->hiddenInput(['value' => $data['client_id']])->label(false); ?>
<?= $form->field($model, 'peer_id')->hiddenInput(['value' => $data['peer_id']])->label(false); ?>
<?= $form->field($model, 'transaction_id')->hiddenInput(['value' => $data['transaction_id']])->label(false); ?>
<?= $form->field($model, 'peer_stripe_account_id')->hiddenInput(['value' => $data['peer_stripe_account_id']])->label(false); ?>
<?= $form->field($model, 'ccr_id')->hiddenInput(['value' => $data['ccr_id']])->label(false); ?>
<div class="alert alert-danger alert-dismissable" style="display: none">
       <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
       <strong></strong> <span class="msg"></span>
    </div>
    <div class="form-group">
        <label for="">Total Amount</label>
        <?= $form->field($model, 'total_amount')->textInput(['value' => $data['total_amount'],'class' => 'form-control input-lg', 'readonly' => true])->label(false); ?>
    </div>
    <div class="form-group">
        <label for="">Amount Paid To Client(<?php echo $data['client_name'] ?>)</label>
        <?= $form->field($model, 'client_amount')->textInput(['value' => $data['client_amount'],'class' => 'form-control input-lg', 'readonly' => true])->label(false); ?>
    </div>
    <div class="form-group">
        <label for="">Amount Paid To Pal Attorney(<?php echo $data['peer_name'] ?>)</label>
        <?= $form->field($model, 'peer_amount')->textInput(['value' => $data['peer_amount'],'class' => 'form-control input-lg', 'readonly' => true])->label(false); ?>
    </div>
    <div class="form-group text-right">
        <button type="button" id="submitBtn" class="btn btn-primary noradius waves-effect waves-button waves-light text-uppercase">Confirm Refund </button>
    </div>
<?php ActiveForm::end(); ?> 
<script>
  
      $().ready(function () {

        $("#submitBtn").on('click', function(e) {
            $(this).attr('disabled','disabled');
            var form = $('#refund-form');
            var formData = form.serialize();
            $.ajax({
                url: form.attr("action"),
                type: form.attr("method"),
                data: formData,
                success: function (data) {
                    var responseData = JSON.parse(data);
                    if(responseData.success){
                        $(".alert-danger").hide();
                        window.location.href = "<?php echo Yii::$app->urlManager->createAbsoluteUrl('payment'); ?>";
                    }
                },
                error: function (response) {
                    if(response.status !== 200){
                        $("#submitBtn").removeAttr('disabled');
                        $(".alert-danger").show();
                        $(".alert-danger strong").html(response.status);
                        $(".alert-danger span").text(response.statusText);
                    }
                }
            });
        });
       
    });
  
</script>