<?php $this->title = "Payment"; ?> 
<div id="content" class="detail">
    <main class="main-content common-grid-page managecategory-page">
        <div class="container-fluid">
            <div class="page-title" id="pageTitle">
                <h4>Payment</h4>
            </div>
            <?php if (Yii::$app->session->hasFlash('success')): ?> 
                <div class="alert alert-success alert-dismissable">
                    <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                    <h4><i class="icon fa fa-check"></i>Saved!</h4>
                    <?= Yii::$app->session->getFlash('success') ?>
                </div>
            <?php endif; ?>
            <div class="panel panel-primary filter-panel" id="panel-height">
                <div class="panel-heading clearfix filter-heading">
                    <h4 class="panel-title"><i class="ti-layout-tab-window"></i> Payment List</h4>
                </div>
                <div class="panel-body">
                    <!-- Nav tabs -->
                    <ul class="nav nav-tabs" role="tablist">
                        <li role="presentation" class="active"><a href="#received" onClick="receivedPaymentList()" aria-controls="received" role="tab" data-toggle="tab">Received</a></li>
                        <li role="presentation"><a href="#sent" onClick="sentPaymentList()" aria-controls="sent" role="tab" data-toggle="tab">Sent</a></li>
                        <li role="presentation"><a href="#cancel" onClick="cancelRequestList()" aria-controls="cancel" role="tab" data-toggle="tab">Cancel Request</a></li>
                    </ul>
                    <!-- Tab panes -->
                    <div class="tab-content">
                        <div role="tabpanel" class="tab-pane active" id="received">
                            <div class="filter-icon">
                                <a waves class="waves-effect waves-circle waves-ripple waves-light" data-toggle="collapse" data-target="#filter" href="javascript:void(0)">
                                    <i class="ti-filter"></i>
                                </a>
                            </div>
                            <div class="clearfix"></div>
                            <div class="filter">
                                <div class="collapse" id="filter">
                                    <form id="form">
                                        <div class="row">
                                            <div class="col-sm-3 col-lg-2 col">
                                                <div class="form-group">
                                                    <label>Case ID</label>
                                                    <input type="text" class="form-control noradius "name="case_id" />
                                                </div>
                                            </div>
                                            <div class="col-sm-3 col-lg-2 col">
                                                <div class="form-group">
                                                    <label>Sender</label>
                                                    <input type="text" class="form-control noradius" name="receiver" />
                                                </div>
                                            </div>
                                            <div class="col-sm-3 col-lg-3 col ">
                                                <div class="form-group mb-0">
                                                    <label class="hidden-xs btn-block">&nbsp;</label>
                                                    <button type="button" waves onclick="receivedPaymentList()" class="btn btn-primary text-uppercase waves-effect waves-light noradius"><i class="ti-filter"></i> Filter</button>
                                                    <button type="button" waves onclick="reset('form');" class="btn btn-primary text-uppercase waves-effect waves-light noradius"><i class="ti-reload"></i> Reset</button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <div class="table-responsive admintable">
                            </div>
                        </div>
                        <!-- xxxxxx -->
                        <div role="tabpanel" class="tab-pane" id="sent">
                            <div class="filter-icon">
                                <a waves class="waves-effect waves-circle waves-ripple waves-light" data-toggle="collapse" data-target="#filter02" href="javascript:void(0)">
                                    <i class="ti-filter"></i>
                                </a>
                            </div>
                            <div class="clearfix"></div>
                            <div class="filter">
                                <div class="collapse" id="filter02">
                                    <form id="sent_filter_form">
                                        <div class="row">
                                            <div class="col-sm-3 col-lg-2 col">
                                                <div class="form-group">
                                                    <label>Case ID</label>
                                                    <input type="text" class="form-control noradius" name="case_id"/>
                                                </div>
                                            </div>
                                            <div class="col-sm-3 col-lg-2 col">
                                                <div class="form-group">
                                                    <label>Receiver</label>
                                                    <input type="text" class="form-control noradius" name="sender" />
                                                </div>
                                            </div>
                                            <div class="col-sm-3 col-lg-3 col">
                                                <div class="form-group mb-0">
                                                    <label class="hidden-xs btn-block">&nbsp;</label>
                                                    <button type="button" waves onclick="sentPaymentList()" class="btn btn-primary text-uppercase waves-effect waves-light noradius"><i class="ti-filter"></i> Filter</button>
                                                    <button type="button" waves onclick="reset('sent_filter_form');" class="btn btn-primary text-uppercase waves-effect waves-light noradius"><i class="ti-reload"></i> Reset</button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <div class="table-responsive admintable"></div>

                        </div>

                        <!-- Cancel request list -->
                        <div role="tabpanel" class="tab-pane" id="cancel">
                            <div class="filter-icon">
                                <a waves class="waves-effect waves-circle waves-ripple waves-light" data-toggle="collapse" data-target="#filter03" href="javascript:void(0)">
                                    <i class="ti-filter"></i>
                                </a>
                            </div>
                            <div class="clearfix"></div>
                            <div class="filter">
                                <div class="collapse" id="filter03">
                                    <form id="cancel_filter_form">
                                        <div class="row">
                                            <div class="col-sm-3 col-lg-2 col">
                                                <div class="form-group">
                                                    <label>Case ID</label>
                                                    <input type="text" class="form-control noradius" name="case_id"/>
                                                </div>
                                            </div>
                                            <div class="col-sm-3 col-lg-2 col">
                                                <div class="form-group">
                                                    <label>Client</label>
                                                    <input type="text" class="form-control noradius" name="client" />
                                                </div>
                                            </div>
                                            <div class="col-sm-3 col-lg-2 col">
                                                <div class="form-group">
                                                    <label>Peer</label>
                                                    <input type="text" class="form-control noradius" name="peer" />
                                                </div>
                                            </div>
                                            <div class="col-sm-3 col-lg-2 col">
                                                <div class="form-group">
                                                    <label>Status</label>
                                                    <select class="selectpicker"  name="status">
                                                        <option value="">All</option>
                                                        <option value="Active">Active</option>
                                                        <option value="Complete">Complete</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-sm-3 col-lg-3 col">
                                                <div class="form-group mb-0">
                                                    <label class="hidden-xs  btn-block">&nbsp;</label>
                                                    <button type="button" waves onclick="cancelRequestList()" class="btn btn-primary text-uppercase waves-effect waves-light noradius"><i class="ti-filter"></i> Filter</button>
                                                    <button type="button" waves onclick="reset('cancel_filter_form');" class="btn btn-primary text-uppercase waves-effect waves-light noradius"><i class="ti-reload"></i> Reset</button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <div class="table-responsive admintable"></div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </main>
</div>

<script type="text/javascript">
    
    var timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    function receivedPaymentList()
    {
        $('#received .admintable').html('<div class="loader text-center"><i class="fa fa-spin fa-spinner fa-3x color-blue"></i></div>');
        var url = url || "<?php echo \yii::$app->urlManager->createUrl(['payment/received-payment-list']) ?>";
        $.ajax({
            type: "GET",
            url: url,
            data: $('#form').serialize() + "&timezone=" + timezone,
            success: function (data) {
                $("#sent").hide();
                $("#cancel").hide();
                $("#received").show();
                $("#received .admintable").html(data);
            }
        });
    }
    $().ready(function () {
        receivedPaymentList();
    }

    );

    function sentPaymentList()
    {
        $('#sent .admintable').html('<div class="loader text-center"><i class="fa fa-spin fa-spinner fa-3x color-blue"></i></div>');
        var url = url || "<?php echo \yii::$app->urlManager->createUrl(['payment/sent-payment-list']) ?>";
        $.ajax({
            type: "GET",
            url: url,
            data: $('#sent_filter_form').serialize()+ "&timezone=" + timezone,
            success: function (data) {
                $("#received_list").hide();
                $("#cancel").hide();
                $("#sent").show();
                $("#sent .admintable").html(data);
            }
        });
    }

    function cancelRequestList()
    {
        $('#cancel .admintable').html('<div class="loader text-center"><i class="fa fa-spin fa-spinner fa-3x color-blue"></i></div>');
        var url = url || "<?php echo \yii::$app->urlManager->createUrl(['payment/cancel-request-list']) ?>";
        $.ajax({
            type: "GET",
            url: url,
            data: $('#cancel_filter_form').serialize()+ "&timezone=" + timezone,
            success: function (data) {
                $("#received_list").hide();
                $("#sent").hide();
                $("#cancel").show();
                $("#cancel .admintable").html(data);
            }
        });
    }
    
    function detailShow(id){
     
         var url = url || "<?php echo \yii::$app->urlManager->createUrl(['payment/sender-veiw']) ?>?id="+id;
        $.ajax({
            type: "GET",
            url: url,
            data:{timezone:timezone},
            success: function (data) {
                $(".detail").html(data);
            }
        });
    }
    function detailShowOfReceiver(id){
     
         var url = url || "<?php echo \yii::$app->urlManager->createUrl(['payment/receiver-veiw']) ?>?id="+id;
        $.ajax({
            type: "GET",
            url: url,
            data:{timezone:timezone},
            success: function (data) {
                $(".detail").html(data);
            }
        });
    }
    function reset(formId){
        $("#"+formId).find("input[type=text], textarea").val("");
    }
</script>

