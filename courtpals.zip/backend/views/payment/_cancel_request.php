
    <table class="table">
        <thead>
            <tr>
                <th>Case ID</th>
                <th>Client</th>
                <th>Pal Attorney</th>
                <th>Cancelled By</th>
                <th>Total Amount</th>
                <th>Refund to client</th>
                <th>Refund to pal</th>
                <th>Admin's Earning</th>
                <th>Cancellation Charges</th>
                <th>Cancelled status</th>
                <th>Date/Time</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($model->getModels()) == 0) { ?>
            <tr><td colspan="11"><div class="alert alert-danger">No Record Found</div></td></tr>
                <?php
            }
            foreach ($model->getModels() as $request) {
                ?>
                <tr>
                    <?php $cancellationCharges =  $request->transactions->amount - ($request->caseCancelledRequests[0]->client_amount + $request->caseCancelledRequests[0]->peer_amount)?>
                    <td><?php echo $request->case_id; ?></td>
                    <td><?php echo $request->from->first_name.' '.$request->from->last_name; ?></td>
                    <td><?php echo $request->to->first_name.' '.$request->to->last_name; ?></td>
                    <td><?php echo $request->cancelledBy->first_name.' '.$request->cancelledBy->last_name; ?></td>
                    <td><?php echo number_format((float) $request->transactions->amount, 2, '.', ''); ?></td>
                    <td><?php echo number_format((float) $request->caseCancelledRequests[0]->client_amount, 2, '.', ''); ?></td>
                    <td><?php echo number_format((float) $request->caseCancelledRequests[0]->peer_amount, 2, '.', ''); ?></td>
                    <?php 
                    $admin_earning = ($request->transactions->amount!=$request->caseCancelledRequests[0]->client_amount)?($request->transactions->amount*$request->transactions->commition)/100:0;
                    ?>
                    <td><?php echo number_format((float) $admin_earning, 2, '.', ''); ?></td>
                    <td><?php echo number_format((float) $cancellationCharges, 2, '.', ''); ?></td>
                    <td><?php echo ucfirst($request->caseCancelledRequests[0]->status); ?></td>
                    <td><?php echo date("Y-m-d h:i A", strtotime($request['created_at'])); ?></td>
                    <td>
                        <ul class="list-inline mb-0">
                            <?php if($request->caseCancelledRequests[0]->status == 'Active' && ($request->caseCancelledRequests[0]->client_amount != 0 || $request->caseCancelledRequests[0]->peer_amount != 0)){ ?>
                                <li><a data-toggle="modal" data-backdrop="static" data-target="#refund-modal" onclick="processRefund(<?php echo $request->id; ?>);" class="waves-circle waves-effect waves-ripple"><i class="ti-money"></i></a></li>
                            <?php } ?>
                        </ul>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
<nav class="paginationdiv text-center">

    <?php
    echo \yii\widgets\LinkPager::widget([
        'pagination' => $model->pagination,
    ]);
    ?>

</nav>
<!-- Modal payment -->
<div class="modal fade" id="refund-modal">
    <div class="modal-dialog other-modal">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="myModalLabel">Process Refund</h4>
            </div>
            <div class="modal-body"></div>
        </div>
    </div>
</div>
<!--End modal payment-->
<script>
    $().ready(function () {
        $(".pagination li a").on('click', function (e) {
            e.preventDefault();
            var $this = $(this);
            // $('#loaderImage').show();
            var pageLink = $this.attr('href');

            $.ajax({
                type: 'GET',
                url: pageLink,
                success: function (response) {
                    $("html, body").animate({scrollTop: 300}, "slow");
                    $('#cancel .admintable').html(response);
                }
            });
        });
    });
    
    function processRefund(requestId){
    var url = url || "<?php echo \yii::$app->urlManager->createUrl(['payment/process-refund']) ?>";
    $.ajax({
            type: "GET",
            url: url,
            data:{requestId:requestId},
            success: function (data) {
                $("#refund-modal .modal-body").html(data);
            }
    });
}  
</script>