<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
?>

<?php $form = ActiveForm::begin(['id' => 'payment-form',
                                 'action' => Yii::$app->urlManager->createAbsoluteUrl('payment/make-attorney-payment')
                                ]); 
?>
    <?= $form->field($model, 'request_id')->hiddenInput(['value' => $data['request_id']])->label(false); ?>
    <div class="alert alert-danger alert-dismissable" style="display: none">
       <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
       <strong></strong> <span class="msg"></span>
    </div>
    <div class="form-group">
        <label for="">Amount Paid By Client</label>
        <?= $form->field($model, 'amount')->textInput(['value' => $data['amount'],'class' => 'form-control input-lg', 'readonly' => true])->label(false); ?>
    </div>
    <div class="form-group">
        <label for="">Commission in (%) </label>
        <?= $form->field($model, 'commition')->textInput(['value' => $data['commition'],'class' => 'form-control input-lg', 'readonly' => true])->label(false); ?>
    </div>
    <div class="form-group">
        <label for="">Amount Paid To Attorney</label>
        <?= $form->field($model, 'paid_to_attorney')->textInput(['value' => \common\models\Transactions::calculateCommitionedAmount($data['commition'], $data['amount']),'class' => 'form-control input-lg', 'readonly' => true])->label(false); ?>
    </div>
    <div class="form-group text-right">
        <button type="button" id="submitBtn" class="btn btn-primary noradius waves-effect waves-button waves-light text-uppercase">Confirm Payment</button>
    </div>
<?php ActiveForm::end(); ?> 
<script>
  
      $().ready(function () {

        $("#submitBtn").on('click', function(e) {
            $(this).attr('disabled','disabled');
            var form = $('#payment-form');
            var formData = form.serialize();
            $.ajax({
                url: form.attr("action"),
                type: form.attr("method"),
                data: formData,
                success: function (data) {
                    var responseData = JSON.parse(data);
                    if(responseData.success){
                        window.location.href = "<?php echo Yii::$app->urlManager->createAbsoluteUrl('payment'); ?>";
                    }
                },
                error: function (response) {
                    if(response.status !== 200){
                        $("#submitBtn").removeAttr('disabled');
                        $(".alert-danger").show();
                        $(".alert-danger strong").html(response.status);
                        $(".alert-danger span").text(response.statusText);
                    }
                }
            });
        });
       
    });
  
</script>