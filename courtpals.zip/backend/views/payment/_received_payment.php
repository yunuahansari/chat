<table class="table">
    <thead>
        <tr>
            <th>Case ID</th>
            <th>Payment Date/Time</th>
            <th>Hearing Date</th>
            <th>Sender</th>
            <th>Sender's Email</th>
            <th>Total Amount</th>
            <th>Admin's Earning($)</th>
            <th>Admin's Commission(%)</th>
            <th>Case Status</th>
            <th class="text-center">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php if (count($model->getModels()) == 0) { ?>
            <tr><td colspan="9"><div class="alert alert-danger">No Record Found</div></td></tr>
            <?php
        }
        foreach ($model->getModels() as $payment) {
            ?>
            <tr>
                <td><?php echo $payment['case_id']; ?></td>
                <td><?php echo date("F  d ,Y h:i A", strtotime($payment['created_at'])); ?></td>
                <td><?php echo date('F  d ,Y',  strtotime($payment['case_date'])) ?></td>
                <td><?php echo ucwords($payment['first_name'] . ' ' . $payment['last_name']); ?></td>
                <td><?php echo $payment['email']; ?></td>
                <td><?php echo $payment['amount']; ?></td>
                <td><?php echo number_format((float) $payment['admin_earning'], 2, '.', ''); ?></td>
                <td><?php echo $payment['commition']; ?></td>
                <td><?php echo ucfirst($payment['case_status']); ?></td>
                <td class="text-center">
                    <ul class="list-inline mb-0">
                        <li><a href="#" onclick="detailShowOfReceiver('<?php echo $payment['request_id']; ?>')"class="waves-circle waves-effect waves-ripple"><i class="ti-eye"></i></a></li>
                        <?php if ($payment['case_status'] == 'completed' && $payment['paid_to_attorney'] == 'no') { ?>
                            <li><a data-toggle="modal" data-backdrop="static" data-target="#payment-modal" onclick="makePayment(<?php echo $payment['request_id'] ?>);" class="waves-circle waves-effect waves-ripple"><i class="ti-money"></i></a></li>
                        <?php } ?>
                    </ul>
                </td>
            </tr>
        <?php } ?>

    </tbody>
</table>

<nav class="paginationdiv text-center">

    <?php
    echo \yii\widgets\LinkPager::widget([
        'pagination' => $model->pagination,
    ]);
    ?>

</nav>

<!-- Modal payment -->
<div class="modal fade" id="payment-modal">
    <div class="modal-dialog other-modal">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="myModalLabel">Payment to Pal Attorney</h4>
            </div>
            <div class="modal-body"></div>
        </div>
    </div>
</div>
<!--End modal payment-->
<script>

    $().ready(function () {

        $(".pagination li a").on('click', function (e) {

            e.preventDefault();
            var $this = $(this);
            // $('#loaderImage').show();
            var pageLink = $this.attr('href');

            $.ajax({
                type: 'GET',
                url: pageLink,
                success: function (response) {
                    // $('#loaderImage').hide();
                    $("html, body").animate({scrollTop: 300}, "slow");

                    $('#received .admintable').html(response);


                }
            });
        });

    });

    function makePayment(requestId) {
        var url = url || "<?php echo \yii::$app->urlManager->createUrl(['payment/make-payment']) ?>";
        $.ajax({
            type: "GET",
            url: url,
            data: {requestId: requestId},
            success: function (data) {
                $("#payment-modal .modal-body").html(data);
            }
        });
    }
</script>