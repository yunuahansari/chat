<table class="table">
    <thead>
        <tr>
            <th>Case ID</th>
            <th>Date/Time</th>
            <th>Sender</th>
            <th>Receiver</th>
            <th>Receiver's Email</th>
            <th>Total Amount($)</th>
            <th>Admin's Earning($)</th>
            <th>Amount Paid($)</th>
            <th>Case status</th>
            <th class="text-center">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php if (count($model->getModels()) == 0) { ?>
            <tr><td colspan="10"><div class="alert alert-danger">No Record Found</div></td></tr>
            <?php
        }
        foreach ($model->getModels() as $payment) {
            ?>
            <tr>
                <td><?php echo $payment['case_id']; ?></td>
                <td><?php echo date("F  d ,Y h:i A", strtotime($payment['case_date'].' '.$payment['case_time'])); ?></td>
                <td><?php echo ucwords($payment->fromUser->first_name .' '.$payment->fromUser->last_name)?></td>
                <td><?php echo ucwords($payment['first_name'] . ' ' . $payment['last_name']); ?></td>
                <td><?php echo $payment['email']; ?></td>
                <td><?php echo $payment['amount']; ?></td>
                <td><?php 
                    
                    if($payment['amount'] == $payment['amount_paid'] && $payment['case_status'] == 'cancelled'){
                        $adminEarning = "0.00";
                    }else{
                        $adminEarning = number_format((float) $payment['admin_earning'], 2, '.', '');
                    }
                    echo $adminEarning; ?></td>
                <td><?php echo number_format((float) $payment['amount_paid'], 2, '.', ''); ?></td>
                <td><?php echo ucfirst($payment['case_status']); ?></td>
                <td class="text-center">
                    <ul class="list-inline mb-0">
                        <li><a href="#" onclick="detailShow('<?php echo $payment['id']; ?>')" class="waves-circle waves-effect waves-ripple"><i class="ti-eye"></i></a></li>
                    </ul>
                </td>
            </tr>
        <?php } ?>
    </tbody>
</table>
<nav class="paginationdiv text-center">

    <?php
    echo \yii\widgets\LinkPager::widget([
        'pagination' => $model->pagination,
    ]);
    ?>

</nav>

<script>
    $().ready(function () {

        $(".pagination li a").on('click', function (e) {

            e.preventDefault();
            var $this = $(this);
            // $('#loaderImage').show();
            var pageLink = $this.attr('href');

            $.ajax({
                type: 'GET',
                url: pageLink,
                success: function (response) {
                    // $('#loaderImage').hide();
                    $("html, body").animate({scrollTop: 300}, "slow");

                    $('#sent .admintable').html(response);
                }
            });
        });

    });
</script>