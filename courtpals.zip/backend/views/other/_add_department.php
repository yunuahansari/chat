<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
?>  

<div class="modal-body">

    <?php $form = ActiveForm::begin(); ?>

    <div class="form-group">
        <label for="">Department Name</label>
        <?= $form->field($model, 'name')->textInput(['class' => 'form-control input-lg', 'placeholder' => 'Department Name'])->label(false); ?>
    </div>

    <div class="form-group">
        <label for="">Address</label>
        <?= $form->field($model, 'address_id')->dropDownList(\common\models\Address::getAll(), ['class' => 'form-control input-lg', 'prompt' => 'Select Address'])->label(false); ?>
    </div>

    <div class="form-group text-right">
        <button id="btn"type="submit" class="btn btn-primary noradius waves-effect waves-button waves-light text-uppercase"><?php echo ($model->isNewRecord) ? 'ADD' : 'UPDATE'; ?><i id="loader" style="display: none"class="fa fa-spinner fa-spin"></i></button>
    </div>

    <?php ActiveForm::end(); ?> 

</div>
<script>
  
    window.addEventListener('beforeunload', function(event) {
        $("#btn").attr("disabled", true);
        $("#loader").show();
     });
  
</script>