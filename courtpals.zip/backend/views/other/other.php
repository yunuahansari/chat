<?php $this->title = "Other"; ?>
<div id="content">                   
    <main class="main-content common-grid-page managecategory-page">

        <?php if (Yii::$app->session->hasFlash('message')):
            ?> <div class="alert alert-success alert-dismissable">
                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                <h4><i class="icon fa fa-check"></i>Added!</h4>
                <?= Yii::$app->session->getFlash('message') ?>

            </div>
        <?php endif; ?>
        <div class="container-fluid">
            <div class="page-title" id="pageTitle">
                <h4>Other</h4>
            </div>
            <div class="panel panel-primary filter-panel" id="panel-height">
                <div class="panel-heading clearfix filter-heading">
                    <h4 class="panel-title"><i class="ti-layout-tab-window"></i> Other List</h4>
                </div>

                <div class="panel-body">
                    <!-- Nav tabs -->
                    <ul class="nav nav-tabs" role="tablist">
                        <li id="hearing_menu" role="presentation" class="active"><a href="#hearing" onclick="getHearingTypes()" aria-controls="hearing" role="tab" data-toggle="tab">Hearing </a></li>
                        <li id="address_menu" role="presentation"><a href="#location" onclick="geAddresses()" aria-controls="location" role="tab" data-toggle="tab">Address</a></li>
                        <li id="department_menu" role="presentation"><a href="#department" onclick="geDepartment()" aria-controls="department" role="tab" data-toggle="tab">Department</a></li>
                    </ul>

                    <!-- Tab panes -->
                    <div class="tab-content">
                        <div role="tabpanel" class="tab-pane active" id="hearing">
                            <div id="hearing_type"></div>
                        </div>
                        <div role="tabpanel" class="tab-pane" id="location">
                            <div id="addresses"></div>
                        </div>
                        <div role="tabpanel" class="tab-pane" id="department">
                            <div id="departments"></div>
                        </div>
                    </div>
                    <!-- xxxxxx -->

                </div>

            </div>                        
        </div>

    </main>
</div>

<!-- Modal hearing -->
<div class="modal fade" id="hearing-modal">
    <div class="modal-dialog other-modal">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="myModalLabel">Add Hearing</h4>
            </div>
            <div class="modal-body" id="add_hearing"></div>
        </div>
    </div>
</div>

<!-- Modal location -->
<div class="modal fade" id="location-modal">
    <div class="modal-dialog other-modal">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="myModalLabel">Add Location</h4>
            </div>
            <div class="modal-body" id="add_address"></div>
        </div>
    </div>
</div>

<!-- Modal department -->
<div class="modal fade" id="department-modal">
    <div class="modal-dialog other-modal">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="myModalLabel">Add Department</h4>
            </div>
            <div class="modal-body" id="add_department"></div>
        </div>
    </div>
</div>

<?php $tab = (!empty(Yii::$app->request->get('id'))) ? Yii::$app->request->get('id') : ''; ?>

<script type="text/javascript">

    $().ready(function () {
        var tab = "<?php echo $tab; ?>";
        if (tab == "address") {
            $(".nav-tabs li").removeClass('active');
            $("div .tab-pane").removeClass('active');
            $("#address_menu").addClass('active');
            $("#location").addClass('active');
            geAddresses('');
            $("#addresses").show();
        } else if (tab == "deparments") {
            $(".nav-tabs li").removeClass('active');
            $("div .tab-pane").removeClass('active');
            $("#department_menu").addClass('active');
            $("#department").addClass('active');
            geDepartment();
        } else {
            $(".nav-tabs li").removeClass('active');
            $("div .tab-pane").removeClass('active');
            $("#hearing_menu").addClass('active');
            $("#hearing").addClass('active');
           
            getHearingTypes();
        }

    });
    
    function AddEditHearingType(id) {
        if (id) {
            var url = "<?php echo \yii::$app->urlManager->createUrl(['other/add-edit-hearing-type?id=']) ?>" + id;
        } else {
            var url = "<?php echo \yii::$app->urlManager->createUrl(['other/add-edit-hearing-type']) ?>";
        }
        
        $.ajax({
            type: "POST",
            url: url,
            success: function (data) {
                $("#add_hearing").html(data);
            }
        });
    }
    
    function getHearingTypes(id)
    {
        $('#hearing_type').html('<div class="loader text-center"><i class="fa fa-spin fa-spinner fa-3x color-blue"></i></div>');
        var url = url || "<?php echo \yii::$app->urlManager->createUrl(['other/hearing-type']) ?>";
        $.ajax({
            type: "GET",
            url: url,
            data: {id: id},
            success: function (data) {
                $("#addresses").hide();
                $("#departments").hide();
                $("#hearing_type").show();
                $("#hearing_type").html(data);
            }
        });
    }

    function AddEditAddress(id) {

        if (id) {
            var url = "<?php echo \yii::$app->urlManager->createUrl(['other/add-edit-address?id=']) ?>" + id;
        } else {
            var url = "<?php echo \yii::$app->urlManager->createUrl(['other/add-edit-address']) ?>";
        }
        $.ajax({
            type: "POST",
            url: url,
            success: function (data) {
                $("#add_address").html(data);
            }
        });
    }
    
    function geAddresses(id)
    {
        $('#addresses').html('<div class="loader text-center"><i class="fa fa-spin fa-spinner fa-3x color-blue"></i></div>');
        var url = url || "<?php echo \yii::$app->urlManager->createUrl(['other/addresses']) ?>";
        $.ajax({
            type: "GET",
            url: url,
            data: {id: id},
            success: function (data) {
                $("#departments").hide();
                $("#hearing_type").hide();
                $("#addresses").show();
                $("#addresses").html(data);
            }
        });
    }
    
    function AddEditDepartment(id) {

        if (id) {
            var url = "<?php echo \yii::$app->urlManager->createUrl(['other/add-edit-department?id=']) ?>" + id;
        } else {
            var url = "<?php echo \yii::$app->urlManager->createUrl(['other/add-edit-department']) ?>";
        }
        $.ajax({
            type: "POST",
            url: url,
            success: function (data) {
                $("#add_department").html(data);
            }
        });
    }
    
    function geDepartment(id)
    {
        $('#departments').html('<div class="loader text-center"><i class="fa fa-spin fa-spinner fa-3x color-blue"></i></div>');
        var url = url || "<?php echo \yii::$app->urlManager->createUrl(['other/department']) ?>";
        $.ajax({
            type: "GET",
            url: url,
            data: {id: id},
            success: function (data) {
                $("#hearing_type").hide();
                $("#addresses").hide();
                $("#departments").show();
                $("#departments").html(data);
            }
        });
    }
</script>