<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use common\models\HearingType;
?>  

<div class="modal-body">
    <?php $form = ActiveForm::begin(); ?> 
    <div class="form-group">
        <label for="">Hearing Name</label>
        <?= $form->field($model, 'name')->textInput(['class' => 'form-control input-lg', 'placeholder' => 'Hearing Name'])->label(false); ?>
    </div>
    
    <div class="form-group">
        <label for="">Parent Hearing</label>
        <?= $form->field($model, 'parent')->dropDownList(HearingType::getAll(),['class' => 'form-control input-lg', 'prompt'=>'None'])->label(false); ?>
    </div>

    <div class="form-group">
        <label for="">Price</label>
        <?= $form->field($model, 'price')->textInput(['class' => 'form-control input-lg', 'placeholder' => 'Price'])->label(false); ?>
    </div>

    <div class="form-group text-right">
        <button type="submit" class="btn btn-primary noradius waves-effect waves-button waves-light text-uppercase"><?php echo ($model->isNewRecord) ? 'ADD' : 'UPDATE'; ?></button>
    </div>
    <?php ActiveForm::end(); ?> 
</div>


