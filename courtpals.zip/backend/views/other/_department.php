<?php if (Yii::$app->session->hasFlash('delete')):
    ?> <div class="alert alert-success alert-dismissable">
        <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
        <h4><i class="icon fa fa-check"></i>Deleted!</h4>
        <?= Yii::$app->session->getFlash('delete') ?>

    </div>
<?php endif; ?>

<div class="filter-icon">
    <a waves class="waves-effect waves-circle waves-ripple waves-light" data-toggle="collapse" data-target="#filter03" href="javascript:void(0)">
        <i class="ti-filter"></i>
    </a>
    <a data-toggle="modal" data-target="#department-modal" onclick="AddEditDepartment()" class="create-btn waves-circle waves-effect waves-ripple"><i class="ti-plus" aria-hidden="true"></i></a>
</div>
<div class="clearfix"></div>

<div class="filter">
    <div class="collapse" id="filter03">
        <form  action="" >
            <div class="row">
                <div class="col-sm-3 col-lg-2 col">
                    <div class="form-group">
                        <label>Department</label>
                        <input type="text" class="form-control noradius" id="department_search" name="name"/>
                    </div>
                </div>
                <div class="col-sm-3 col-lg-2 col ">
                    <div class="form-group mb-0">
                        <label class="hidden-xs">&nbsp;</label>
                        <button type="button"  onclick="getDepartment()" waves class="btn btn-primary text-uppercase waves-effect waves-light noradius btn-block"><i class="ti-filter"></i> Filter</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<div class="table-responsive admintable">
    <table class="table">
        <thead>
            <tr>
                <th>Department </th>
                <th>Address</th>
                <th class="text-center">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            foreach ($departments->getModels() as $department) {
                ?>
                <tr>
                    <td><?php echo $department['name'] ?></td>                                            
                    <td><?php echo $department['address']; ?></td>                                            
                    <td class="text-center">
                        <ul class="list-inline mb-0">
                            <li><a  data-toggle="modal" data-target="#department-modal" onclick="AddEditDepartment(<?php echo $department['id'] ?>)" class="waves-circle waves-effect waves-ripple"><i class="ti-pencil-alt"></i></a></li>
                            <li><a href="javascript:void(0);" onclick="deleteConfirm(<?php echo $department['id'] ?>)" class="waves-circle waves-effect waves-ripple"><i class="ti-trash"></i></a></li>
                        </ul>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
    <div class="text-center">
        <?php
        echo \yii\widgets\LinkPager::widget([
            'pagination' => $departments->pagination,
        ]);
        ?>
    </div>
</div>

<script type="text/javascript">
    function getDepartment(id)
    {
        var search = $("#department_search").val();
        var url = url || "<?php echo \yii::$app->urlManager->createUrl(['other/department']) ?>";
        $.ajax({
            type: "GET",
            url: url,
            data: {search: search},
            success: function (data) {
                $("#addresses").hide();
                $("#hearing_type").hide();
                $("#departments").show();
                $("#departments").html(data);
            }
        });
    }

    $().ready(function () {

        $(".pagination li a").on('click', function (e) {
            e.preventDefault();
            var $this = $(this);
            // $('#loaderImage').show();
            var pageLink = $this.attr('href');

            $.ajax({
                type: 'get',
                url: pageLink,
                success: function (response) {
                    // $('#loaderImage').hide();
                    $("html, body").animate({scrollTop: 300}, "slow");
                    $('#departments').html(response);
                }
            });
        });

    });

    function deleteConfirm(id)
    {

        bootbox.confirm({
            message: "Are you sure to delete this record?",
            buttons: {
                confirm: {
                    label: 'Yes',
                    className: 'btn-success'
                },
                cancel: {
                    label: 'No',
                    className: 'btn-danger'
                }
            },
            callback: function (result) {
                if (result) {
                    var url = url || "<?php echo \yii::$app->urlManager->createUrl(['other/delete-department']) ?>?id=" + id;
                    $.ajax({
                        type: "POST",
                        url: url,
                        success: function (data) {
                            if (data) {
                                location.reload();

                            }
                        }
                    });
                }
            }
        });

    }
    window.setTimeout(function () {
        $(".alert").fadeTo(500, 0).slideUp(500, function () {
            $(this).remove();
        });
    }, 4000);

</script>
