<?php if (Yii::$app->session->hasFlash('delete')): ?> 
<div class="alert alert-success alert-dismissable">
        <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
        <h4><i class="icon fa fa-check"></i>Deleted!</h4>
        <?= Yii::$app->session->getFlash('delete') ?>
</div>
<?php endif; ?>
<div class="filter-icon">
    <a waves class="waves-effect waves-circle waves-ripple waves-light" data-toggle="collapse" data-target="#filter" href="javascript:void(0)">
        <i class="ti-filter"></i>
    </a>
    <a data-toggle="modal" data-target="#hearing-modal" onclick="AddEditHearingType()" class="create-btn waves-circle waves-effect waves-ripple"><i class="ti-plus" aria-hidden="true"></i></a>
</div>
<div class="clearfix"></div>
<div class="filter">
    <div class="collapse" id="filter">
        <form  action="" >
            <div class="row">
                <div class="col-sm-3 col-lg-2 col">
                    <div class="form-group">
                        <label>Hearing Type</label>
                        <input type="text" class="form-control noradius" id="hearing_search"name="name"/>
                    </div>
                </div>

                <div class="col-sm-3 col-lg-2 col ">
                    <div class="form-group mb-0">
                        <label class="hidden-xs">&nbsp;</label>
                        <button type="button"  onclick="getHearingTypes()" waves class="btn btn-primary text-uppercase waves-effect waves-light noradius btn-block"><i class="ti-filter"></i> Filter</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<div class="table-responsive admintable">
    <table class="table">
        <thead>
            <tr>
                <th>Hearing Type </th>
                <th>Price</th>
                <th>parent</th>
                <th class="text-center">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($hearingTypes->getModels()) == 0) { ?>
                <tr><td colspan="4"><div class="alert alert-danger">No Record Found</div></td></tr>
                <?php
            }
                                                foreach ($hearingTypes->getModels() as $hearingTpe){
                                            ?>
                                            <tr>
                                                <td><?php echo $hearingTpe['name'] ?></td>                                            
                                                <td><?php echo ($hearingTpe['price']) ? '$'.$hearingTpe['price'] : '-'; ?></td>                                            
                                                <td><?php echo $hearingTpe['parent'] ?></td>                                            
                                                <td class="text-center">
                                                    <ul class="list-inline mb-0">
                                                        <li><a  data-toggle="modal" data-target="#hearing-modal" onclick="AddEditHearingType(<?php echo $hearingTpe['id'] ?>)" class="waves-circle waves-effect waves-ripple"><i class="ti-pencil-alt"></i></a></li>

                                                        <li><a href="javascript:void(0);" onclick="deleteConfirm(<?php echo $hearingTpe['id'] ?>)" class="waves-circle waves-effect waves-ripple"><i class="ti-trash"></i></a></li>
                                                    </ul>
                                                </td>
                                            </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                                <div class="text-center">
                                    <?php
                                    echo \yii\widgets\LinkPager::widget([
                                        'pagination' => $hearingTypes->pagination,
                                    ]);
                                    ?>
                                </div>
                            </div>

                            <script type="text/javascript">
                                function getHearingTypes(id)
                                {
                                    var search = $("#hearing_search").val();
                                    var url = url || "<?php echo \yii::$app->urlManager->createUrl(['other/hearing-type']) ?>";
                                    $.ajax({
                                        type: "GET",
                                        url: url,
                                        data: {search: search},
                                        success: function (data) {
                                            $("#addresses").hide();
                                            $("#hearing_type").show();
                                            $("#hearing_type").html(data);
                                        }
                                    });
                                }

                                $().ready(function () {

                                    $(".pagination li a").on('click', function (e) {
                                        e.preventDefault();
                                        var $this = $(this);
                                        // $('#loaderImage').show();
                                        var pageLink = $this.attr('href');

                                        $.ajax({
                                            type: 'get',
                                            url: pageLink,
                                            success: function (response) {
                                                // $('#loaderImage').hide();
                                                $("html, body").animate({scrollTop: 300}, "slow");

                                                $('#hearing_type').html(response);


                                            }
                                        });
                                    });

                                });

                                function deleteConfirm(id)
                                {

                                    bootbox.confirm({
                                        message: "Are you sure to delete this record?",
                                        buttons: {
                                            confirm: {
                                                label: 'Yes',
                                                className: 'btn-success'
                                            },
                                            cancel: {
                                                label: 'No',
                                                className: 'btn-danger'
                                            }
                                        },
                                        callback: function (result) {
                                            if (result) {
                                                var url = url || "<?php echo \yii::$app->urlManager->createUrl(['other/delete-hearing-type']) ?>?id=" + id;
                                            $.ajax({
                                                type: "POST",
                                                url: url,
                                                success: function (data) {
                                                    if (data) {
                                                        location.reload();

                                                    }
                                                }
                                            });
                                        }
                                    }
                                });

                            }
                            window.setTimeout(function () {
                                $(".alert").fadeTo(500, 0).slideUp(500, function () {
                                    $(this).remove();
                                });
                            }, 4000);

                        </script>