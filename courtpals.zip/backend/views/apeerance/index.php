<?php $this->title = "courtpals"; ?>
<main class="main-content common-grid-page managereport-page">
                <div class="container-fluid">
                    <div class="page-title" id="pageTitle">
                        <h4>Appearances</h4>
                    </div>
                    <div class="panel panel-primary filter-panel" id="panel-height">
                        <div class="panel-heading clearfix filter-heading">
                            <h4 class="panel-title"><i class="ti-layout-tab-window"></i> Appearances  List</h4>
                            <div class="filter-icon">
                                <a waves class="waves-effect waves-circle waves-ripple waves-light" data-toggle="collapse" data-target="#filter" href="javascript:void(0)">
                                    <i class="ti-filter"></i>
                                </a>
                            </div>
                            <div class="clearfix"></div>
                            <div class="filter">                    
                                <div class="collapse" id="filter">
                                    <br>
                                    <form id="apeeance_filter">
                                        <div class="row">
                                            <div class="col-sm-3 col-lg-2 col">
                                                <div class="form-group">                                       
                                                    <label>Unique ID</label>
                                                    <input type="text" class="form-control noradius" name="unique_id"/>                                                    
                                                </div>
                                            </div>                                           
                                            <div class="col-sm-3 col-lg-2 col">
                                                <div class="form-group">                                       
                                                    <label>Full Name</label>
                                                    <input type="text" class="form-control noradius" name="name"/>                                                    
                                                </div>
                                            </div>                                           
                                            <div class="col-sm-3 col-lg-2 col">
                                                <div class="form-group">                                       
                                                    <label>Email</label>
                                                    <input type="text" class="form-control noradius" name="email"/>                                                    
                                                </div>
                                            </div>                                           

                                            <div class="col-sm-3 col-lg-2 col ">
                                                <div class="form-group mb-0">                                       
                                                    <label class="hidden-xs">&nbsp;</label>
                                                    <button type="button" onclick="apeeranceList()" waves class="btn btn-primary text-uppercase waves-effect waves-light noradius btn-block"><i class="ti-filter"></i> Filter</button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="panel-body">
                            
                             
                        </div>                        
                    </div>
                </div>
            </main>

<script>
    function apeeranceList(){
        $('.panel-body').html('<div class="loader text-center"><i class="fa fa-spin fa-spinner fa-3x color-blue"></i></div>');
        
         var url = url || "<?php echo \yii::$app->urlManager->createUrl(['apeerance/apeerance-list']) ?>";
         $.ajax({
            type: "GET",
            url: url,
            data : $('#apeeance_filter').serialize(),
            success: function (data) {
                $(".panel-body").html(data);
                 }
            });
    }
    
    $().ready(function () {
        apeeranceList();
    });
  </script>