<?php $this->title = "Apeerance Detail"; ?>

<div id="content">                   
    <main class="main-content common-grid-page view-page">
        <div class="container-fluid">
            <div class="page-title" id="pageTitle">
                <h4>VIEW APPEARANCES</h4>
            </div>
            <div class="panel panel-primary filter-panel" id="panel-height">
                <div class="panel-heading clearfix filter-heading">
                    <h4 class="panel-title"><i class="ti-eye" aria-hidden="true"></i> VIEW APPEARANCES</h4>
                    <a href="<?php echo yii::$app->urlManager->createAbsoluteUrl('/apeerance/') ?>" class="back-btn"><i class="ti-hand-point-left" aria-hidden="true"></i> Back</a>
                    <div class="clearfix"></div>
                </div>
                <div class="panel-body">
               
                    <div class="form-horizontal">
                        <div class="form-group">
                            <label class="control-label col-sm-2 col-md-2 col-lg-2">Unique ID   <span>:</span></label>
                            <div class="col-sm-10 col-md-10 col-lg-10">
                                <p class="form-control-static"><?php echo$user['id']; ?></p>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-sm-2 col-md-2 col-lg-2">BAR Number   <span>:</span></label>
                            <div class="col-sm-10 col-md-10 col-lg-10">
                                <p class="form-control-static"><?php echo$user['bar_number']; ?></p>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2 col-md-2 col-lg-2">SSN Number  <span>:</span></label>
                            <div class="col-sm-10 col-md-10 col-lg-10">
                                <p class="form-control-static"><?php echo$user['ssn_number']; ?></p>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2 col-md-2 col-lg-2">Full Name  <span>:</span></label>
                            <div class="col-sm-10 col-md-10 col-lg-10">
                                <p class="form-control-static"><?php echo$user['first_name'] . ' ' . $user['last_name']; ?></p>
                            </div>
                        </div>                    
                        <div class="form-group">
                            <label class="control-label col-sm-2 col-md-2 col-lg-2">Email Address <span>:</span></label>
                            <div class="col-sm-10 col-md-10 col-lg-10">
                                <p class="form-control-static">
                                    <?php echo$user['email']; ?>
                                </p>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2 col-md-2 col-lg-2">Phone Number <span>:</span></label>
                            <div class="col-sm-10 col-md-10 col-lg-10">
                                <p class="form-control-static">
                                    <?php echo$user['mobile']; ?>
                                </p>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-sm-2 col-md-2 col-lg-2">Address <span>:</span></label>
                            <div class="col-sm-10 col-md-10 col-lg-10">
                                <p class="form-control-static">
                                    <?php echo$user['address']; ?>
                                </p>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-sm-2 col-md-2 col-lg-2">City  <span>:</span></label>
                            <div class="col-sm-10 col-md-10 col-lg-10">
                                <p class="form-control-static">
                                    <?php echo$user['city']; ?>
                                </p>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-sm-2 col-md-2 col-lg-2">Zip Code  <span>:</span></label>
                            <div class="col-sm-10 col-md-10 col-lg-10">
                                <p class="form-control-static">
                                    <?php echo$user['zip_code']; ?>
                                </p>
                            </div>
                        </div>


                        <div id="case" class="admintable table-responsive">
                              <div class="panel-heading clearfix filter-heading">
       
                                <div class="filter-icon">
                                    <a waves class="waves-effect waves-circle waves-ripple waves-light" data-toggle="collapse" data-target="#filter" href="javascript:void(0)">
                                        <i class="ti-filter"></i>
                                    </a>
                                    <br>
                                </div>

                                <div class="clearfix"></div>
                                <div class="filter">                    
                                    <div class="collapse" id="filter">
                                        <br>
                                        <form id="apeeance_filter">

                                            <div class="row">
                                                <div class="col-sm-3 col-lg-2 col">
                                                    <div class="form-group">                                       
                                                        <label>Unique ID</label>
                                                        <input type="text" id="unique_id" class="form-control noradius" name="unique_id"/>                                                    
                                                    </div>
                                                </div>                                           

                                                <div class="col-sm-3 col-lg-2 col ">
                                                    <div class="form-group mb-0">                                       
                                                        <label class="hidden-xs">&nbsp;</label>
                                                        <button type="button" onclick="getApperanceList()" waves class="btn btn-primary text-uppercase waves-effect waves-light noradius btn-block"><i class="ti-filter"></i> Filter</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <table class="table">

                                <thead>
                                    <tr>
                                        <th>Case Id</th>
                                        <th>Case Placed Date</th>
                                        <th>Hearing Date</th>
                                        <th>Party1.</th>
                                        <th>Party2</th>
                                        <th>Department</th>
                                        <th>Hearing Type</th>
                                        <th>Sub-Type</th>
                                        <th>Number of Attachment</th>
                                        <th>Tags</th>
                                        <th>Pal Attorney</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
    
                        </div>
                          
                    </div>
                </div>                        
            </div>
        </div>
    </main>
</div>


<script type="text/javascript">
    function getApperanceList()
    {
        var url = url || "<?php echo \yii::$app->urlManager->createUrl(['apeerance/attorney-cases']) ?>";
        $.ajax({
            type: "GET",
            url: url,
            data:{id:<?php echo $user['id'];?>,case_id:$('#unique_id').val()},
            success: function (data) {
                $("#case .table tbody").html(data);
                }
            });
    }
    
    $().ready(function () {
        
          $(".pagination li a").on('click', function (e) {

            e.preventDefault();
            var $this = $(this);
            // $('#loaderImage').show();
            var pageLink = $this.attr('href');

            $.ajax({
                type: 'POST',
                url: pageLink,
              
                success: function (response) {
                    // $('#loaderImage').hide();
                    $("html, body").animate({scrollTop: 300}, "slow");

                    $('#case').html(response);


                }
            });
        });
        getApperanceList();
    });

</script>