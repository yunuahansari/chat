
<div class="table-responsive admintable">
    <table class="table">
        <thead>
            <tr>
                <th>Unique ID</th>

                <th>Full Name</th>
                <th>Email Address</th>
                <th class="text-center">Appearance</th>
                <th class="text-center">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($apeerances->getModels()) == 0) { ?>
                <tr><td colspan="5"><div class="alert alert-danger">No Record Found</div></td></tr>
                <?php
            }
            foreach ($apeerances->getModels() as $apeerance) {
                ?>
                <tr>
                    <td><?php echo $apeerance['id'] ?></td>

                    <td><?php echo $apeerance['first_name'] . ' ' . $apeerance['last_name'] ?></td>
                    <td><?php echo $apeerance['email'] ?></td>
                    <td class="text-center"><?php echo $apeerance['apeerances'] ?></td>
                    <td class="text-center">
                        <ul class="list-inline mb-0">
                            <li><a href="<?php echo yii::$app->urlManager->createAbsoluteUrl(['/apeerance/apeerance-detail', 'id' => $apeerance['id']]) ?>" class="waves-circle waves-effect waves-ripple"><i class="ti-eye"></i></a></li> 

<!--                            <li><a href="javascript:void(0);" class="waves-circle waves-effect waves-ripple"><i class="ti-trash"></i></a></li>-->
                        </ul>
                    </td>                                              
                </tr>   
            <?php } ?>

        </tbody>
    </table>
    <nav class="paginationdiv text-center">
     <?php
        echo \yii\widgets\LinkPager::widget([
            'pagination' => $apeerances->pagination,
        ]);
        ?>
    </nav>
</div>

  <script type="text/javascript">

    $().ready(function () {

        $(".pagination li a").on('click', function (e) {

            e.preventDefault();
            var $this = $(this);
            // $('#loaderImage').show();
            var pageLink = $this.attr('href');

            $.ajax({
                type: 'POST',
                url: pageLink,
                success: function (response) {
                    // $('#loaderImage').hide();
                    $("html, body").animate({scrollTop: 300}, "slow");

                    $('.panel-body').html(response);


                }
            });
        });
       
    });

</script>     