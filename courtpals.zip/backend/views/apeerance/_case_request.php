
                <?php foreach ($cases->getModels() as $case) { ?>
                    <tr>
                        <td><?php echo $case->case_id; ?></td>
                        <td><?php echo date('F  d ,Y',  strtotime($case->created_at)); ?></td>
                        <td><?php echo date('F  d ,Y',  strtotime($case->case_date)); ?></td>
                        <td><?php echo $case->party_2; ?></td>
                        <td><?php echo $case->party_1; ?></td>
                        <td><?php echo $case->department->name; ?></td>
                        <td><?php echo $case->hearingType->name; ?></td>
                        <td><?php echo $case->sub_hearing_type; ?></td>
                        <td><?php echo count($case->caseRequestImages); ?></td>
                        <td><?php 
                                $tags = [];
                                if (!empty($case->requestTags)){
                                    foreach($case->requestTags as $request_tag)
                                        echo '<span class="label label-primary"> '.$request_tag->tag->name.' </span> &nbsp;'; 
                                }
                            ?>
                        </td>
                        <td><?php echo $case->to->first_name.' '.$case->to->last_name; ?></td>
                        <td><?php echo ucfirst($case->status); ?></td>

                <?php } ?>
           
                    <tr><td colspan="10">
    <nav class="paginationdiv text-center">
        <?php
            echo \yii\widgets\LinkPager::widget([
                'pagination' => $cases->pagination,
            ]);
         ?>
    </nav>
                        </td></tr>
<script type="text/javascript">

    $().ready(function () {

        $(".pagination li a").on('click', function (e) {
            e.preventDefault();
            var $this = $(this);
            var pageLink = $this.attr('href');
            $.ajax({
                type: 'POST',
                url: pageLink,
                success: function (response) {
                    $("html, body").animate({scrollTop: 300}, "slow");
                    $('#case .table tbody').html(response);
                }
            });
        });
       
    });

</script>
