<table class="table">
        <thead>
            <tr>
                <th>Unique ID</th>
                <th>BAR No.</th>
                <th>Full Name</th>
                <th>Email Address</th>
                <th>Commission</th>
                <th class="text-center">Status</th>
                <th class="text-center">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (count($users->getModels()) > 0) {
                foreach ($users->getModels() as $user) {
                    ?>
                    <tr>
                        <td><?php echo $user['id']; ?></td>
                        <td><?php echo $user['bar_number']; ?></td>
                        <td><?php echo $user['first_name'] . ' ' . $user['last_name']; ?></td>
                        <td><?php echo $user['email']; ?></td>
                        <td><input onblur="updateCommition('<?php echo $user['id']; ?>',this.value);" id="txtBox_<?php echo $user['id']; ?>" type="textbox" value="<?php echo ($user['commition']) ? $user['commition'] : 0; ?>" style="display:none; width: 50px;" /><span id="span_<?php echo $user['id']; ?>" ondblclick="showTextBox('txtBox_<?php echo $user['id']; ?>',this)"><?php echo ($user['commition']) ? $user['commition'] : 0; ?>%</span></td>
                        <td class="text-center">
                            <div class="statusbtn">
                                <div class="status-chk enable">
                                    <input id="enable_<?php echo $user['id']; ?>" value="active" name="radio_<?php echo $user['id']; ?>" <?php if ($user['status'] == 'active') { ?> checked="checked" <?php }; ?> type="radio" onclick="activeInacive(this.value, <?php echo $user['id']; ?>)"> 
                                    <label for="enable_<?php echo $user['id']; ?>" >ACTIVE</label>
                                </div>
                                <div class="or"></div>
                                <div class="status-chk disable">
                                    <input id="disable_<?php echo $user['id']; ?>" value="banned" name="radio_<?php echo $user['id']; ?>" <?php if ($user['status'] == 'banned') { ?> checked="checked" <?php }; ?> type="radio" onclick="activeInacive(this.value, '<?php echo $user['id']; ?>')"> 
                                    <label for="disable_<?php echo $user['id']; ?>">BANNED</label>
                                </div>

                            </div>
                        </td>
                        <td class="text-center">
                            <ul class="list-inline mb-0">
                                <li><a href="<?php echo Yii::$app->urlManager->createAbsoluteUrl(['/attorney/banned-attorney-view/', 'id' => $user['id']]) ?>" class="waves-circle waves-effect waves-ripple"><i class="ti-eye"></i></a></li>
                            </ul>
                        </td>
                    </tr>
                    <?php
                        }
                    } else {
                        ?>
                <tr><td colspan="7"><div class="alert alert-danger">No Record Found</div></td></tr>
            <?php } ?>
        </tbody>
    </table>
    <nav class="paginationdiv text-center">
        <?php
        echo \yii\widgets\LinkPager::widget([
            'pagination' => $users->pagination,
        ]);
        ?>
    </nav>
<div id="myModal" class="modal hide">
    <div class="modal-header">
        <a href="#" data-dismiss="modal" aria-hidden="true" class="close">×</a>
        <h3>Delete</h3>
    </div>
    <div class="modal-body">
        <p>You are about to delete.</p>
        <p>Do you want to proceed?</p>
    </div>
    <div class="modal-footer">
        <a href="#" id="btnYes" class="btn danger">Yes</a>
        <a href="#" data-dismiss="modal" aria-hidden="true" class="btn secondary">No</a>
    </div>
</div>
<script type="text/javascript">
    function showTextBox(textBoxId,obj){
        $(obj).hide(); //hide text
        $('#'+textBoxId).show(); //show textbox
        $('#'+textBoxId).focus();
    }
    
    function updateCommition(userId,commition){
        $.ajax({
            type: 'POST',
            url: "<?php echo Yii::$app->urlManager->createAbsoluteUrl('admin/update-commition'); ?>",
            data:{userId:userId,commition:commition},
            success: function (response) {
                if(response){
                    $('#txtBox_'+userId).val(commition);
                    $('#span_'+userId).text(commition+'%');
                    $('#txtBox_'+userId).hide();
                    $('#span_'+userId).show();
                }
            }
        });
    }
    $().ready(function () {

        $(".pagination li a").on('click', function (e) {

            e.preventDefault();
            var $this = $(this);
            var pageLink = $this.attr('href');

            $.ajax({
                type: 'POST',
                url: pageLink,
                success: function (response) {
                    $("html, body").animate({scrollTop: 300}, "slow");
                    $('#banned-attornies .admintable').html(response);
                }
            });
        });

    });

</script>

