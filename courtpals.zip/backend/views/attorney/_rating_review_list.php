            <?php foreach ($reviews->getModels() as $review) {  
                ?>
                    <tr>
                        <td> <?php echo $review->fromUser->first_name. ' '.$review->fromUser->last_name; ?> </td>
                        <td> 
                            <span id="stars_<?php echo $review->id; ?>">
                            </span>
                        </td>
                           <script>
                            $.fn.raty.defaults.path = '<?php echo Yii::getAlias("@images_url"); ?>/raty';
                            $("#stars_<?php echo $review->id;?>").raty({
                                half: true,
                                halfShow:true,
                                targetType: 'score',
                                readOnly: true,
                                score: '<?php echo ($review->rating!=0)? $review->rating : 0 ; ?>'
                            });  
                           </script>
                        <td><?php echo $review->review_text; ?></td>
                        <td><?php echo date('F d Y h:i A', strtotime($review->created_at)); ?></td>     
                    </tr>
                <?php } ?>
           
                       <tr><td colspan="4">
                        <nav class="paginationdiv text-center">
                        <?php
                        echo \yii\widgets\LinkPager::widget([
                            'pagination' => $reviews->pagination,
                        ]);
                        ?>
                        </nav>
                        </td> </tr>
<script type="text/javascript">

    $().ready(function () {

        $(".pagination li a").on('click', function (e) {
            e.preventDefault();
            var $this = $(this);
            var pageLink = $this.attr('href');
            $.ajax({
                type: 'GET',
                url: pageLink,
                success: function (response) {
                    $("html, body").animate({scrollTop: 300}, "slow");
                    $('#rating-review-list .table tbody').html(response);
                }
            });
        });
       
    });

</script>
