<?php 
//echo "<pre>";
//print_r($users->getModels());die;

?>

<table class="table">
        <thead>
            <tr >
                
                 <?php if($type=='not-verified'){?>
                <th>Unique ID</th>
                <th>Full Name</th>
                <th>Email Address</th>
                <th >Date Registered</th>
                <th class="text-center">Status</th>
                <th class="text-center">Action</th>
                <?php   }elseif($type == 'not_approved'){?>
                <th>
                    <label class="custom-check">
                        <input type="checkbox" class="chkbx"  name="chk[]" />
                        <i></i>
                        <span></span>
                    </label>
                </th>
                <th>Unique ID</th>
                <th>BAR No.</th>
                <th>Full Name</th>
                <th>Email Address</th>
                <th >Date Registered</th>
                <th>Commission</th>
                <th >Approve</th>
                <th class="text-center">Action</th>
                 <?php }else{?>
               <th>
                    <label class="custom-check">
                        <input type="checkbox" id="checkAll" class="chkbx"  name="chk[]" />
                        <i></i>
                        <span></span>
                    </label>
                </th>
                <th>Unique ID</th>
                <th>BAR No.</th>
                <th>Full Name</th>
                <th>Email Address</th>
                <th >Date Registered</th>
                <th>Commission</th>
                <th>Rating</th>
                
                 <th class="text-center"><label class="custom-check">
                        <input type="checkbox" id="paermint" class="permit"  name="chk[]" />
                        <i></i>
                        <span></span>
                 </label> &nbsp;&nbsp;Can Place a case?</th>
                 <th class="text-center">Status</th>
                 <th class="text-center">Action</th>
                 <?php }?>
                
            </tr>
        </thead>
        <tbody>
            <?php
            if (count($users->getModels()) > 0) {
                 $i=1;
                foreach ($users->getModels() as $user) {
                    ?>
                    <tr id="row_<?php echo $user['id']; ?>">
                        <?php if($type=='not-verified'){?>
                        <td><?php echo $user['id']; ?></td>
                        <td><?php echo ucwords($user['first_name'] . ' ' . $user['last_name']); ?></td>
                        <td><?php echo $user['email']; ?></td>
                        <td> 
                            <?php echo date('F  d ,Y',  strtotime($user['created_at'])); ?>
                        </td>
                        <td class="text-center"> 
                             <?php if($user->verified_code == '' || $user->type=='linkedin')
                                echo "Email Verified"; 
                          
                            else{
                               echo "Email Not Verified"; 
                            }
                             ?>
                        </td>
                        <td class="text-center">
                            <ul class="list-inline mb-0">
                                <li><a href="<?php echo Yii::$app->urlManager->createAbsoluteUrl(['/attorney/unverified-attorney-view/', 'id' => $user['id']]) ?>" class="waves-circle waves-effect waves-ripple"><i class="ti-eye"></i></a></li>
                                <li><a href="<?php echo Yii::$app->urlManager->createAbsoluteUrl(['/attorney/unverified-attorney-edit/', 'id' => $user['id']]) ?>" class="waves-circle waves-effect waves-ripple"><i class="ti-pencil-alt"></i></a></li>
                                <li><a href="javascript:void(0);"  onclick="deleteConfirm(<?php echo $user['id'] ?>)" class="confirm-delete waves-circle waves-effect waves-ripple"><i class="ti-trash"></i></a></li>                                
                            </ul>
                        </td>
                        <?php }else{
                            ?>
                        <td class="text-center"> 
                            <label class="custom-check">
                                <input  class="chkbx" type="checkbox" value="<?php echo $user['id']; ?>" name="attorney[]">
                                <i></i>
                            </label>

                        </td>
                        <td><?php echo $user['id']; ?></td>
                        <td><?php echo $user['bar_number']; ?></td>
                        <td><?php echo ucwords($user['first_name'] . ' ' . $user['last_name']); ?></td>
                        <td><?php echo $user['email']; ?></td>
                        <td> 
                            <?php echo date('F  d ,Y',  strtotime($user['created_at'])); ?>
                        </td>
                        <td><input onblur="updateCommition('<?php echo $user['id']; ?>',this.value);" id="txtBox_<?php echo $user['id']; ?>" type="textbox" value="<?php echo ($user['commition']) ? $user['commition'] : 0; ?>" style="display:none; width: 50px;" /><span id="span_<?php echo $user['id']; ?>" ondblclick="showTextBox('txtBox_<?php echo $user['id']; ?>',this)"><?php echo ($user['commition']) ? $user['commition'] : 0; ?>%</span></td>
                        <?php  if($type != 'not_approved'){?>
                        <td> <span id="stars_<?php echo $user->id?>">
                            </span></td>
                           <script>
                            $.fn.raty.defaults.path = '<?php echo Yii::getAlias("@images_url"); ?>/raty';
                            $("#stars_<?php echo $user->id?>").raty({
                                half: true,
                                halfShow:true,
                                targetType: 'score',
                                readOnly: true,
                                score: <?php echo ($user['rating'])?$user['rating']:0;?>
                            });  
                           </script>
                        
                        <?php }?>
                        
                        
                          <?php  if($type != 'not_approved'){?>
                           <td class="text-center"> 
                              <label class="custom-check">
                                   <input  id="per_<?php echo $user['id'] ?>" class="permit" value="<?php echo $user['id']; ?>" onclick="PermintPlaceCase('<?php echo $user['id'] ?>')" <?php if($user['can_place']=='yes'){ ?> checked="checked" <?php } ?> type="checkbox"  name="can_place[]">
                                <i></i>
                            </label>
                            </td>
                            <?php 
                            }
                                ?>
                       
                        <td class="text-center"> 
                          <?php  if($type == 'not_approved'){?>
                           
                           <div class="statusbtn">
                                <div class="status-chk enable">
                                    <input id="apr<?php echo $user['id']; ?>" value="active" name="radio_<?php echo $user['id']; ?>" <?php if ($user['approved'] == 'yes') { ?> checked="checked" <?php }; ?> type="radio" onclick="approve(this.value, <?php echo $user['id']; ?>)"> 
                                    <label for="apr_<?php echo $user['id']; ?>" >APPROVE <i id="loader_<?php echo $user['id']; ?>" style="display: none" class="fa fa-spin fa-spinner color-pink"></i></label>
                                </div>
                                <div class="or"></div>
                                <div class="status-chk disable">
                                    <input id="apr_<?php echo $user['id']; ?>" value="inactive" name="radio_<?php echo $user['id']; ?>" <?php if ($user['approved'] == 'no') { ?> checked="checked" <?php }; ?> type="radio" onclick="approve(this.value, '<?php echo $user['id']; ?>')"> 
                                    <label for="apr_<?php echo $user['id']; ?>">DECLINE</label>
                                </div>

                            </div>
                            <?php 
                            }else{?>
                               <div class="statusbtn">
                                <div class="status-chk enable">
                                    <input id="enable_<?php echo $user['id']; ?>" value="active" name="radio_<?php echo $user['id']; ?>" <?php if ($user['status'] == 'active') { ?> checked="checked" <?php }; ?> type="radio" onclick="activeInacive(this.value, <?php echo $user['id']; ?>)"> 
                                    <label for="enable_<?php echo $user['id']; ?>" >APPROVE <i id="loader_<?php echo $user['id']; ?>" style="display: none" class="fa fa-spin fa-spinner color-pink"></i></label>
                                </div>
                                <div class="or"></div>
                                <div class="status-chk disable">
                                    <input id="disable_<?php echo $user['id']; ?>" value="inactive" name="radio_<?php echo $user['id']; ?>" <?php if ($user['status'] == 'inactive') { ?> checked="checked" <?php }; ?> type="radio" onclick="activeInacive(this.value, '<?php echo $user['id']; ?>')"> 
                                    <label for="disable_<?php echo $user['id']; ?>">DECLINE</label>
                                </div>

                            </div>
                            <?php
                            }
                                ?>
                        </td>
                      
                        <?php  if($type == 'not_approved'){?>
                        <td class="text-center">
                            <ul class="list-inline mb-0">
                                <li><a href="<?php echo Yii::$app->urlManager->createAbsoluteUrl(['/attorney/pending-attorney-view/', 'id' => $user['id']]) ?>" class="waves-circle waves-effect waves-ripple"><i class="ti-eye"></i></a></li>
                                <li><a href="<?php echo Yii::$app->urlManager->createAbsoluteUrl(['/attorney/pending-attorney-edit/', 'id' => $user['id']]) ?>" class="waves-circle waves-effect waves-ripple"><i class="ti-pencil-alt"></i></a></li>
                                <li><a href="javascript:void(0);"  onclick="deleteConfirm(<?php echo $user['id'] ?>)" class="confirm-delete waves-circle waves-effect waves-ripple"><i class="ti-trash"></i></a></li>                                
                            </ul>
                        </td>
                        <?php 
                            }else{?>
                        <td class="text-center">
                            <ul class="list-inline mb-0">
                                <li><a href="<?php echo Yii::$app->urlManager->createAbsoluteUrl(['/attorney/attorney-view/', 'id' => $user['id']]) ?>" class="waves-circle waves-effect waves-ripple"><i class="ti-eye"></i></a></li>
                                <li><a href="<?php echo Yii::$app->urlManager->createAbsoluteUrl(['/attorney/attorney-edit/', 'id' => $user['id']]) ?>" class="waves-circle waves-effect waves-ripple"><i class="ti-pencil-alt"></i></a></li>
                                <li><a href="javascript:void(0);"  onclick="deleteConfirm(<?php echo $user['id'] ?>)" class="confirm-delete waves-circle waves-effect waves-ripple"><i class="ti-trash"></i></a></li>                                
                            </ul>
                        </td>
                        <?php
                            }
                                ?>
                    </tr>
                    <?php
                   if($user['can_place']=='no'){
                       $i=0;
                   }
                }}
                    } else {
                        ?>
                <tr><td colspan="9"><div class="alert alert-danger">No Record Found</div></td></tr>
            <?php } ?>
        </tbody>
    </table>
    <nav class="paginationdiv text-center">
        <?php
        echo \yii\widgets\LinkPager::widget([
            'pagination' => $users->pagination,
        ]);
        ?>
    </nav>
<div id="myModal" class="modal hide">
    <div class="modal-header">
        <a href="#" data-dismiss="modal" aria-hidden="true" class="close">×</a>
        <h3>Delete</h3>
    </div>
    <div class="modal-body">
        <p>You are about to delete.</p>
        <p>Do you want to proceed?</p>
    </div>
    <div class="modal-footer">
        <a href="#" id="btnYes" class="btn danger">Yes</a>
        <a href="#" data-dismiss="modal" aria-hidden="true" class="btn secondary">No</a>
    </div>
</div>
<style>
    .statusbtn{
        width:200px !important;
    }
</style>
<script type="text/javascript">
    if('<?php if(isset($i)) echo $i ?>'==1){
        $("#paermint").prop("checked", true);
    }
$(function () {
    $("#checkAll").click(function () {
        if ($("#checkAll").is(':checked')) {
            $(".chkbx").prop("checked", true);
        } else {
            $(".chkbx").prop("checked", false);
        }
    });
})

    $("#paermint").click(function () {
        if ($("#paermint").is(':checked')) {
            $(".permit").prop("checked", true);
           var type = 'permit';
           var message  = "Are you sure you want to enable 'Place a Case' feature for all Attorneys?";
        } else {
            $(".permit").prop("checked", false);
            var type = 'unpermit';
            var message  = "Are you sure you want to disable 'Place a Case' feature for all Attorneys?";
        }
        var ids = [];
        $.each($("input[name='can_place[]']"), function(){
           ids.push($(this).val());
        });
        
         bootbox.confirm({
            message: message,
            buttons: {
                confirm: {
                    label: 'Yes',
                    className: 'btn-success'
                },
                cancel: {
                    label: 'No',
                    className: 'btn-danger'
                }
            },
            callback: function (result) {
                if (result) {
                   var url = url || "<?php echo \yii::$app->urlManager->createUrl(['attorney/permit-all-for-case']) ?>";
                    $.ajax({
                        type: "POST",
                        url: url,
                        data:{ids:ids,type:type},
                        success: function (data) {
                            if (data) {
                                if(data=='true'){
                                    var alert_message = "All selected Attorney has been permitted";
                                }else{
                                   var alert_message = "All selected Attorney has been unpermitted"; 
                                }
                                 toastr.remove();
                                 toastr.options.closeButton = true;
                                 toastr.success(alert_message, 'Success', {
                                   timeOut: 3000
                                });
                            }
                        }
                    });
             window.setTimeout(function () {
                    $(".alert").fadeTo(500, 0).slideUp(500, function () {
                        $(this).remove();
                    });
                }, 4000);
                }else{
                       attorneyList();
                }
            }
        });
          
        
    });

    
//    function checkAll(ele) {
//      var checkboxes = document.getElementsByTagName('input');
//     if (ele.checked) {
//         for (var i = 0; i < checkboxes.length; i++) {
//             if (checkboxes[i].type == 'checkbox') {
//                 checkboxes[i].checked = true;
//             }
//         }
//     } else {
//         for (var i = 0; i < checkboxes.length; i++) {
//             if (checkboxes[i].type == 'checkbox') {
//                 checkboxes[i].checked = false;
//             }
//         }
//     }
// }
 
    $(document).on('submit', '#download', function(event){
        var ids = [];
        $.each($("input[name='attorney[]']:checked"), function(){
           ids.push($(this).val());
        });
        $('#excel-id').val(ids);
        //event.preventDefault();
    });
 
    function showTextBox(textBoxId,obj){
        $(obj).hide(); //hide text
        $('#'+textBoxId).show(); //show textbox
        $('#'+textBoxId).focus();
    }
    
    function updateCommition(userId,commition){
        $.ajax({
            type: 'POST',
            url: "<?php echo Yii::$app->urlManager->createAbsoluteUrl('admin/update-commition'); ?>",
            data:{userId:userId,commition:commition},
            success: function (response) {
                if(response){
                    $('#txtBox_'+userId).val(commition);
                    $('#span_'+userId).text(commition+'%');
                    $('#txtBox_'+userId).hide();
                    $('#span_'+userId).show();
                }
            }
        });
    }
    $().ready(function () {

        $(".pagination li a").on('click', function (e) {

            e.preventDefault();
            var $this = $(this);
            var pageLink = $this.attr('href');
            console.log(pageLink);
            $.ajax({
                type: 'POST',
                url: pageLink,
                success: function (response) {
                    $("html, body").animate({scrollTop: 300}, "slow");
                    if('<?php echo $type?>' =='not_approved'){
                     $('#not-approved .admintable').html(response);   
                    }
                    if('<?php echo $type?>' == 'not_banned'){
                     $('#attornies .admintable').html(response);   
                    }
                    if('<?php echo $type?>' =='not-verified'){
                    $('#not-verified-emial .admintable').html(response);
                    }
                    
                }
            });
        });

    });

</script>



