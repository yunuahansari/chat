<?php

use yii\helpers\BaseHtml;

$this->title = "Attorney";
?>

<div id="content">
    <main class="main-content common-grid-page manageuser-page">
        <div class="container-fluid">
            <div class="page-title" id="pageTitle">
                <h4>Attorney</h4>
            </div>

            <?php if (Yii::$app->session->hasFlash('success')):
                ?> <div class="alert alert-success alert-dismissable">
                    <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                    <h4><i class="icon fa fa-check"></i>Saved!</h4>
                    <?= Yii::$app->session->getFlash('success') ?>

                </div>
            <?php endif; ?>

           
            <?php if (Yii::$app->session->hasFlash('createAttorny')):
                ?> <div class="alert alert-success alert-dismissable">
                    <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                    <h4><i class="icon fa fa-check"></i>Create!</h4>
                    <?= Yii::$app->session->getFlash('createAttorny') ?>

                </div>
            <?php endif; ?>
            <?php if (Yii::$app->session->hasFlash('blanck_sheet')):
                ?> <div class="alert alert-danger alert-dismissable">
                    <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                    <h4><i class="icon fa fa-check"></i>Blank!</h4>
                    <?= Yii::$app->session->getFlash('blanck_sheet') ?>

                </div>
            <?php endif; ?>
            

            <div class="panel panel-primary filter-panel" id="panel-height">
                <div class="panel-heading clearfix filter-heading">
                    <h4 class="panel-title"><i class="ti-layout-tab-window"></i> Attorney List</h4>
                </div>
                <div  class="panel-body">
                    <!-- Nav tabs -->
                    <ul id="myTab" class="nav nav-tabs" role="tablist">
                        <li role="presentation" id="tab_approved" class="childtab active"><a href="#attornies" onClick="attorneyList()" aria-controls="attornies" role="tab" data-toggle="tab">Approved by Admin</a></li>
                        <li role="presentation" id="tab_unapproved" class="childtab"><a href="#not-approved" onClick="notApprovedAttorneyList()" aria-controls="not-approved" role="tab" data-toggle="tab">Pending Requests</a></li>
                        <li role="presentation" id="tab_unverify" class="childtab"><a href="#not-verified-emial"  onClick="notEmailVerifiedAttorneyList()" aria-controls="not-verified-emial" role="tab" data-toggle="tab">UN-Verified</a></li>
                        <li role="presentation" id="tab_banned" class="childtab"><a href="#banned-attornies" onClick="bannedAttorneyList()" aria-controls="banned-attornies" role="tab" data-toggle="tab">Banned Attorney</a></li>
                    </ul>
                    <!-- Tab panes -->
                    <div class="tab-content" id="myTabContent">
                        <div role="tabpanel" class="tab-pane active" id="attornies">
                            <i id="loader"style="display: none" class="fa fa-spin fa-spinner fa-3x color-blue"></i>
                            <div class="if-excel-row">
                                <div class="filter-icon xs-float">
                                    <a waves class="waves-effect waves-circle waves-ripple waves-light" data-toggle="collapse" data-target="#filter" href="javascript:void(0)">
                                        <i class="ti-filter"></i>
                                    </a>

                                    <a href="<?php echo Yii::$app->urlManager->createAbsoluteUrl('/attorney/create-attorney') ?>" class="create-btn waves-circle waves-effect waves-ripple"><i class="ti-plus"></i></a>
                                </div>

                                <div class="dwnld-csv">
                                    <form id="download" method="post" action="<?php echo Yii::$app->urlManager->createAbsoluteUrl('attorney/download-attorney-list'); ?>">
                                        <select  name="type">
                                            <option value="All">All</option>
                                            <option value="Select">Selected</option>
                                        </select>
                                        <input type="hidden" id="excel-id" name="attorney-id"/>
                                        <button type="submit" class="btn btn-primary btn-lg noradius waves-effect waves-button waves-light text-uppercase"><i class="ti-import"></i> Excel</button>
                                    </form>
                                </div>
                            </div>
                            <div style="display: none" id="loader" class="loader text-center"><i id="loder"class="fa fa-spin fa-spinner fa-3x color-blue"></i></div>
                            <div class="clearfix"></div>
                            <div class="filter">
                                <div class="collapse" id="filter">
                                    <br>
                                    <form id="attorney_filter">
<!--                                        <input type="hidden" value="list" name="type"/> </div>-->
                                        <input type="hidden" class="form-control noradius" name="status" value=""/>
                                        <input type="hidden" class="form-control noradius" name="type" value="not_banned"/>
                                        <div class="row">
                                            <div class="col-sm-3 col-lg-2 col">
                                                <div class="form-group">
                                                    <label>Unique ID</label>
                                                    <input type="text" class="form-control noradius" name="unique_id"/> </div>

                                            </div>
                                            <div class="col-sm-3 col-lg-2 col">
                                                <div class="form-group">
                                                    <label>Full Name</label>
                                                    <input type="text" class="form-control noradius" name="name"/> </div>
                                            </div>
                                            <div class="col-sm-3 col-lg-2 col">
                                                <div class="form-group">
                                                    <label>Email</label>
                                                    <input type="text" class="form-control noradius" name="email"/> </div>
                                            </div>
                                            <div class="col-sm-3 col-lg-2 col ">
                                                <div class="form-group mb-0">
                                                    <label class="hidden-xs">&nbsp;</label>
                                                    <button type="button" onclick="attorneyList()" waves class="btn btn-primary text-uppercase waves-effect waves-light noradius btn-block"><i class="ti-filter"></i> Filter</button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <div class="table-responsive admintable">
                            </div>
                        </div>
                        <div role="tabpanel" class="tab-pane active" id="not-verified-emial">
                            <i id="loader"style="display: none" class="fa fa-spin fa-spinner fa-3x color-blue"></i>
                            <div class="if-excel-row">
                                <div class="filter-icon xs-float">
                                    <a waves class="waves-effect waves-circle waves-ripple waves-light" data-toggle="collapse" data-target="#not-email-verified" href="javascript:void(0)">
                                        <i class="ti-filter"></i>
                                    </a>

                                    <a href="<?php echo Yii::$app->urlManager->createAbsoluteUrl('/attorney/create-attorney') ?>" class="create-btn waves-circle waves-effect waves-ripple"><i class="ti-plus"></i></a>
                                </div>

                              
                            </div>
                            <div style="display: none" id="loader" class="loader text-center"><i id="loder"class="fa fa-spin fa-spinner fa-3x color-blue"></i></div>
                            <div class="clearfix"></div>
                            <div class="filter">
                                <div class="collapse" id="not-email-verified">
                                    <br>
                                    <form id="not-verified">
                                        <input type="hidden" class="form-control noradius" name="type" value="not-verified"/>
                                        <div class="row">
                                            <div class="col-sm-3 col-lg-2 col">
                                                <div class="form-group">
                                                    <label>Unique ID</label>
                                                    <input type="text" class="form-control noradius" name="unique_id"/> </div>
                                            </div>
                                            <div class="col-sm-3 col-lg-2 col">
                                                <div class="form-group">
                                                    <label>Full Name</label>
                                                    <input type="text" class="form-control noradius" name="name"/> </div>
                                            </div>
                                            <div class="col-sm-3 col-lg-2 col">
                                                <div class="form-group">
                                                    <label>Email</label>
                                                    <input type="text" class="form-control noradius" name="email"/> </div>
                                            </div>
                                            <div class="col-sm-3 col-lg-2 col ">
                                                <div class="form-group mb-0">
                                                    <label class="hidden-xs">&nbsp;</label>
                                                    <button type="button" onclick="notEmailVerifiedAttorneyList()" waves class="btn btn-primary text-uppercase waves-effect waves-light noradius btn-block"><i class="ti-filter"></i> Filter</button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <div class="table-responsive admintable">
                            </div>
                        </div>
                        <div role="tabpanel" class="tab-pane active" id="not-approved">
                            <i id="loader"style="display: none" class="fa fa-spin fa-spinner fa-3x color-blue"></i>
                            <div class="if-excel-row">
                                <div class="filter-icon xs-float">
                                    <a waves class="waves-effect waves-circle waves-ripple waves-light" data-toggle="collapse" data-target="#not-approved-filter" href="javascript:void(0)">
                                        <i class="ti-filter"></i>
                                    </a>

                                    <a href="<?php echo Yii::$app->urlManager->createAbsoluteUrl('/attorney/create-attorney') ?>" class="create-btn waves-circle waves-effect waves-ripple"><i class="ti-plus"></i></a>
                                </div>

                                
                            </div>
                            <div style="display: none" id="loader" class="loader text-center"><i id="loder"class="fa fa-spin fa-spinner fa-3x color-blue"></i></div>
                            <div class="clearfix"></div>
                            <div class="filter">
                                <div class="collapse" id="not-approved-filter">
                                    <br>
                                    <form id="not-approved_filter">
                                        <input type="hidden" class="form-control noradius" name="type" value="not_approved"/>
                                        <div class="row">
                                            <div class="col-sm-3 col-lg-2 col">
                                                <div class="form-group">
                                                    <label>Unique ID</label>
                                                    <input type="text" class="form-control noradius" name="unique_id"/> </div>
                                            </div>
                                            <div class="col-sm-3 col-lg-2 col">
                                                <div class="form-group">
                                                    <label>Full Name</label>
                                                    <input type="text" class="form-control noradius" name="name"/> </div>
                                            </div>
                                            <div class="col-sm-3 col-lg-2 col">
                                                <div class="form-group">
                                                    <label>Email</label>
                                                    <input type="text" class="form-control noradius" name="email"/> </div>
                                            </div>
                                            <div class="col-sm-3 col-lg-2 col ">
                                                <div class="form-group mb-0">
                                                    <label class="hidden-xs">&nbsp;</label>
                                                    <button type="button" onclick="notApprovedAttorneyList()" waves class="btn btn-primary text-uppercase waves-effect waves-light noradius btn-block"><i class="ti-filter"></i> Filter</button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <div class="table-responsive admintable">
                            </div>
                        </div>
                        <div role="tabpanel" class="tab-pane" id="banned-attornies">
                            <div class="filter-icon">
                                <a waves class="waves-effect waves-circle waves-ripple waves-light" data-toggle="collapse" data-target="#banned-filter" href="javascript:void(0)">
                                    <i class="ti-filter"></i>
                                </a>
                            </div>
                            <div class="clearfix"></div>
                            <div class="filter">
                                <div class="collapse" id="banned-filter">
                                    <br>
                                    <form id="banned_filter">
                                        <input type="hidden" class="form-control noradius" name="status" value="banned"/>
                                        <input type="hidden" class="form-control noradius" name="type" value="banned"/>
                                        <div class="row">
                                            <div class="col-sm-3 col-lg-2 col">
                                                <div class="form-group">
                                                    <label>Unique ID</label>
                                                    <input type="text" class="form-control noradius" name="unique_id"/> </div>
                                            </div>
                                            <div class="col-sm-3 col-lg-2 col">
                                                <div class="form-group">
                                                    <label>Full Name</label>
                                                    <input type="text" class="form-control noradius" name="name"/> </div>
                                            </div>
                                            <div class="col-sm-3 col-lg-2 col">
                                                <div class="form-group">
                                                    <label>Email</label>
                                                    <input type="text" class="form-control noradius" name="email"/> </div>
                                            </div>
                                            <div class="col-sm-3 col-lg-2 col ">
                                                <div class="form-group mb-0">
                                                    <label class="hidden-xs">&nbsp;</label>
                                                    <button type="button" onclick="bannedAttorneyList()" waves class="btn btn-primary text-uppercase waves-effect waves-light noradius btn-block"><i class="ti-filter"></i> Filter</button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            
                            
                            <div class="table-responsive admintable">
                                <div style="display: none" class="loader text-center"><i class="fa fa-spin fa-spinner fa-3x color-blue"></i></div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>

</main>
</div>
<script>
    $().ready(function () {
        
      <?php $i=0?>
     var tab = "<?php echo (Yii::$app->request->get('tab')) ? Yii::$app->request->get('tab') : ''; ?>";
     if(tab==''){
         attorneyList();
     }
     if(tab!=''){
        $("#myTab  .childtab").removeClass('active');
        $("#myTabContent .tab-pane").removeClass('show active');  
     }
     if(tab == 'unverified'){
        $("#tab_unverify").addClass('active');
        $("#not-verified-emial").addClass('show active');
        notEmailVerifiedAttorneyList(); 
     }
     if(tab == 'pending'){
        $("#tab_unapproved").addClass('active');
        $("#not-approved").addClass('show active');
        notApprovedAttorneyList(); 
     }
     if(tab == 'banned'){
        $("#tab_banned").addClass('active');
        $("#banned-attornies").addClass('show active');
        bannedAttorneyList(); 
     }
//     if(tab == 'gen'){
//        $("#gs-tab").addClass('active');
//        $("#GeneralSettings").addClass('show active');
//        generalSetting(); 
//     }
//    if(tab==''){
//            attorneyList();
//        }
    });
    
      
  
    
    var time_zone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    function attorneyList() {
        $('#not-verified-emial').removeClass('show');
        $('#not-approved').removeClass('show');
        $('#banned-attornies').removeClass('show');
//        $('#tmzn').val(time_zone);
        $('#attornies .admintable').html('<div class="loader text-center"><i class="fa fa-spin fa-spinner fa-3x color-blue"></i></div>');

        var url = url || "<?php echo \yii::$app->urlManager->createUrl(['attorney/attorney-list']) . '?timezone=' ?>" + time_zone;
        $.ajax({
            type: "GET",
            url: url,
            data: $('#attorney_filter').serialize(),
            success: function (data) {
                $("#banned-attornies").hide();
                $("#not-approved").hide();
                $("#not-verified-emial").hide();
                $("#attornies").show();
                $(".dwnld-csv").show()
                $("#attornies .admintable").html(data);
            }
        });
    }
    function notApprovedAttorneyList() {
        $('#not-verified-emial').removeClass('show');
        $('#attornies').removeClass('show');
        $('#banned-attornies').removeClass('show');
        $('#not-approved .admintable').html('<div class="loader text-center"><i class="fa fa-spin fa-spinner fa-3x color-blue"></i></div>');

        var url = url || "<?php echo \yii::$app->urlManager->createUrl(['attorney/not-approved-attorney-list']) . '?timezone=' ?>" + time_zone;
        $.ajax({
            type: "GET",
            url: url,
            data: $('#not-approved_filter').serialize(),
            success: function (data) {
                $("#banned-attornies").hide();
                $("#attornies").hide();
                $("#not-verified-emial").hide();
                $("#not-approved").show();
                $("#not-approved .admintable").html(data);
            }
        });
    }
    function notEmailVerifiedAttorneyList() {
        $('#not-approved').removeClass('show');
        $('#attornies').removeClass('show');
        $('#banned-attornies').removeClass('show');
       $('#not-verified-emial .admintable').html('<div class="loader text-center"><i class="fa fa-spin fa-spinner fa-3x color-blue"></i></div>');

        var url = url || "<?php echo \yii::$app->urlManager->createUrl(['attorney/not-email-verified-attorney-list']) . '?timezone=' ?>" + time_zone;
        $.ajax({
            type: "GET",
            url: url,
            data: $('#not-verified').serialize(),
            success: function (data) {
                $("#banned-attornies").hide();
                $("#not-approved").hide();
                $("#attornies").hide();
                $("#not-verified-emial").show();
                $("#not-verified-emial .admintable").html(data);
            }
        });
    }

    function bannedAttorneyList() {
        $('#not-approved').removeClass('show');
        $('#attornies').removeClass('show');
        $('#not-verified-emial').removeClass('show');
        $('#banned-attornies .admintable').html('<div class="loader text-center"><i class="fa fa-spin fa-spinner fa-3x color-blue"></i></div>');
        var url = url || "<?php echo \yii::$app->urlManager->createUrl(['attorney/banned-attorney-list']) . '?timezone=' ?>" + time_zone;
        $.ajax({
            type: "GET",
            url: url,
            data: $('#banned_filter').serialize(),
            success: function (data) {
                $("#attornies").hide();
                $("#not-approved").hide();
                $("#not-verified-emial").hide();
                $("#banned-attornies").show();
                $("#banned-attornies .admintable").html(data);
            }
        });
    }

    function activeInacive(value, id)
    {

        window.setTimeout(function () {
            $(".alert").fadeTo(500, 0).slideUp(500, function () {
                $(this).remove();
            });
        }, 4000);
        var url = url || "<?php echo \yii::$app->urlManager->createUrl(['attorney/active-inactive-attorny']) ?>";
        if (value == "active") {
            $('#attornies .admintable').html('<div class="loader text-center"><i class="fa fa-spin fa-spinner fa-3x color-blue"></i></div>');
            $("#loader_" + id).css('display', 'inline-block');
            $.ajax({
                type: "POST",
                url: url,
                data: {status: value, id: id},
                success: function (data) {
                    console.log(data);
                    if (data=='active') {
                                 toastr.remove();
                                 toastr.options.closeButton = true;
                                 toastr.success("Account has been activated", 'Success', {
                                   timeOut: 3000
                                });
                                window.location.href  = "<?php echo \yii::$app->urlManager->createUrl(['attorney']) ?>";
//                                attorneyList();
                    }
                }
            });
        } else {
            bootbox.confirm({
                message: "Are You sure to decline this attorney?",
                buttons: {
                    confirm: {
                        label: 'Yes',
                        className: 'btn-success'
                    },
                    cancel: {
                        label: 'No',
                        className: 'btn-danger'
                    }
                },
                callback: function (result) {

                    if (result) {
                        $('#attornies .admintable').html('<div class="loader text-center"><i class="fa fa-spin fa-spinner fa-3x color-blue"></i></div>');
                        $.ajax({
                            type: "POST",
                            url: url,
                            data: {status: value, id: id},
                            success: function (data) {
                                console.log(data);
                                if (data=='inactive') {
                                    toastr.remove();
                                    toastr.options.closeButton = true;
                                    toastr.success("Account has been inactivated", 'Success', {
                                   timeOut: 3000
                                });
                                attorneyList();
                                }
                            }
                        });
                    } else {
                        //alert('test');
                        $("#enable_" + id).attr("checked", 'checked');
                        $("#enable_" + id).prop("checked", true);
                    }
                }
            });
        }

    }
</script>
<script type="text/javascript">
    function deleteConfirm(id)
    {

        bootbox.confirm({
            message: "Are you sure to delete attorney?",
            buttons: {
                confirm: {
                    label: 'Yes',
                    className: 'btn-success'
                },
                cancel: {
                    label: 'No',
                    className: 'btn-danger'
                }
            },
            callback: function (result) {
                if (result) {
                    var url = url || "<?php echo \yii::$app->urlManager->createUrl(['attorney/delete']) ?>?id=" + id;
                    $.ajax({
                        type: "POST",
                        url: url,
                        success: function (data) {
                            if (data) {
                                 toastr.remove();
                                 toastr.options.closeButton = true;
                                 toastr.success("Attorney has been deleted", 'Success', {
                                   timeOut: 3000
                                });
                              $("#row_"+id).remove();
                            }
                        }
                    });
                }
            }
        });
    }
    function PermintPlaceCase(id)
    {
                var message;
                if($("#per_" + id).is(':checked')){
                    message =  "Are you sure you want to activate 'Place a Case' feature for this user?"; 
                }else{
                    message =  "Are you sure you want to deactivate 'Place a Case' feature for this user?";
                    
                }
        
            bootbox.confirm({
            message: message,
            buttons: {
                confirm: {
                    label: 'Yes',
                    className: 'btn-success'
                },
                cancel: {
                    label: 'No',
                    className: 'btn-danger'
                }
            },
            callback: function (result) {
                if (result) {
                   var url = url || "<?php echo \yii::$app->urlManager->createUrl(['attorney/permint-case-palce']) ?>?id=" + id;
                    $.ajax({
                        type: "POST",
                        url: url,
                        success: function (data) {
                            if (data=='true') {
                               toastr.remove();
                               toastr.options.closeButton = true;
                               toastr.success("Status has been changed", 'Success', {
                                  timeOut: 3000
                               });
                            }
                        }
                    });
             window.setTimeout(function () {
                    $(".alert").fadeTo(500, 0).slideUp(500, function () {
                        $(this).remove();
                    });
                }, 4000);
                var check_status=1;
                 $.each($("input[name='can_place[]']"), function(){
                    if(!$(this).is(':checked')){
                        check_status = 0;
                    }
                 });
                 if(check_status==1){
                  $("#paermint").prop("checked", true);   
                 }else{
                    $("#paermint").prop("checked", false);  
                 }
                }else{
                    if($("#per_" + id).is(':checked')){
                        $("#per_" + id).prop("checked", false);
                    }else{
                       $("#per_" + id).prop("checked", true);  
                    }
                  
                }
            }
        });

    }
    
    function approve(value,id)
    {
         bootbox.confirm({
            message: "Are you sure  to approve this attorney ?",
            buttons: {
                confirm: {
                    label: 'Yes',
                    className: 'btn-success'
                },
                cancel: {
                    label: 'No',
                    className: 'btn-danger'
                }
            },
            callback: function (result) {
                if (result) {
                    $('.loader').show();
                    var url = url || "<?php echo \yii::$app->urlManager->createUrl(['attorney/approve']) ?>?id=" + id;
                    $.ajax({
                    type: "POST",
                    url: url,
                    success: function (data) {
                        console.log(data);
                        if (data) {
                           toastr.remove();
                           toastr.options.closeButton = true;
                   toastr.success('Attorney has been approved', 'Success', {
                      timeOut: 3000
                   });
                   $(".loader").hide();
                   $("#row_"+id).remove();
                }
              }
             });
             window.setTimeout(function () {
                    $(".alert").fadeTo(500, 0).slideUp(500, function () {
                        $(this).remove();
                    });
                }, 4000);
                }else{
                        $("#apr_" + id).attr("checked", 'checked');
                        $("#apr_" + id).prop("checked", true);
                }
            }
        });
        
        
        

    }
    

</script>