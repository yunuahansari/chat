<?php $this->title = "Attorney Detail"; 
//echo "<pre>";
//print_r($bank_detail);die;
?>
<div id="content">                   
    <main class="main-content common-grid-page view-page">
        <div class="container-fluid">
            <div class="page-title" id="pageTitle">
                <h4>View Attorney</h4>
            </div>
            <div class="panel panel-primary filter-panel" id="panel-height">
                <div class="panel-heading clearfix filter-heading">
                    <h4 class="panel-title"><i class="ti-eye" aria-hidden="true"></i> View Attorney</h4>
                    <a href="<?php echo Yii::$app->urlManager->createAbsoluteUrl('/attorney') ?>" class="back-btn"><i class="ti-hand-point-left" aria-hidden="true"></i> Back</a>
                    <div class="clearfix"></div>
                </div>
                <div class="panel-body">

                    <div class="form-horizontal">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="control-label col-sm-4">Unique ID   <span>:</span></label>
                                    <div class="col-sm-8">
                                        <p class="form-control-static"><?php echo $user['id'] ?></p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="control-label col-sm-4">BAR Number  <span>:</span></label>
                                    <div class="col-sm-8">
                                        <p class="form-control-static"><?php echo $user['bar_number'] ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="control-label col-sm-4">SSN Number  <span>:</span></label>
                                    <div class="col-sm-8">
                                        <p class="form-control-static"><?php echo $user['ssn_number'] ?></p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="control-label col-sm-4">Full Name  <span>:</span></label>
                                    <div class="col-sm-8">
                                        <p class="form-control-static"><?php echo ucwords($user['first_name'] . ' ' . $user['last_name']) ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="control-label col-sm-4">Email Address <span>:</span></label>
                                    <div class="col-sm-8">
                                        <p class="form-control-static">
                                            <?php echo $user['email'] ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="control-label col-sm-4">Phone Number <span>:</span></label>
                                    <div class="col-sm-8">
                                        <p class="form-control-static">
                                            <?php echo $user['mobile'] ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="control-label col-sm-4">Address <span>:</span></label>
                                    <div class="col-sm-8">
                                        <p class="form-control-static">
                                            <?php echo $user['address'] ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="control-label col-sm-4">City  <span>:</span></label>
                                    <div class="col-sm-8">
                                        <p class="form-control-static">
                                            <?php echo $user['city'] ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="control-label col-sm-4">Zip Code  <span>:</span></label>
                                    <div class="col-sm-8">
                                        <p class="form-control-static">
                                            <?php echo $user['zip_code'] ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                             <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="control-label col-sm-4">Commission Percentage   <span>:</span></label>
                                    <div class="col-sm-8">
                                        <p class="form-control-static">
                                            <?php echo $user['commition'] ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="control-label col-sm-4">DOB  <span>:</span></label>
                                    <div class="col-sm-8">
                                        <p class="form-control-static">
                                            <?php echo date("F  d ,Y",  strtotime($user['dob'])); ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                     </div>
                    <hr>
                    <h3 class="view_heading">Bank Details</h3>
                    <div class="form-horizontal">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="control-label col-sm-4">Routing Number<span>:</span></label>
                                    <div class="col-sm-8">
                                        <p class="form-control-static"><?php echo $bank_detail['ach_bank_aba_number']?></p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="control-label col-sm-4">Bank Name<span>:</span></label>
                                    <div class="col-sm-8">
                                        <p class="form-control-static"><?php echo $bank_detail['bank_name']  ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="control-label col-sm-4">Account Number <span>:</span></label>
                                    <div class="col-sm-8">
                                        <p class="form-control-static"><?php echo $bank_detail['account_number']?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                       
                        
                      
                     </div>
                    <div id="rating-review-list" class="admintable table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Pal Attorney</th>
                                    <th>Rating</th>
                                    <th>Review</th>
                                    <th>Date & Time</th>  
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                    
                    
                </div>    
                
                
            </div>
        </div>
    </main>
</div>
<script type="text/javascript">
    var timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    function getReviewRating()
    {
        var url = url || "<?php echo \yii::$app->urlManager->createUrl(['attorney/rating-reviews']) ?>";
        $.ajax({
            type: "GET",
            url: url,
            data:{provider_id:<?php echo $user['id']?>,timezone:timezone},
            success: function (data) {
                $("#rating-review-list .table tbody").html(data);
                }
            });
    }
    
    $().ready(function () {
        getReviewRating();
    });

</script>