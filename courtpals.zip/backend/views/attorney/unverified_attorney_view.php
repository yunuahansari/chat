<?php $this->title = "Attorney Detail"; 
//echo "<pre>";
//print_r($bank_detail);die;
?>
<div id="content">                   
    <main class="main-content common-grid-page view-page">
        <div class="container-fluid">
            <div class="page-title" id="pageTitle">
                <h4>View Attorney</h4>
            </div>
            <div class="panel panel-primary filter-panel" id="panel-height">
                <div class="panel-heading clearfix filter-heading">
                    <h4 class="panel-title"><i class="ti-eye" aria-hidden="true"></i> View Attorney</h4>
                    <a href="<?php echo Yii::$app->urlManager->createAbsoluteUrl(['/attorney','tab'=> $tab]) ?>" class="back-btn"><i class="ti-hand-point-left" aria-hidden="true"></i> Back</a>
                    <div class="clearfix"></div>
                </div>
                <div class="panel-body">

                    <div class="form-horizontal">
                       
                        <div class="row">
                             <div class="col-sm-12">
                                <div class="form-group">
                                    <label class="control-label col-sm-4">Unique ID   <span>:</span></label>
                                    <div class="col-sm-8">
                                        <p class="form-control-static"><?php echo $user['id'] ?></p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label class="control-label col-sm-4">Full Name  <span>:</span></label>
                                    <div class="col-sm-8">
                                        <p class="form-control-static"><?php echo ucwords($user['first_name'] . ' ' . $user['last_name']) ?></p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label class="control-label col-sm-4">Email Address <span>:</span></label>
                                    <div class="col-sm-8">
                                        <p class="form-control-static">
                                            <?php echo $user['email'] ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                          
                            
                        </div>
                      
                      
                     </div>
                    <hr>
                    
                </div>    
                
                
            </div>
        </div>
    </main>
</div>
<script type="text/javascript">
    var timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    function getReviewRating()
    {
        var url = url || "<?php echo \yii::$app->urlManager->createUrl(['attorney/rating-reviews']) ?>";
        $.ajax({
            type: "GET",
            url: url,
            data:{provider_id:<?php echo $user['id']?>,timezone:timezone},
            success: function (data) {
                $("#rating-review-list .table tbody").html(data);
                }
            });
    }
    
    $().ready(function () {
        getReviewRating();
    });

</script>