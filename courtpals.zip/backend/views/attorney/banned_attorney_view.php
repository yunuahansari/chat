<?php 
$this->title = "Attorney";
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use common\models\Settings;
?>
<div id="content">                   
            <main class="main-content commonform-page">
                <div class="container-fluid">
                    <div class="page-title" id="pageTitle">
                        <h4><?php echo ($user->isNewRecord) ? 'Create' : 'Update'; ?> Attorney</h4>
                    </div>
                    <div class="panel panel-primary filter-panel" id="panel-height">
                        <div class="panel-heading clearfix filter-heading">
                            <h4 class="panel-title"><i class="ti-plus" aria-hidden="true"></i> &nbsp; <?php echo ($user->isNewRecord) ? 'Create' : 'Update'; ?> Attorney</h4>
                            <a href="<?php echo yii::$app->urlManager->createAbsoluteUrl(['/attorney','tab'=>$tab]) ?>" class="back-btn"><i class="ti-hand-point-left" aria-hidden="true"></i> Back</a>
                            <div class="clearfix"></div>
                        </div>
                        <div class="panel-body">
                            <div class="">
                                <?php if (Yii::$app->session->hasFlash('updateAttorney')): ?> 
                                    <div class="alert alert-success alert-dismissable">
                                        <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                                        <h4><i class="icon fa fa-check"></i>Updated!</h4>
                                        <?= Yii::$app->session->getFlash('updateAttorney') ?>
                                    </div>
                                <?php endif; ?>
                                <?php $form = ActiveForm::begin([]); ?>                                  
                                    <div class="row">
                                        <div class="col-sm-6 col-md-4">
                                            <div class="form-group">
                                                <label>First Name </label>
                                                  <?= $form->field($user, 'first_name')->textInput(['class' => 'form-control input-lg','placeholder'=>'First name'])->label(false); ?>
                                            </div>                                            
                                        </div>
                                        <div class="col-sm-6 col-md-4">
                                            <div class="form-group">
                                                <label>Last Name </label>
                                                   <?= $form->field($user, 'last_name')->textInput(['class' => 'form-control input-lg','placeholder'=>'Last name'])->label(false); ?>
                                            </div>                                            
                                        </div>
                                        <div class="col-sm-6 col-md-4">
                                            <div class="form-group">
                                                <label>BAR Number</label>
                                                <?= $form->field($user, 'bar_number')->textInput(['class' => 'form-control input-lg','placeholder'=>'BAR Number'])->label(false); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-6 col-md-4">
                                            <div class="form-group">
                                                <label>SSN Number</label>
                                               <?= $form->field($user, 'ssn_number')->textInput(['class' => 'form-control input-lg','placeholder'=>'SSN Number'])->label(false); ?>
                                            </div>
                                        </div>
                                        

                                        <div class="col-sm-6 col-md-4">
                                            <div class="form-group">
                                                <label>Email Address</label>
                                               <?= $form->field($user, 'email')->textInput(['class' => 'form-control input-lg','placeholder'=>'Email Address'])->label(false); ?>
                                            </div>                                            
                                        </div>

                                        <div class="col-sm-6 col-md-4">
                                            <div class="form-group">
                                                <label>Phone Number</label>
                                              <?= $form->field($user, 'mobile')->textInput(['class' => 'form-control input-lg','placeholder'=>'Phone Number'])->label(false); ?>
                                            </div>                                            
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-6 col-md-4">
                                            <div class="form-group">
                                                <label>Address</label>
                                                <?= $form->field($user, 'address')->textInput(['class' => 'form-control input-lg','placeholder'=>'Address'])->label(false); ?>
                                            </div>                                            
                                        </div>

                                        <div class="col-sm-6 col-md-4">
                                            <div class="form-group">
                                                <label>City </label>
                                               <?= $form->field($user, 'city')->textInput(['class' => 'form-control input-lg','placeholder'=>'City'])->label(false);  ?>
                                            </div>                                            
                                        </div>

                                        <div class="col-sm-6 col-md-4">
                                            <div class="form-group">
                                                <label>Zip Code</label>
                                                <?= $form->field($user, 'zip_code')->textInput(['class' => 'form-control input-lg','placeholder'=>'Zip Code'])->label(false); ?>
                                            </div>                                            
                                        </div>
                                        </div>
                                <div class="row">
                                        <div class="col-sm-6 col-md-4">
                                            <div class="form-group">
                                                <label>DOB</label>
                                                <?= $form->field($user, 'dob')->textInput(['value' => date('M d,Y'),'class' => 'form-control input-lg datepicker','placeholder'=>'Date of birth','readonly' => true])->label(false); ?>
                                            </div>                                            
                                        </div>
                                        <div class="col-sm-6 col-md-4">
                                            <div class="form-group">
                                                <label>Commission</label>
                                                <?php if($user->isNewRecord){ ?>
                                                <?= $form->field($user, 'commition')->textInput(['class' => 'form-control input-lg','value'=> Settings::getCommissionFromSettings(),'placeholder'=>'Commission'])->label(false); ?>
                                                <?php }else{ ?>
                                                <?= $form->field($user, 'commition')->textInput(['class' => 'form-control input-lg','placeholder'=>'Commission'])->label(false); ?>
                                                 <?php }?>
                                            </div>                                            
                                        </div>
                                    <?php if($user->isNewRecord){ ?>
                                        <div class="col-sm-6 col-md-4">
                                            <div class="form-group">
                                                <label>Password</label>
                                                <?= $form->field($user, 'password')->passwordInput(['class' => 'form-control input-lg','placeholder'=>'Password'])->label(false); ?>
                                            </div>                                            
                                        </div>
                                    <?php } ?>
                                </div>
                                <button id="create_attorney"type="submit" class="btn btn-primary btn-lg noradius waves-effect waves-button waves-light text-uppercase"><?php echo ($user->isNewRecord) ? 'Create' : 'Update'; ?><i id="loader" style="display: none" class="fa fa-spin fa-spinner color-pink"></i></button>
                               <?php ActiveForm::end(); ?>  
                            </div>
                        </div>                        
                    </div>
                </div>
            </main>
        </div>
<script type="text/javascript">
$("#user-mobile").mask("9999999999");

window.addEventListener('beforeunload', function(event) {
        $("#create_attorney").attr("disabled", true);
        $("#loader").show();
 });
</script>
