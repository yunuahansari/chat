

<script type="text/javascript">
$().ready(function(){
   getList();  
   $("#alert-message").hide();
});
function getList(url)
{
    var post = $("#frm-Search").serialize();
    var url = url || "<?php echo \yii::$app->urlManager->createUrl(['student/list'])?>";
    $.ajax({
            type :"POST",
            url  :url,
            data : post,
            success:function(data){
                $(".overlay").hide();    
                $("#container-list").html(data);
            }
    });
}
</script>
<div class="container-fluid ">
    <div class="production-inner">
        <div class="row">
            <div class="col-lg-12 col-sm-12 col-xs-12">
                <div class="tab-content">
                    <div role="tabpanel" class="tab-pane active" id="unassiagn">
                        <div id="alert-message" class="alert alert-danger"></div>
                        <div class="panel-heading fliter_dropdown">
                            <div class="row">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 right">
                                    <ul class="list-inline pull-right">
                                        <li class="search-li">
                                            <form class="search-form" id="frm-Search">
                                                <div class="form-group">
                                                    <label class="sr-only" for="search">Search</label>
                                                    <input type="text" placeholder="search" id="search" name="txtSearch" class="form-control">
                                                    <button class="form-control-feedback" type="submit"><span class="glyphicon glyphicon-search"></span></button>
                                                </div>
                                            </form>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        
                        <div id="container-list" class="table-responsive">

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>