
   <?php use yii\widgets\ActiveForm;
        use yii\helpers\Html;
   ?>

            
            <main class="main-content commonform-page">
                <div class="container-fluid">
                    <div class="page-title" id="pageTitle">
                        <h4>Change password</h4>
                    </div>
                    <div class="panel panel-primary filter-panel" id="panel-height">
                        
                        <div class="panel-body">
                            <div class="change-password">  
                                
                                <?php if (Yii::$app->session->hasFlash('success')): ?>
                                <div class="alert alert-success alert-dismissable">
                                    <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                                    <h4><i class="icon fa fa-check"></i>Saved!</h4>
                                <?= Yii::$app->session->getFlash('success') ?>
                                    
                                </div>
                                
                            <?php endif; ?>
                                <?php $form = ActiveForm::begin(
                                ); ?>                                   
                                    <div class="row">
                                        <div class="col-sm-6 col-md-4">
                                            <div class="form-group">
                                                <?= $form->field($changePassword, 'password')->passwordInput(['class' => 'form-control input-lg ','placeholder'=>'Password']); ?>
                                            </div>
                                        </div>
                                        <div class="col-sm-6 col-md-4">
                                            <div class="form-group">
                                                  <?= $form->field($changePassword, 'new_password')->passwordInput(['class' => 'form-control input-lg ','placeholder'=>'New password']); ?>
                                            </div>
                                        </div>
                                        <div class="col-sm-6 col-md-4">
                                            <div class="form-group">
                                                <?= $form->field($changePassword, 'confirm_password')->passwordInput(['class' => 'form-control input-lg ','placeholder'=>'Confirm password']); ?>
                                            </div>                                            
                                        </div>
                                    </div>
                                  <?= Html::submitButton('Save', ['id'=>'change-form-loader','class' => "btn btn-primary btn-lg noradius waves-effect waves-button waves-light text-uppercase"]); ?>
                                   <?php ActiveForm::end(); ?> 
                            </div>
                           
                            
                        </div>                        
                    </div>
                </div>
            </main>
       

<script>
 window.setTimeout(function() {
    $(".alert").fadeTo(500, 0).slideUp(500, function(){
        $(this).remove(); 
    });
}, 4000);

  
    window.addEventListener('beforeunload', function(event) {
        $("#change-form-loader").attr("disabled", true);
        $("#change-form-loader").html('Save <i class="fa fa-spinner fa-spin"></i>');
     });
  

</script>
      

            
   

