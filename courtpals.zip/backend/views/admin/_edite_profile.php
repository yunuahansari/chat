<?php

use yii\widgets\ActiveForm;
use yii\bootstrap\Html;
?>

<?php $form = ActiveForm::begin(['enableAjaxValidation' => true, 'enableClientValidation' => false,'class' => "form-horizontal", 'action' => Yii::$app->urlManager->createAbsoluteUrl(['/user/update-profile']), 'options' => ['id' => 'edite-profile','enctype' => 'multipart/form-data']])
?>

<div class=" col-sm-12 col-xs-10 col-sm-offset-0 col-xs-offset-1 edit-form">
    <div class="form-group">
        <div class="col-lg-5 col-md-3 col-sm-6 col-xs-12"> <img src="<?php echo \common\components\Utility::getUserImage('profile', Yii::$app->user->getId()); ?>" /> </div>
        <div class="col-lg-7 col-md-7 col-sm-6 col-xs-12">
<?= $form->field($model, 'profile_pic')->fileInput([ 'class' => 'form-control date '])->label('upload pic'); ?>
        </div>
    </div>
    <div class="form-group">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
<?= $form->field($model, 'first_name')->textInput(['placeholder' => "Enter First name", 'class' => 'form-control date ']); ?>
        </div>
    </div>
    <div class="form-group">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
<?= $form->field($model, 'last_name')->textInput(['placeholder' => "Enter Last name", 'class' => 'form-control date ']); ?>
        </div>
    </div>
    <div class="form-group">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
<?= $form->field($model, 'email')->textInput(['placeholder' => "Enter email", 'class' => 'form-control date ']); ?>
        </div>
    </div>
</div>
<div class="clearfix"></div>
<div class="modal-footer">
<?= Html::submitButton('Update', ['class' => "btn btn-primary"]); ?>
<?= Html::submitButton('Cancel', ['class' => "btn btn-primary", 'data-dismiss' => "modal"]); ?>
</div>
<?php ActiveForm::end(); ?>   
