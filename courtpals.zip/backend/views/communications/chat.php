

<?php
$count = 0;
foreach ($chats as $chat) {

    $array = explode('/', $chat['media']);
    $length = count($array);
    $pos = $length - 1;
    $file = $array["$pos"];
    $extention = explode('.', $file);

    if ($count == 0) {
        $fromId = $chat->sender;
        $toId = $chat->receiver;
    }
    if ($chat->receiver == $fromId) {
        ?>
        <div class="clearfix">
            <div class="msg-wrap left">
                <div> <?php echo ucwords($chat->sender0->first_name." ".$chat->sender0->last_name)?></div>
                <div class="img">
                    <img src="<?php echo common\components\Utility::getUserImage($chat->sender); ?>" class="img-responsive" />
                </div>

                <div class="msg">
                    <?php if ($chat->type == 'text') { ?>
                        <p><?php echo $chat->message ?></p>
                        <span><?php echo date("F  d ,Y h:i A", strtotime($chat->created_at)); ?></span>
                    <?php } elseif ($extention[1] == 'pdf') { ?>
                        <a href="<?php echo $chat->media; ?>" target="_blank"><img src="<?php echo Yii::getAlias('@images_url'); ?>/pdf.jpg" width="110" height="100" /></a>
                    <?php } elseif (($extention[1] == 'doc') || ($extention[1] == 'docx')) {
                        ?>
                        <a href="<?php echo $chat->media; ?>" ><img src="<?php echo Yii::getAlias('@images_url'); ?>/word.jpg" width="110" height="100" /></a>
                    <?php } else { ?>
                        <a href="<?php echo $chat->media; ?>" ><img src="<?php echo $chat->media ?>" width="250" height="250" /></a>
                    <?php } ?>
                </div>
            </div>
        </div>
    <?php } else { ?>
        <div class="clearfix">
            <div class="msg-wrap right">
                <div> <?php echo ucwords($chat->sender0->first_name." ".$chat->sender0->last_name)?></div>
                <div class="img">
                    <img src="<?php echo common\components\Utility::getUserImage($chat->sender); ?>" class="img-responsive" />
                </div>
                <div class="msg">
                    <?php if ($chat->type == 'text') { ?>
                        <p><?php echo $chat->message ?></p>
                        <span><?php echo date("F  d ,Y h:i A", strtotime($chat->created_at)); ?></span>
                    <?php } elseif ($extention[1] == 'pdf') { ?>
                        <a href="<?php echo $chat->media; ?>" target="_blank"><img src="<?php echo Yii::getAlias('@images_url'); ?>/pdf.jpg" width="110" height="100" /></a>
                    <?php } elseif (($extention[1] == 'doc') || ($extention[1] == 'docx')) {
                        ?>
                        <a href="<?php echo $chat->media; ?>" ><img src="<?php echo Yii::getAlias('@images_url'); ?>/word.jpg" width="110" height="100" /></a>
                    <?php } else { ?>
                        <a href="<?php echo $chat->media; ?>" ><img src="<?php echo $chat->media ?>" width="250" height="250" /></a>
                    <?php } ?>
                </div>
                
               
            </div>
        </div>
        <?php
    }
    $count = 1;
}
?>


