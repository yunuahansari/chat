<?php $this->title = "Communications"; ?>
<div id="content">
    <main class="main-content common-grid-page communications-page">
        <div class="container-fluid">
        	<div class="page-title" id="pageTitle">
                <h4>Communications </h4>
            </div>

            <div class="panel panel-primary" id="panel-height">
            	<div class="panel-body">
            		<div class="row">
            			<div class="left-side " >
            				<div class="col-sm-6">
	            				<div class="mCustomScrollbar" data-mcs-theme="dark">
		            				<div class="table-responsive admintable " >
		            					<table class="table">
		                                    <thead>
		                                        <tr>
		                                            <th>Case ID</th>
		                                            <th>Attorneys</th>
		                                            <th>Date/ Time</th>
		                                            <th class="text-center">Action</th>
		                                        </tr>
		                                    </thead>
		                                    
		                                    <tbody>
		                                        <tr>
		                                            <td>AP2330A</td>
		                                            <td>Mark William vs Richard D. Starr</td>
		                                            <td>6/16/15 10:15 am</td>
		                                            <td class="text-center">
		                                                <ul class="list-inline mb-0">
		                                                    <li><a href="javascript:void(0);"><i class="ti-eye"></i></a></li> 

		                                                    <li><a href="javascript:void(0);"><i class="ti-trash"></i></a></li>
		                                                </ul>
		                                            </td>                                              
		                                        </tr>                              
		                                        <tr>
		                                            <td>AP2330A</td>
		                                            <td>Mark William vs Richard D. Starr</td>
		                                            <td>6/16/15 10:15 am</td>
		                                            <td class="text-center">
		                                                <ul class="list-inline mb-0">
		                                                    <li><a href="javascript:void(0);"><i class="ti-eye"></i></a></li> 

		                                                    <li><a href="javascript:void(0);"><i class="ti-trash"></i></a></li>
		                                                </ul>
		                                            </td>                                              
		                                        </tr>

		                                        <tr class="active">
		                                            <td>AP2330A</td>
		                                            <td>Mark William vs Richard D. Starr</td>
		                                            <td>6/16/15 10:15 am</td>
		                                            <td class="text-center">
		                                                <ul class="list-inline mb-0">
		                                                    <li><a href="javascript:void(0);"><i class="ti-eye"></i></a></li> 

		                                                    <li><a href="javascript:void(0);"><i class="ti-trash"></i></a></li>
		                                                </ul>
		                                            </td>                                              
		                                        </tr>

		                                        <tr>
		                                            <td>AP2330A</td>
		                                            <td>Mark William vs Richard D. Starr</td>
		                                            <td>6/16/15 10:15 am</td>
		                                            <td class="text-center">
		                                                <ul class="list-inline mb-0">
		                                                    <li><a href="javascript:void(0);"><i class="ti-eye"></i></a></li> 

		                                                    <li><a href="javascript:void(0);"><i class="ti-trash"></i></a></li>
		                                                </ul>
		                                            </td>                                              
		                                        </tr>

		                                        <tr>
		                                            <td>AP2330A</td>
		                                            <td>Mark William vs Richard D. Starr</td>
		                                            <td>6/16/15 10:15 am</td>
		                                            <td class="text-center">
		                                                <ul class="list-inline mb-0">
		                                                    <li><a href="javascript:void(0);"><i class="ti-eye"></i></a></li> 

		                                                    <li><a href="javascript:void(0);"><i class="ti-trash"></i></a></li>
		                                                </ul>
		                                            </td>                                              
		                                        </tr>

		                                        <tr>
		                                            <td>AP2330A</td>
		                                            <td>Mark William vs Richard D. Starr</td>
		                                            <td>6/16/15 10:15 am</td>
		                                            <td class="text-center">
		                                                <ul class="list-inline mb-0">
		                                                    <li><a href="javascript:void(0);"><i class="ti-eye"></i></a></li> 

		                                                    <li><a href="javascript:void(0);"><i class="ti-trash"></i></a></li>
		                                                </ul>
		                                            </td>                                              
		                                        </tr>

		                                        <tr>
		                                            <td>AP2330A</td>
		                                            <td>Mark William vs Richard D. Starr</td>
		                                            <td>6/16/15 10:15 am</td>
		                                            <td class="text-center">
		                                                <ul class="list-inline mb-0">
		                                                    <li><a href="javascript:void(0);"><i class="ti-eye"></i></a></li> 

		                                                    <li><a href="javascript:void(0);"><i class="ti-trash"></i></a></li>
		                                                </ul>
		                                            </td>                                              
		                                        </tr>

		                                       <tr>
		                                            <td>AP2330A</td>
		                                            <td>Mark William vs Richard D. Starr</td>
		                                            <td>6/16/15 10:15 am</td>
		                                            <td class="text-center">
		                                                <ul class="list-inline mb-0">
		                                                    <li><a href="javascript:void(0);"><i class="ti-eye"></i></a></li> 

		                                                    <li><a href="javascript:void(0);"><i class="ti-trash"></i></a></li>
		                                                </ul>
		                                            </td>                                              
		                                        </tr>

		                                        <tr>
		                                            <td>AP2330A</td>
		                                            <td>Markx William vs Richard D. Starr</td>
		                                            <td>6/16/15 10:15 am</td>
		                                            <td class="text-center">
		                                                <ul class="list-inline mb-0">
		                                                    <li><a href="javascript:void(0);"><i class="ti-eye"></i></a></li> 

		                                                    <li><a href="javascript:void(0);"><i class="ti-trash"></i></a></li>
		                                                </ul>
		                                            </td>                                              
		                                        </tr>

		                                        <tr>
		                                            <td>AP2330A</td>
		                                            <td>Marka William vs Richard D. Starr</td>
		                                            <td>6/16/15 10:15 am</td>
		                                            <td class="text-center">
		                                                <ul class="list-inline mb-0">
		                                                    <li><a href="javascript:void(0);"><i class="ti-eye"></i></a></li> 

		                                                    <li><a href="javascript:void(0);"><i class="ti-trash"></i></a></li>
		                                                </ul>
		                                            </td>                                              
		                                        </tr>

		                                        <tr>
		                                            <td>AP2330A</td>
		                                            <td>Marky William vs Richard D. Starr</td>
		                                            <td>6/16/15 10:15 am</td>
		                                            <td class="text-center">
		                                                <ul class="list-inline mb-0">
		                                                    <li><a href="javascript:void(0);"><i class="ti-eye"></i></a></li> 

		                                                    <li><a href="javascript:void(0);"><i class="ti-trash"></i></a></li>
		                                                </ul>
		                                            </td>                                              
		                                        </tr>

		                                        <tr>
		                                            <td>AP2330A</td>
		                                            <td>Mark William vs Richard D. Starr</td>
		                                            <td>6/16/15 10:15 am</td>
		                                            <td class="text-center">
		                                                <ul class="list-inline mb-0">
		                                                    <li><a href="javascript:void(0);"><i class="ti-eye"></i></a></li> 

		                                                    <li><a href="javascript:void(0);"><i class="ti-trash"></i></a></li>
		                                                </ul>
		                                            </td>                                              
		                                        </tr>

		                                        <tr>
		                                            <td>AP2330A</td>
		                                            <td>Markx William vs Richard D. Starr</td>
		                                            <td>6/16/15 10:15 am</td>
		                                            <td class="text-center">
		                                                <ul class="list-inline mb-0">
		                                                    <li><a href="javascript:void(0);"><i class="ti-eye"></i></a></li> 

		                                                    <li><a href="javascript:void(0);"><i class="ti-trash"></i></a></li>
		                                                </ul>
		                                            </td>                                              
		                                        </tr>

		                                        <tr>
		                                            <td>AP2330A</td>
		                                            <td>Marka William vs Richard D. Starr</td>
		                                            <td>6/16/15 10:15 am</td>
		                                            <td class="text-center">
		                                                <ul class="list-inline mb-0">
		                                                    <li><a href="javascript:void(0);"><i class="ti-eye"></i></a></li> 

		                                                    <li><a href="javascript:void(0);"><i class="ti-trash"></i></a></li>
		                                                </ul>
		                                            </td>                                              
		                                        </tr>

		                                        <tr>
		                                            <td>AP2330A</td>
		                                            <td>Marky William vs Richard D. Starr</td>
		                                            <td>6/16/15 10:15 am</td>
		                                            <td class="text-center">
		                                                <ul class="list-inline mb-0">
		                                                    <li><a href="javascript:void(0);"><i class="ti-eye"></i></a></li> 

		                                                    <li><a href="javascript:void(0);"><i class="ti-trash"></i></a></li>
		                                                </ul>
		                                            </td>                                              
		                                        </tr>

		                                                                    
		                                    </tbody>
		                                </table>
		            				</div>
	            				</div>
	            			</div>
            			</div>

            			<!-- xxxxxx -->

            			<div class="right-side">
            				<div class="col-sm-6">
            					<div class="chat-header">
            						<h3><span>Oscar M. Dan</span> vs <span>Andrew M. Edens</span></h3>
            					</div>

            					<div class="mCustomScrollbar" data-mcs-theme="dark">
            					<div class="chat-body">
            						<div class="clearfix">
	            						<div class="msg-wrap left">
	            							<div class="img">
	            								<img src="<?php echo Yii::getAlias('@images_url'); ?>/user.jpg" class="img-responsive" />
	            							</div>

	            							<div class="msg">
	            								<p>Hi How are you...?</p>
	            								<span>03:19 PM - 09/08/2015</span>
	            							</div>
										</div>
									</div>

									<!-- xxxxxx -->

									<div class="clearfix">
										<div class="msg-wrap right">
	            							<div class="msg">
	            								<p>Hi How are you...?</p>
	            								<span>03:19 PM - 09/08/2015</span>
	            							</div>

	            							<div class="img">
	            								<img src="<?php echo Yii::getAlias('@images_url'); ?>/user02.jpg" class="img-responsive" />
	            							</div>
										</div>
									</div>

									<!-- xxxxxxx -->

									<div class="clearfix">
										<div class="msg-wrap left">
	            							<div class="img">
	            								<img src="<?php echo Yii::getAlias('@images_url'); ?>/user.jpg" class="img-responsive" />
	            							</div>

	            							<div class="msg">
	            								<p>I need your  help with some documents.</p>
	            								<span>03:19 PM - 09/08/2015</span>
	            							</div>
										</div>
									</div>

									<!-- xxxxxx -->

									<div class="clearfix">
										<div class="msg-wrap right">
	            							<div class="msg">
	            								<p>Hi How are you...?</p>
	            								<span>03:19 PM - 09/08/2015</span>
	            							</div>

	            							<div class="img">
	            								<img src="<?php echo Yii::getAlias('@images_url'); ?>/user02.jpg" class="img-responsive" />
	            							</div>
										</div>
									</div>

									<!-- xxxxxxx -->

									<div class="clearfix">
										<div class="msg-wrap left">
	            							<div class="img">
	            								<img src="<?php echo Yii::getAlias('@images_url'); ?>/user.jpg" class="img-responsive" />
	            							</div>

	            							<div class="msg">
	            								<p>Hi How are you...?</p>
	            								<span>03:19 PM - 09/08/2015</span>
	            							</div>
										</div>
									</div>

									<!-- xxxxxx -->

									<div class="clearfix">
										<div class="msg-wrap right">
	            							<div class="msg">
	            								<p>Hi How are you...?</p>
	            								<span>03:19 PM - 09/08/2015</span>
	            							</div>

	            							<div class="img">
	            								<img src="<?php echo Yii::getAlias('@images_url'); ?>/user02.jpg" class="img-responsive" />
	            							</div>
										</div>
									</div>

									

									<!-- xxxxxxx -->

									<div class="clearfix">
										<div class="msg-wrap left">
	            							<div class="img">
	            								<img src="<?php echo Yii::getAlias('@images_url'); ?>/user.jpg" class="img-responsive" />
	            							</div>

	            							<div class="msg">
	            								<p>Hi How are you...?</p>
	            								<span>03:19 PM - 09/08/2015</span>
	            							</div>
										</div>
									</div>

									<!-- xxxxxx -->

									<div class="clearfix">
										<div class="msg-wrap right">
	            							<div class="msg">
	            								<p>Hi How are you...?</p>
	            								<span>03:19 PM - 09/08/2015</span>
	            							</div>

	            							<div class="img">
	            								<img src="<?php echo Yii::getAlias('@images_url'); ?>/user02.jpg" class="img-responsive" />
	            							</div>
										</div>
									</div>


            					</div>
            					</div>
            				</div>
            			</div>
            		</div>
            	</div>
            </div>
        </div>
    </main>
</div>