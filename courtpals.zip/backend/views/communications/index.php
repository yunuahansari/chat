<?php
$this->title = "Communications";
$defaultCase = 0;
?>
<div id="content">
    <main class="main-content common-grid-page communications-page">
        <div class="container-fluid">
            <div class="page-title" id="pageTitle">
                <h4>Communications </h4>
            </div>

            <div class="panel panel-primary" id="panel-height">
                <div class="panel-body">
                    <div class="row">
                        <div class="left-side">
                            <div class="col-sm-6">
                                <div class="form-group search">
                                    <div class="search-wrap">
                                        <form>
                                            <input type="text" id="searchvalue" class="form-control" name="searchvalue" placeholder="Search By CaseId....">
                                            <button type="button" onclick ="inboxList()"><span class="ti-search"></span></button>
                                        </form>
                                    </div>
                                </div>
                                <div class="mCustomScrollbar" data-mcs-theme="dark">
                                    <div class="table-responsive admintable" id="inbox">
                                        
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- xxxxxx -->

                        <div class="right-side">
                            <div class="col-sm-6">
                                <div class="chat-header">
                                    <h3><span id="nameofchatters"></span><br/>
                                   <span id="caseId"></span></h3>
                                </div>
                                <div id="chat-msgs" class="mCustomScrollbar" data-mcs-theme="dark">
                                    <div class="chat-body" id="allchat">


                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>

<script>
    var timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    $().ready(function () {
//         alert(Intl.DateTimeFormat().resolvedOptions().timeZone);
         
         var url = url || "<?php echo \yii::$app->urlManager->createUrl(['communications/index-inbox']) ?>";
        $.ajax({
            type: "GET",
            url: url,
            data: {time_zone: timezone},
            success: function (data) {
                $("#inbox").html(data);
            }
        });
    });
    function chatList(case_id) {
        $('.table tr').removeClass('active');
        $('#chat_active_' + case_id).addClass('active');
        var url = url || "<?php echo \yii::$app->urlManager->createUrl(['communications/chat-of-attorney']) ?>";
        $.ajax({
            type: "GET",
            url: url,
            data: {case_id: case_id,time_zone:timezone},
            success: function (data) {
                var names = $('#name' + case_id).val();
                $('#nameofchatters').html(names);
                $("#allchat").html(data);
                $("#caseId").html(case_id);
                $("#chat-msgs").mCustomScrollbar("scrollTo", "bottom");
            }
        });       
    }

     function inboxList() {
        var url = url || "<?php echo \yii::$app->urlManager->createUrl(['communications/inbox-list']) ?>";
        $.ajax({
            type: "GET",
            url: url,
            data: $('#searchvalue').serialize(),
            success: function (data) {
                $(".admintable").html(data);
            }
        });
    }
 
</script>