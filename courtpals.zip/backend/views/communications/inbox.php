<?php
$this->title = "Communications";
$defaultCase = 0;
?>

<div class="table-responsive admintable" >
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <th>Case ID</th>
                                                    <th>Attorneys</th>
                                                    <th>Date/ Time</th>
                                                </tr>
                                            </thead>

                                            <tbody>

                                                <?php
                                                $i = 1;
                                                foreach ($inbox as $chat) {
                                                    if ($i == 1) {
                                                        $defaultCase = $chat->case_id;
                                                    }
                                                    ?>
                                                    <tr id="chat_active_<?php echo $chat->case_id; ?>">
                                                    <td id="abc<?php echo $chat->case_id ?>" onclick="chatList('<?php echo $chat->case_id ?>')"> <a href="#"><?php echo $chat->case_id ?></a></td>
                                                        <td ><?php echo ucwords($chat->sender0['first_name'] . ' ' . $chat->sender0['last_name'] . ' VS ' . $chat->receiver0['first_name'] . ' ' . $chat->receiver0['last_name']); ?></td>
                                                <input id="name<?php echo $chat->case_id ?>" type="hidden" value="<?php echo $chat->sender0['first_name'] . ' ' . $chat->sender0['last_name'] . ' VS ' . $chat->receiver0['first_name'] . ' ' . $chat->receiver0['last_name']; ?>">
                                                <td><?php echo date("F  d ,Y h:i A", strtotime($chat->created_at)); ?></td>
                                                                                           
                                                </tr>                              
                                                <?php
                                                $i++;
                                            }
                                            ?>                        
                                            </tbody>
                                        </table>
 </div>
<script>
        chatList('<?php echo $defaultCase; ?>');
</script>
