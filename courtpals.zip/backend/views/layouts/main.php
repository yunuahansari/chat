<?php
/* @var $this \yii\web\View */
/* @var $content string */

use backend\assets\AppAsset;
use yii\helpers\Html;
use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;
use yii\widgets\Breadcrumbs;
use common\widgets\Alert;

AppAsset::register($this);
?>
<?php $this->beginPage() ?>

<html lang="<?= Yii::$app->language ?>">
    <head>
    <meta charset="<?= Yii::$app->charset ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo Yii::getAlias('@base_url'); ?>/images/favicons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo Yii::getAlias('@base_url'); ?>/images/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo Yii::getAlias('@base_url'); ?>/images/favicons/favicon-16x16.png">
    <link rel="manifest" href="<?php echo Yii::getAlias('@base_url'); ?>/images/favicons/manifest.json">
    <link rel="mask-icon" href="<?php echo Yii::getAlias('@base_url'); ?>/images/favicons/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="theme-color" content="#ffffff">
    <?= Html::csrfMetaTags() ?>
    <title><?= Html::encode($this->title).' | '. Yii::$app->name ?></title>
    <?php $this->head() ?>
</head>
       
    
    <body  onload="hide_preloader();">
        <?php $this->beginBody() ?>

        <div class="maincontainer">
            <div class="leftbar">
                <header role="banner" class="navbar navbar-fixed-top adminmenu">
                    <nav class="navbar navbar-default navbar-fixed-top" id="top-header">
                        <div class="container-fluid">
                            <div class="navbar-header">
                                <button waves type="button" class="navbar-toggle waves-effect waves-ripple waves-light" id="navbar" onclick="fullwidth()">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                                <a class="navbar-brand" href="<?php echo yii::$app->urlManager->createAbsoluteUrl('/dashboard') ?>"><img src="<?php echo Yii::getAlias('@images_url'); ?>/white_new_logo.png" class="img-responsive center-block" /></a>
                            </div>
                            <div class="navbar-collapse">          
                                <ul class="nav navbar-nav navbar-right">           
                                    <li><a href="<?php echo yii::$app->urlManager->createAbsoluteUrl('/admin/change-password') ?>" class="waves-effect waves-block waves-classic"><i class="ti-settings"></i></a></li>
                                    <li><a href="<?php echo Yii::$app->urlManager->createAbsoluteUrl('/auth/login/logout'); ?>" class="waves-effect waves-block waves-classic"><i class="ti-power-off"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </nav>

                </header>
            </div>
            <!-- left sidebar--> 

            <?php echo $this->render('//layouts/sidebar'); ?>
            <!-- right container -->
            <div class="right-fullcontainer side-collapse-container">
                <div class="main-container p-l-0 manage_listingadd">

                    <?php echo $content ?>
                </div>
            </div>
        </div>
        <?php echo $this->render('//layouts/footer'); ?>

        <?php $this->endBody() ?>
    </body>
</html>
<?php $this->endPage() ?>
    