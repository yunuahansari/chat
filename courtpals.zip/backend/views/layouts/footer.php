<!--<footer style="text-align: center;" id="footer">
    COPYRIGHT © 2017 APEERANCE . ALL RIGHTS RESERVED.
</footer>-->
<script>
   $(document).ready(function(){
       $('#user-dob').datepicker({
           autoclose: true,
//           immediateUpdates: true,
           format:"M d,yyyy"
       }); 
   });
                        $('.selectpicker').selectpicker();
                        if (/Android|webOS|iPhone|iPad|iPod|BlackBerry/i.test(navigator.userAgent)) {
                            $('.selectpicker').selectpicker('mobile');
                        }
                        Waves.init();
                        function fullwidth() {
                            $("body").toggleClass('content-wrapper');
                            $("#nav-aside").toggleClass('slide');
                            $(document).on('touchmove', function (e) {
                                if (!$(e.target)('body.content-wrapper')[0]) {
                                    e.preventDefault();
                                }
                            });
                        }
                        ;
                        $(window).resize(function () {
                            var chk_account_height = $('#top-header').outerHeight(true) + 51;
                            var window_height = $(window).height();
                            $("#content").css('min-height', window_height - chk_account_height);
                        }).resize();
                        setTimeout(function () {
                            $(window).resize(function () {
                                var chk_height = $('#top-header').outerHeight(true) + $('#pageTitle').outerHeight(true);
                                var window_height = $(window).height();
                                $("#panel-height").css('min-height', window_height - chk_height - 20);
                            }).resize();
                        }, 100);

                        var rotate = 1;
                        function hide_preloader() {
                            rotate = 0;
                            $("#preloader").fadeOut('slow');
                        }
        </script>   