<div id="preloader">
    <div class="inner">
        <div class="image">
            <img src="<?php echo Yii::getAlias('@images_url'); ?>/white_new_logo.png" class="img-responsive" />
        </div>
        <div class="spinner">
            <div class="rect1"></div>
            <div class="rect2"></div>
            <div class="rect3"></div>
            <div class="rect4"></div>
            <div class="rect5"></div>
        </div>
    </div>
</div>
<?php $current = Yii::$app->controller->id;  
 $action = Yii::$app->controller->action->id;
?>
<aside class="nav-aside" id="nav-aside">
    <div class="nav-wrapper mCustomScrollbar"  data-mcs-theme="light">
        <ul class="list-unstyled sidebar-nav">
            <li <?php if ($current == 'dashboard' && $action == 'index') { echo 'class="active"'; } ?>>
                <a href="<?php echo yii::$app->urlManager->createAbsoluteUrl('/dashboard') ?>" class="waves-effect waves-block waves-classic"><i class="ti-dashboard icon"></i> <span>Dashboard</span></a>
            </li>
            <li <?php if ($current == 'attorney') { echo 'class="active"'; } ?>>
                <a href="<?php echo yii::$app->urlManager->createAbsoluteUrl('/attorney') ?>" class="waves-effect waves-block waves-classic"><i class="ti-user icon"></i> <span>Attorney</span></a>
            </li>
            <li <?php if ($current == 'apeerance') { echo 'class="active"'; } ?>>
                <a href="<?php echo yii::$app->urlManager->createAbsoluteUrl('/apeerance') ?>" class="waves-effect waves-block waves-classic"><i class="ti-briefcase icon"></i> <span>APPEARANCES </span></a>
            </li>
            <li <?php if ($current == 'communications') { echo 'class="active"'; } ?>>
                <a href="<?php echo yii::$app->urlManager->createAbsoluteUrl('/communications') ?>" class="waves-effect waves-block waves-classic"><i class="ti-comment icon"></i> <span>Communication </span></a>
            </li>
            <li <?php if ($current == 'payment') { echo 'class="active"'; } ?>>
                <a href="<?php echo yii::$app->urlManager->createAbsoluteUrl('/payment') ?>" class="waves-effect waves-block waves-classic"><i class="ti-money icon"></i> <span>Payment</span></a>
            </li>
            <li <?php if ($current == 'other') { echo 'class="active"'; } ?>>
                <a href="<?php echo yii::$app->urlManager->createAbsoluteUrl('/other') ?>" class="waves-effect waves-block waves-classic"><i class="ti-tag icon"></i> <span>Other</span></a>
            </li>
            <li <?php if ($current == 'dashboard' && $action == 'settings') { echo 'class="active"'; } ?>>
                <a href="<?php echo yii::$app->urlManager->createAbsoluteUrl('/dashboard/settings') ?>" class="waves-effect waves-block waves-classic"><i class="ti-settings icon"></i> <span>Commission Settings</span></a>
            </li>
           
        </ul>
    </div>
</aside> 