<?php $this->title = "Dashboard"; ?>
<div id="content">                   
            <main class="main-content dashboard-page">
                <div class="container-fluid">
                    <div class="page-title">
                        <h4>Dashboard</h4>
                    </div>
                    <section class="boxes_section">
                        <div class="row boxes">
                            <div class="col col-sm-6 col-md-3">
                                <div class="c_widget color_1 hvr-wobble-vertical">
                                  <div class="c_content text-center">
                                    <i class="icon ti-user"></i>
                                    <h2><?php echo $deatil['attorny_count'] ?></h2>
                                    <hr>
                                    <p>TOTAL ATTORNEY</p>
                                  </div>
                                </div>
                            </div>
                            <div class="col col-sm-6 col-md-3">
                               <div class="c_widget color_2 hvr-wobble-vertical">
                                  <div class="c_content text-center">
                                    <i class="icon fa ti-briefcase"></i>
                                    <h2><?php echo $deatil['apeerance_count'] ?></h2>
                                    <hr>
                                    <p>TOTAL APPEARANCE</p>
                                  </div>
                                </div>
                            </div>

                            <div class="col col-sm-6 col-md-3">
                                <div class="c_widget color_3 hvr-wobble-vertical">
                                  <div class="c_content text-center">
                                    <i class="icon ti-money"></i>
                                    <h2><?php echo $deatil['total_payment_received'] ?></h2>
                                    <hr>
                                    <p>TOTAL PAYMENT RECEIVED</p>
                                  </div>
                                </div>
                            </div>
                            <div class="col col-sm-6 col-md-3">
                               
                                <div class="c_widget color_4 hvr-wobble-vertical">
                                  <div class="c_content text-center">
                                    <i class="icon ti-money"></i>
                                    <h2><?php echo $deatil['total_payment_sent'] ?></h2>
                                    <hr>
                                    <p>TOTAL PAYMENT SENT</p>
                                  </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <div class="row latest-activity">
                        <div class="col-sm-6">
                            <div class="panel panel-primary">
                                <div class="panel-heading clearfix">
                                    <h4 class="panel-title"><i class="fa fa-user"></i>&nbsp; ATTORNEY list</h4>
                                    <div class="viewall">
                                        <a href="<?php echo Yii::$app->urlManager->createAbsoluteUrl('attorney/index')?>" waves class="btn btn-primary btn-sm text-uppercase waves-effect waves-ripple">View All</a>
                                    </div>
                                </div>
                                <div class="panel-body">
                                    <div class="table-responsive admintable">
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <th>Unique ID</th>
                                                    <th>BAR No.</th>
                                                    <th>Full Name</th>
                                                    <th>Email Address</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php 
                                                if(count($deatil['attornys'])>0){
                                                foreach ($deatil['attornys'] as $attorny)
                                                    {
                                                    ?>
                                                <tr>
                                                    <td><?php echo $attorny['id']?></td>
                                                    <td><?php echo $attorny['bar_number']?></td>
                                                    <td><?php echo $attorny['first_name'].' '.$attorny['last_name']?></td>
                                                    <td><?php echo $attorny['email']?></td>
                                                </tr>
                                                    <?php }}else{?>
                                                 <tr><td colspan="5"><div class="alert alert-danger">No Record Found</div></td></tr>
                                                    <?php }?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="panel panel-primary">
                                <div class="panel-heading clearfix">
                                    <h4 class="panel-title"><i class="fa fa-users"></i>&nbsp; Appearance List </h4>
                                    <div class="viewall">
                                        <a href="<?php echo Yii::$app->urlManager->createAbsoluteUrl('apeerance/index')?>" waves class="btn btn-primary btn-sm text-uppercase waves-effect waves-ripple">View All</a>
                                    </div>
                                </div>
                                <div class="panel-body">
                                    <div class="table-responsive admintable">
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <th>Unique ID</th>
                                                    <th>Full Name</th>
                                                    <th>Email Address</th>
                                                    <th class="text-center">Appearance</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                 <?php 
                                                 if(count($deatil['apeerances'])>0){
                                                 foreach ($deatil['apeerances'] as $attorny)
                                                    {
                                                    ?>
                                                <tr>
                                                    <td><?php echo $attorny['id']?></td>
                                                    <td><?php echo $attorny['first_name'].' '.$attorny['last_name']?></td>
                                                    <td><?php echo $attorny['email']?></td>
                                                    <td class="text-center"><?php echo $attorny['apeerances']?></td>
                                                </tr>
                                              
                                                   <?php }}else{?>
                                                 <tr><td colspan="5"><div class="alert alert-danger">No Record Found</div></td></tr>
                                                    <?php }?>
                                                
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>                       
                    </div>
                </div>
            </main>
        </div>
