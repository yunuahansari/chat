<?php
$this->title = "Settings";
use yii\widgets\ActiveForm;
use yii\helpers\Html;
?>

<main class="main-content commonform-page">
    <div class="container-fluid">
        <div class="page-title" id="pageTitle">
            <h4>Commission Settings</h4>
        </div>
        <div class="panel panel-primary filter-panel" id="panel-height">

            <div class="panel-body">
                <div class="change-password">  

<?php if (Yii::$app->session->hasFlash('success')): ?>
                        <div class="alert alert-success alert-dismissable">
                            <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                            <h4><i class="icon fa fa-check"></i>Saved!</h4>
    <?= Yii::$app->session->getFlash('success') ?>

                        </div>

                    <?php endif; ?>
                    <?php $form = ActiveForm::begin(
                    );
                    ?>                                   
                    <div class="row">
                        <div class="col-sm-6 col-md-4">
                            <label>Commission %</label>
                            <div class="form-group">
                        <?= $form->field($model, 'key_value')->textInput(['class' => 'form-control input-lg ', 'placeholder' => 'value'])->label(false); ?>
                            </div>
                        </div>
                    <?= $form->field($model, 'id')->hiddenInput()->label(false); ?>
                    </div>
<?= Html::submitButton('Save', ['class' => "btn btn-primary btn-lg noradius waves-effect waves-button waves-light text-uppercase"]); ?>
<?php ActiveForm::end(); ?> 
                </div>


            </div>                        
        </div>
    </div>
</main>


<script>
    window.setTimeout(function () {
        $(".alert").fadeTo(500, 0).slideUp(500, function () {
            $(this).remove();
        });
    }, 4000);
</script>





