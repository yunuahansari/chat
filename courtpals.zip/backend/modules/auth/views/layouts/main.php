<?php
use backend\assets\AppAsset;
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\url;
/* @var $this \yii\web\View */
/* @var $content string */
AppAsset::register($this);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
<head>
    <meta charset="<?= Yii::$app->charset ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <meta name="msapplication-TileColor" content="#da532c">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo Yii::getAlias('@base_url'); ?>/images/favicons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo Yii::getAlias('@base_url'); ?>/images/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo Yii::getAlias('@base_url'); ?>/images/favicons/favicon-16x16.png">
    <link rel="manifest" href="<?php echo Yii::getAlias('@base_url'); ?>/images/favicons/manifest.json">
    <link rel="mask-icon" href="<?php echo Yii::getAlias('@base_url'); ?>/images/favicons/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="theme-color" content="#ffffff">
    <?= Html::csrfMetaTags() ?>
    <title><?= Html::encode($this->title).' | '. Yii::$app->name ?></title>
    
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
         <script src="js/html5shiv.js"></script>
       <script src="js/respond.min.js"></script> 
   <![endif]-->
    <?php $this->head() ?>
</head>
<script>
    if (navigator.userAgent.match(/IEMobile\/10\.0/)) {
        var msViewportStyle = document.createElement('style')
        msViewportStyle.appendChild(
            document.createTextNode(
                '@-ms-viewport{width:auto!important}'
            )
        )
        document.querySelector('head').appendChild(msViewportStyle)
    }
</script>
 
 <body class="loginpage" onload="hide_preloader();">
        <div id="preloader">
            <div class="inner">
                <div class="image">
                    <img src="<?php echo Yii::getAlias('@images_url'); ?>/white_new_logo.png" class="img-responsive" />
                </div>
                <div class="spinner">
                    <div class="rect1"></div>
                    <div class="rect2"></div>
                    <div class="rect3"></div>
                    <div class="rect4"></div>
                    <div class="rect5"></div>
                </div>
            </div>
        </div>
    <?php $this->beginBody() ?>
    <?= $content;?>
    <?php $this->endBody() ?>
</body>
</html>


<?php $this->endPage() ?>
<script>
      Waves.init();
        var rotate = 1;
        function hide_preloader() {
            rotate = 0;
            $("#preloader").fadeOut('slow');
        }

</script>