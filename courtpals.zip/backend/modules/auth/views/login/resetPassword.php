<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\url;
$this->title = "Reset Password";
?>

        <div id="content">                   
            <main class="login-page">
                <div class="container">                        
                    <section class="login_section">
                        <img src="<?php echo Yii::getAlias('@images_url'); ?>/white_new_logo.png" class="img-responsive center-block" />
                        <div class="inner_section">
                            <h2 class="text-center mt-0 mb-30 font-700 themecolor text-uppercase">Reset Password</h2>
                             <?php $form = ActiveForm::begin(
                                ); ?>
                                <div class="form-group">
                                    <div class="input-group-lg">
                                        <label class="control-label">Password</label>
                                         <?= $form->field($model, 'password')->passwordInput(['class' => 'form-control input-lg noradius ti-lock','placeholder'=>'Password'])->label(false); ?>
                                    </div> 
                                    <span class="icon"><img src="<?php echo Yii::getAlias('@images_url'); ?>/lock-ico.jpg" alt="icon"></span>                                      
                                </div>
                                <div class="form-group">
                                    <div class="input-group-lg">
                                        <label class="control-label">Confirm Password</label>
                                        <?= $form->field($model, 'confirm_password')->passwordInput(['class' => 'form-control input-lg noradius ti-email','placeholder'=>'Confirm Password'])->label(false); ?>
                                    </div>  
                                    <span class="icon"><img src="<?php echo Yii::getAlias('@images_url'); ?>/lock-ico.jpg" alt="icon"></span>                                      
                                </div>
                                <div class="clearfix"></div>
                                <div class="form-group mb-10 mt-15 mt-xs-0">
                                    <button type="submit" class="btn btn-primary btn-block noradius btn-lg waves-effect waves-button waves-light font-700">SUBMIT</button>                                    
                                </div>
                               <?php ActiveForm::end(); ?>  
                        </div>
                    </section>
                </div>
            </main>
        </div>                
