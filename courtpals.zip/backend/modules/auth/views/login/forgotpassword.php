<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use frontend\widgets\Alert;

$this->title = 'Forgot Password';
?>


<main class="login-page">
    <div class="container">

        <section class="login_section">
            <img src="<?php echo Yii::getAlias('@images_url'); ?>/white_new_logo.png" class="img-responsive center-block" />
            <div class="inner_section">
                <h2 class="text-center mt-0 mb-30 font-700 themecolor text-uppercase">Forget Password</h2>

                <?php if (Yii::$app->session->hasFlash('success')): ?>
                    <div class="alert alert-success alert-dismissable">
                        <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                        <?= Yii::$app->session->getFlash('success') ?>
                    </div>
                <?php endif; ?>

                <?php if (Yii::$app->session->hasFlash('error')): ?>
                    <div class="alert alert-success alert-dismissable">
                        <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                        <?= Yii::$app->session->getFlash('error') ?>
                    </div>
                <?php endif; ?>

                <?php
                $form = ActiveForm::begin(
                );
                ?>
                <div class="form-group">

                    <div class="input-group-lg">
                        <label class="control-label">Enter Email</label>
                        <?= $form->field($model, 'email')->textInput(['class' => 'form-control noradius input-lg', 'placeholder' => 'Enter Email'])->label(false); ?>
                    </div>  
                    
                    <span class="icon"><img src="<?php echo Yii::getAlias('@images_url'); ?>/mail-ico.jpg" alt="icon"></span>         
                </div>                                
                <div class="clearfix"></div>
                <div class="form-group mb-10 mt-15 mt-xs-0">

                    <button type="submit" id="forgot-form-loader"class="btn btn-primary btn-block noradius btn-lg waves-effect waves-button waves-light font-700 text-uppercase">Submit</button>                                    
                </div>
                <ul class="list-inline text-center mb-0">
                    <li><a href="<?php echo yii::$app->urlManager->createAbsoluteUrl('/auth/login') ?>" class="themelink"><i class="ti-hand-point-left"></i> Back to Login</a></li>
                </ul>
<?php ActiveForm::end(); ?> 
            </div>
        </section>
    </div>
</main>
<script>
    window.setTimeout(function () {
        $(".alert").fadeTo(500, 0).slideUp(500, function () {
            $(this).remove();
        });
    }, 4000);

    window.addEventListener('beforeunload', function (event) {
        $("#forgot-form-loader").attr("disabled", true);
        $("#forgot-form-loader").html('SUBMIT <i class="fa fa-spinner fa-spin"></i>');
    });

</script>