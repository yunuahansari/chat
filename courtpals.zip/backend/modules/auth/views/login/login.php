<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\url;
$this->title = "Admin Login";
?>

        <div id="content">                   
            <main class="login-page">
                <div class="container">                        
                    <section class="login_section">
                        <img src="<?php echo Yii::getAlias('@images_url'); ?>/white_new_logo.png" class="img-responsive center-block" />
                        <div class="inner_section">
                            <h2 class="text-center mt-0 mb-30 font-700 themecolor text-uppercase">Admin Login</h2>
                            <?php if (Yii::$app->session->hasFlash('success')): ?>
                                <div class="alert alert-success alert-dismissable">
                                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                                <?= Yii::$app->session->getFlash('success') ?>
                                </div>
                            <?php endif; ?>
                             <?php $form = ActiveForm::begin(
                                ); ?>
                                <div class="form-group">
                                    <div class="input-group-lg">
                                        <?= $form->field($model, 'email')->textInput(['class' => 'form-control input-lg noradius ti-email','placeholder'=>'Email']); ?>
                                    </div>   
                                    <span class="icon"><img src="<?php echo Yii::getAlias('@images_url'); ?>/mail-ico.jpg" alt="icon"></span>                                     
                                </div>
                                <div class="form-group">
                                    <div class="input-group-lg">
                                         <?= $form->field($model, 'password')->passwordInput(['class' => 'form-control input-lg noradius ti-lock','placeholder'=>'Password']); ?>
                                    </div>   
                                    <span class="icon"><img src="<?php echo Yii::getAlias('@images_url'); ?>/lock-ico.jpg" alt="icon"></span>                                     
                                </div>
                                <div class="clearfix"></div>
                                <div class="form-group mb-10 mt-15 mt-xs-0">
                                    <button id="login-form-loader"type="submit" class="btn btn-primary btn-block noradius btn-lg waves-effect waves-button waves-light font-700">LOGIN</button>                                    
                                </div>
                                <ul class="list-inline text-center mb-0">
                                    <li><a href="<?php echo yii::$app->urlManager->createAbsoluteUrl('/auth/login/forgot-password') ?>" class="themelink">Forgot Password</a></li>
                                </ul>
                               <?php ActiveForm::end(); ?>  
                        </div>
                    </section>
                </div>
            </main>
        </div>                
<script>
  
    window.addEventListener('beforeunload', function(event) {
        $("#login-form-loader").attr("disabled", true);
        $("#login-form-loader").html('LOGIN <i class="fa fa-spinner fa-spin"></i>');
     });
  
</script>