<?php
/**
 * @link http://www.yiiframework.com/
 * @copyright Copyright (c) 2008 Yii Software LLC
 * @license http://www.yiiframework.com/license/
 */

namespace backend\assets;

use yii\web\AssetBundle;

/**
 * @author Qiang Xue <qiang.xue@gmail.com>
 * @since 2.0
 */
use yii\web\View;
class AppAsset extends AssetBundle
{
    public $basePath = '@webroot';
    public $baseUrl = '@web';
    public $css = [
        'css/themify-icons.css',
        'css/waves.min.css',
        'css/bootstrap.min.css',
        'css/font-awesome.min.css', 
        'css/bootstrap-select.min.css',  
        'css/bootstrap-datepicker.min.css',
        'css/jquery.mCustomScrollbar.min.css',
        'css/custom.min.css',
        'css/toastr.min.css',
        
    ];
    public $js = [
//        'js/jquery-1.9.1.min.js',
        'js/jquery.min.js',
        'js/bootstrap.min.js',
        'js/waves.min.js',
        'js/bootstrap-select.min.js',
        'js/bootstrap-datepicker.min.js',
        'js/bootbox.min.js',
        'js/input-mask.js',
        'js/jquery.raty.min.js',
        'js/jquery.mCustomScrollbar.concat.min.js',
        'js/toastr.min.js',
        'js/jquery.raty.min.js'
    ];
   public $jsOptions = array(
        'position' => View::POS_HEAD
    );
    public $depends = [
        'yii\web\YiiAsset',
        'yii\bootstrap\BootstrapAsset',
    ];
}
