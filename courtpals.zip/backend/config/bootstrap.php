<?php
$baseurl='http://localhost/courtpals/';
Yii::setAlias('base_url',  $baseurl);
Yii::setAlias('images_url',  $baseurl.'backend/web/images');
Yii::setAlias('profile_image',  $baseurl.'uploads/');

