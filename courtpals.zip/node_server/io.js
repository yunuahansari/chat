(function () {
    'use strict';
    var express = require('express');
    var app = express();
    app.use(express.static(__dirname + '/public'));

    var server = app.listen(6017);
    var io = require('socket.io')(server);
    var request = require('request');
    var connectedUsers = {};


    function updateStatus(presence, userID) {
        var options = {
            url: 'http://apeerance.codiant.com/api/web/index.php/messages/update-chat-status',
            method: 'POST',
            body: JSON.stringify({"presence": presence, "user_id": userID}),
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        };
        request(options, function (error, response, body) {
            if (!error && response.statusCode === 200) {
                var arr = JSON.parse(body);
                if (arr.data.length > 0) {
                    for (var i = 0; i < arr.data.length; i++) {
                        if (connectedUsers.hasOwnProperty(arr.data[i])) {
                            connectedUsers[arr.data[i]].emit('presence', {"presence": presence, "userID": userID});
                        }
                    }
                }
            }

        });
    }

    io.sockets.on('connection', function (socket) {

        socket.on('register', function (packet) {

            var userJID = packet.userID
            
            if (connectedUsers.hasOwnProperty(userJID)) {

                connectedUsers[userJID].removeAllListeners();
                connectedUsers[userJID].disconnect();
                delete connectedUsers[userJID];
            }
            ;

            if (!connectedUsers.hasOwnProperty(userJID)) {

                socket.userId = userJID;
                connectedUsers[userJID] = socket;
            }
            ;
        });

        socket.on('presence', function (packet) {

            var presence = packet.presence;
            var userJID = packet.userID;
            //updateStatus(presence,userJID);
        });



        socket.on('chat', function (packet) {

            var toUser = packet.to;
            var fromUser = packet.from;
            var case_id = packet.caseId;
            var message = packet.text;
            
            if (connectedUsers.hasOwnProperty(toUser)) {
                var options = {
                    url: 'http://apeerance.codiant.com/api/web/index.php/messages/save-message',
                    method: 'POST',
                    body: JSON.stringify({
                        "case_id": case_id,
                        "sender": fromUser,
                        "receiver": toUser,
                        "message": message,
                        "type": packet.type,
                        "media": packet.mediaURL,
                        "thumbnail": packet.thumbnail,
                        "time_stamp": packet.timestamp,
                        "sticker_id": packet.stickerId,
                        "unread_message_count":packet.unread_message_count,
                        "unread_thread_count":packet.unread_thread_count,
                        "online": true
                    }),
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                        'access-token': packet.accessToken
                    }
                };
                request(options, function (error, response, body) {
                    if (response.statusCode === 200) {
                       var arr = JSON.parse(body);
                       packet.unread_message_count = arr.data.unread_message_count;  
                       packet.unread_thread_count = arr.data.unread_thread_count;  
                       packet.message_id = arr.data.message_id;  
                       connectedUsers[toUser].emit('chat', packet);
                    }
                });                
            }
            else {
                // Add message to table.
                // If first send push notification {aps - content-available: 1}
                var options = {
                    url: 'http://apeerance.codiant.com/api/web/index.php/messages/save-message',
                    method: 'POST',
                    body: JSON.stringify({
                        "case_id": case_id,
                        "sender": fromUser,
                        "receiver": toUser,
                        "message": message,
                        "type": packet.type,
                        "media": packet.mediaURL,
                        "thumbnail": packet.thumbnail,
                        "time_stamp": packet.timestamp,
                        "sticker_id": packet.stickerId,
                        "online": false
                    }),
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                        'access-token': packet.accessToken
                    }
                };
                request(options, function (error, response, body) {
                    
                });
            }
        });

        socket.on('typing', function (packet) {

            var toUser = packet.to;

            if (connectedUsers.hasOwnProperty(toUser)) {
                connectedUsers[toUser].emit('typing', packet);
            }
        });

        socket.on('disconnect', function () {
            if (connectedUsers.hasOwnProperty(socket.userId)) {
                //updateStatus('offline',socket.userId);
                delete connectedUsers[socket.userId];

                socket.removeAllListeners();
                socket.leave();
            }
            ;
        });

    });
})();

