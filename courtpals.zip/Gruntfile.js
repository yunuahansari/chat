!(function () {
    'use strict';
    module.exports = function (grunt) {
        grunt.initConfig({
            pkg: grunt.file.readJSON('package.json'),
            sass: {
                options: {
                    style: 'compressed',
                    sourcemap: 'none',
                    noCache: true
                },
                 dist: {
                     files: {
                         'frontend/web/css/custom.min.css': 'frontend/web/sass/main.scss'
                     }
                 }
//                admin: {
//                    files: {
//                        'backend/web/css/custom.min.css': 'backend/web/sass/main.scss'
//                    }
//                }

            },
            watch: {
                sass: {
                    files: [
                         'frontend/web/sass/*/*.scss', 'frontend/web/sass/**/*.scss','sass/***/*.scss',
                        
//                        'backend/web/sass/*/*.scss', 'backend/web/sass/**/*.scss','sass/***/*.scss',
                        ['Gruntfile.js']],
                    tasks: ['sass']  

                }
            }
        });
        grunt.loadNpmTasks('grunt-contrib-sass');
        grunt.loadNpmTasks('grunt-contrib-watch');
        // Default task(s).
        grunt.registerTask('default', ['sass', 'watch']);
    };
})();