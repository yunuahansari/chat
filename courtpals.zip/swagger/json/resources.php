<?php
$params = require_once('params.php');
echo json_encode([
    'apis' => [
        [
            'path' => '/account.php',
            'description' => '',
        ],
        [
            'path' => '/user.php',
            'description' => '',
        ],
        [
            'path' => '/request.php',
            'description' => '',
        ],
        [
            'path' => '/transactions.php',
            'description' => '',
        ],
        [
            'path' => '/notification.php',
            'description' => '',
        ],
        [
            'path' => '/list.php',
            'description' => '',
        ],
        [
            'path' => '/messages.php',
            'description' => '',
        ],
        
    ],
    'basePath' => $params['apiHelpUrl'],
    'apiUrl' => $params['apiUrl'],
    'apiVersion' => '1.0.0',
    'swaggerVersion' => '1.0'
]);