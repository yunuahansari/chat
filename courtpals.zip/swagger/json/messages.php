<?php

$params = require_once('params.php');

echo json_encode([
    'resourcePath' => '/messages',
    'basePath' => $params['apiUrl'],
    'apis' => [
        [
            'path' => '/messages',
            'description' => 'message inbox',
            'operations' => [
                [
                    'parameters' => [
                        [
                            'name' => 'access-token',
                            'description' => "The user's access_token",
                            'required' => true,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'header'
                        ],
                        [
                            'name' => 'expand',
                            'description' => "other_user,other_user_image,sender_name,sender_profile_image,receiver_name,receiver_profile_image",
                            'required' => false,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'query'
                        ],
                        [
                            'name' => 'timezone',
                            'description' => "like Asia/Kolkata",
                            'required' => false,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'query'
                        ],
                    ],
                    'summary' => 'message inbox',
                    'httpMethod' => 'GET',
                    'nickname' => '',
                    "consumes" => [
                       
                    ],
                ]
            ]
        ],
        [
            'path' => '/messages/detail',
            'description' => 'Get message list',
            'operations' => [
                [
                    'parameters' => [
                        [
                            'name' => 'access-token',
                            'description' => "The user's access_token",
                            'required' => true,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'header'
                        ],
                        [
                            'name' => 'case_id',
                            'description' => "case id",
                            'required' => true,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'query'
                        ],
                        [
                            'name' => 'expand',
                            'description' => "other_user,other_user_image,sender_name,sender_profile_image,receiver_name,receiver_profile_image",
                            'required' => false,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'query'
                        ],
                        [
                            'name' => 'timezone',
                            'description' => "like Asia/Kolkata",
                            'required' => false,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'query'
                        ],
                    ],
                    'summary' => 'Get Transaction total',
                    'httpMethod' => 'GET',
                    'nickname' => '',
                    "consumes" => [
                       
                    ],
                ]
            ]
        ],
        [
            'path' => '/messages/send-multi-media-message',
            'description' => 'save user message',
            'operations' => [
                [
                    'parameters' => [
                        [
                            'name' => 'access-token',
                            'description' => "The user's access_token",
                            'required' => true,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'header'
                        ],
                        [
                            'name' => 'type',
                            'description' => "",
                            'required' => true,
                            'dataType' => 'string',
                            'enum' => ['image','document'],
                            'allowMultiple' => false,
                            'paramType' => 'formData'
                        ],
                        [
                            'name' => 'media',
                            'description' => "media can be image or document",
                            'required' => false,
                            'dataType' => 'file',
                            'allowMultiple' => false,
                            'paramType' => 'formData'
                        ],
                    ],
                    'summary' => '',
                    'httpMethod' => 'POST',
                    'nickname' => '',
                    "consumes" => [
                        "multipart/form-data"
                    ],
                ]
            ]
        ],
        [
            'path' => '/messages/save-message',
            'description' => 'send message',
            'operations' => [
                [
                    'parameters' => [
                        [
                            'name' => 'access-token',
                            'description' => "The user's access_token",
                            'required' => true,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'header'
                        ],
                        [
                            'name' => 'body',
                            'description' => 'send message',
                            'required' => false,
                            'type' => 'send_message',
                            'paramType' => 'body'
                        ],
                    ],
                    'summary' => 'Save Message',
                    'httpMethod' => 'POST',
                    'nickname' => 'send message',
                    'consumes' => [
                        "application/json",
                        "application/xml"
                    ],
                ]
            ]
        ],
        [
            'path' => '/messages/delete',
            'description' => 'delete message',
            'operations' => [
                [
                    'parameters' => [
                        [
                            'name' => 'access-token',
                            'description' => "The user's access_token",
                            'required' => true,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'header'
                        ],
                        [
                            'name' => 'message_id',
                            'description' => '',
                            'required' => true,
                            'dataType' => 'int',
                            'paramType' => 'query'
                        ],
                    ],
                    'summary' => 'delete Message',
                    'httpMethod' => 'DELETE',
                    'nickname' => 'delete message',
                    'consumes' => [
                        "application/json",
                        "application/xml"
                    ],
                ]
            ]
        ],
        [
            'path' => '/messages/delete-all',
            'description' => 'delete All message',
            'operations' => [
                [
                    'parameters' => [
                        [
                            'name' => 'access-token',
                            'description' => "The user's access_token",
                            'required' => true,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'header'
                        ],
                        [
                            'name' => 'case_id',
                            'description' => '',
                            'required' => true,
                            'dataType' => 'string',
                            'paramType' => 'query'
                        ],
                    ],
                    'summary' => 'delete All message',
                    'httpMethod' => 'delete',
                    'nickname' => 'delete All message',
                    'consumes' => [
                        "application/json",
                        "application/xml"
                    ],
                ]
            ]
        ],
        [
            'path' => '/messages/delete-all-thread',
            'description' => 'delete All thread',
            'operations' => [
                [
                    'parameters' => [
                        [
                            'name' => 'access-token',
                            'description' => "The user's access_token",
                            'required' => true,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'header'
                        ]
                    ],
                    'summary' => 'delete All threath',
                    'httpMethod' => 'delete',
                    'nickname' => 'delete All thread',
                    'consumes' => [
                        "application/json",
                        "application/xml"
                    ],
                ]
            ]
        ],
        [
            'path' => '/messages/read-message',
            'description' => 'read message',
            'operations' => [
                [
                    'parameters' => [
                        [
                            'name' => 'access-token',
                            'description' => "The user's access_token",
                            'required' => true,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'header'
                        ],
                        [
                            'name' => 'body',
                            'description' => 'receiver_read should be 1',
                            'required' => false,
                            'type' => 'read_message',
                            'paramType' => 'body'
                        ],
                    ],
                    'summary' => 'Read Message',
                    'httpMethod' => 'POST',
                    'nickname' => 'read message',
                    'consumes' => [
                        "application/json",
                        "application/xml"
                    ],
                ]
            ]
        ],
    ],
    'apiVersion' => $params['apiVersion'],
    'swaggerVersion' => $params['swaggerVersion'],
    'models' => [
        'send_message' =>[
            'properties' => [
                'case_id'=>['type'=>'string'],
                'sender'=>['type'=>'integer'],
                'receiver'=>['type'=>'integer'],
                'message'=>['type'=>'string'],
                'type'=>['type'=>'string'],
                'media'=>['type'=>'string'],
                'thumbnail'=>['type'=>'string'],
                'time_stamp'=>['type'=>'string'],
                'sticker_id'=>['type'=>'string'],
                'online'=>['type'=>'string'],
            ],
            'id' => 'send_message',
            'type' => 'any',
            'required' => false
        ],
        'read_message' =>[
            'properties' => [
                'message_id'=>['type'=>'integer'],
                'receiver_read'=>['type'=>'integer'],
            ],
            'id' => 'read_message',
            'type' => 'any',
            'required' => false
        ],
    ] 
]);