<?php

$params = require_once('params.php');

echo json_encode([
    'resourcePath' => '/notification',
    'basePath' => $params['apiUrl'],
    'apis' => [
        [
            'path' => '/notification/all',
            'description' => 'Get notification',
            'operations' => [
                [
                    'parameters' => [
                        [
                            'name' => 'access-token',
                            'description' => "The user's access_token",
                            'required' => true,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'header'
                        ],
                        [
                            'name' => 'timezone',
                            'description' => "like Asia/Kolkata",
                            'required' => false,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'query'
                        ],
                    ],
                    'summary' => 'Get notification',
                    'httpMethod' => 'GET',
                    'nickname' => '',
                    "consumes" => [
                       
                    ],
                ]
            ]
        ],
        [
            'path' => '/notification/delete/{notification_id}',
            'description' => 'delete notification',
            'operations' => [
                [
                    'parameters' => [
                        [
                            'name' => 'access-token',
                            'description' => "The user's access_token",
                            'required' => true,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'header'
                        ],
                        [
                            'name' => 'notification_id',
                            'description' => "",
                            'required' => false,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'path'
                        ],
                      
                       
                        
                    ],
                    'summary' => 'delete notification',
                    'httpMethod' => 'delete',
                    'nickname' => '',
                    'consumes' => [
                        "application/json",
                        "application/xml"
                    ],
                ]
            ]
        ],
        [
            'path' => '/notification/delete-all',
            'description' => 'Delete all notification',
            'operations' => [
                [
                    'parameters' => [
                        [
                            'name' => 'access-token',
                            'description' => "The user's access_token",
                            'required' => true,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'header'
                        ],
                       
                    ],
                    'summary' => 'Delete all notification',
                    'httpMethod' => 'delete',
                    'nickname' => 'deletenotification',
                    'consumes' => [
                        "application/json",
                        "application/xml"
                    ],
                ]
            ]
        ],
       
    ],
    'apiVersion' => $params['apiVersion'],
    'swaggerVersion' => $params['swaggerVersion'],
    'models' => [
        'update_profile' => [
            'properties' => [
                'first_name' => ['type' => 'string'],
                'last_name' => ['type' => 'string'],
                'bar_number' => ['type' => 'string'],
                'snn_number' => ['type' => 'string'],
                'mobile' => ['type' => 'string'],
                'email' => ['type' => 'string'],
                'address' => ['type' => 'string'],
                'city' => ['type' => 'string'],
                'zip_code' => ['type' => 'string'],
            ],
            'id' => 'update_profile',
            'type' => 'any',
            'required' => false
        ],
        'changepassword'=>[
            'properties' => [
                'password'=>['type'=>'string'],
                'new_password'=>['type'=>'string'],
            ],
            'id' => 'changepassword',
            'type' => 'any',
            'required' => false
        ],
        'addAddress'=>[
            'properties' => [
                'address'=>['type'=>'string']
            ],
            'id' => 'addAddress',
            'type' => 'any',
            'required' => false
        ],
    ] 
]);