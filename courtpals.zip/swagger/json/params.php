<?php
$baseUrl = 'http://localhost/courtpals/';
return array_merge([
    'apiVersion' => '1.0.0',
    'swaggerVersion' => '1.0',
    'apiHelpUrl' => $baseUrl.'swagger/json',
    'apiUrl' => $baseUrl.'api/web/index.php',
    'baseUrl' => $baseUrl
]);