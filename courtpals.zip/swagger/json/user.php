<?php

$params = require_once('params.php');

echo json_encode([
    'resourcePath' => '/user',
    'basePath' => $params['apiUrl'],
    'apis' => [
        [
            'path' => '/user/profile/{user_id}',
            'description' => 'Get Profile',
            'operations' => [
                [
                    'parameters' => [
                        [
                            'name' => 'access-token',
                            'description' => "The user's access_token",
                            'required' => true,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'header'
                        ],
                        [
                            'name' => 'user_id',
                            'description' => 'User ID',
                            'required' => true,
                            'dataType' => 'int',
                            'allowMultiple' => false,
                            'paramType' => 'path'
                        ],
                        [
                            'name' => 'case_id',
                            'description' => 'User ID',
                            'required' => false,
                            'dataType' => 'int',
                            'allowMultiple' => false,
                            'paramType' => 'query'
                        ],
                    ],
                    'summary' => 'Get Profile',
                    'httpMethod' => 'GET',
                    'nickname' => '',
                    "consumes" => [
                       
                    ],
                ]
            ]
        ],
        [
            'path' => '/user/update',
            'description' => 'Update Profile',
            'operations' => [
                [
                    'parameters' => [
                        [
                            'name' => 'access-token',
                            'description' => "The user's access_token",
                            'required' => true,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'header'
                        ],
                        [
                            'name' => 'first_name',
                            'description' => "",
                            'required' => false,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'formData'
                        ],
                        [
                            'name' => 'last_name',
                            'description' => "",
                            'required' => false,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'formData'
                        ],
                        [
                            'name' => 'dob',
                            'description' => "yyyy-mm-dd",
                            'required' => true,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'formData'
                        ],
                        [
                            'name' => 'bar_number',
                            'description' => "",
                            'required' => false,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'formData'
                        ],
                        [
                            'name' => 'ssn_number',
                            'description' => "",
                            'required' => false,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'formData'
                        ],
                         [
                            'name' => 'mobile',
                            'description' => "",
                            'required' => false,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'formData'
                        ],
                        [
                            'name' => 'email',
                            'description' => "",
                            'required' => false,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'formData'
                        ],
                        [
                            'name' => 'address',
                            'description' => "",
                            'required' => false,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'formData'
                        ],
                        [
                            'name' => 'address2',
                            'description' => "",
                            'required' => false,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'formData'
                        ],
                        [
                            'name' => 'city',
                            'description' => "",
                            'required' => false,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'formData'
                        ],
                        [
                            'name' => 'zip_code',
                            'description' => "",
                            'required' => false,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'formData'
                        ],
                        [
                            'name' => 'profile_pic',
                            'description' => "",
                            'required' => false,
                            'dataType' => 'file',
                            'allowMultiple' => false,
                            'paramType' => 'formData'
                        ],
                       
                        
                    ],
                    'summary' => 'Update Profile',
                    'httpMethod' => 'POST',
                    'nickname' => '',
                    'consumes' => [
                        "application/json",
                        "application/xml"
                    ],
                ]
            ]
        ],
        [
            'path' => '/user/change-password',
            'description' => 'Account Change password',
            'operations' => [
                [
                    'parameters' => [
                        [
                            'name' => 'access-token',
                            'description' => "The user's access_token",
                            'required' => true,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'header'
                        ],
                        [
                            'name' => 'body',
                            'description' => 'Change Password',
                            'required' => false,
                            'type' => 'changepassword',
                            'paramType' => 'body'
                        ],
                    ],
                    'summary' => 'Change Password',
                    'httpMethod' => 'POST',
                    'nickname' => 'changePassword',
                    'consumes' => [
                        "application/json",
                        "application/xml"
                    ],
                ]
            ]
        ],
//        [
//            'path' => '/user/add-address',
//            'description' => 'Add Address',
//            'operations' => [
//                [
//                    'parameters' => [
//                        [
//                            'name' => 'access-token',
//                            'description' => "The user's access_token",
//                            'required' => true,
//                            'dataType' => 'string',
//                            'allowMultiple' => false,
//                            'paramType' => 'header'
//                        ],
//                        [
//                            'name' => 'body',
//                            'description' => '',
//                            'required' => false,
//                            'type' => 'addAddress',
//                            'paramType' => 'body'
//                        ],
//                    ],
//                    'summary' => 'Add Address',
//                    'httpMethod' => 'POST',
//                    'nickname' => 'addAddress',
//                    'consumes' => [
//                        "application/json",
//                        "application/xml"
//                    ],
//                ]
//            ]
//        ],
        [
            'path' => '/user/rating-review',
            'description' => 'Add Address',
            'operations' => [
                [
                    'parameters' => [
                        [
                            'name' => 'access-token',
                            'description' => "The user's access_token",
                            'required' => true,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'header'
                        ],
                        [
                            'name' => 'body',
                            'description' => 'apeerance_successfull :- "yes/no"',
                            'required' => false,
                            'type' => 'rating_review',
                            'paramType' => 'body'
                        ],
                    ],
                    'summary' => 'Give ratting',
                    'httpMethod' => 'POST',
                    'nickname' => 'giveRatting',
                    'consumes' => [
                        "application/json",
                        "application/xml"
                    ],
                ]
            ]
        ],
        [
            'path' => '/user/refund-request/{request_id}',
            'description' => 'Refund Request',
            'operations' => [
                [
                    'parameters' => [
                        [
                            'name' => 'access-token',
                            'description' => "The user's access_token",
                            'required' => true,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'header'
                        ],
                        [
                            'name' => 'request_id',
                            'description' => '',
                            'required' => false,
                            'type' => 'string',
                            'paramType' => 'path'
                        ],
                    ],
                    'summary' => 'Refund Request',
                    'httpMethod' => 'GET',
                    'nickname' => 'Refund Request',
                    'consumes' => [
                        "application/json",
                        "application/xml"
                    ],
                ]
            ]
        ],
        [
            'path' => '/user/add-bank-detail',
            'description' => 'Add Bank Detail',
            'operations' => [
                [
                    'parameters' => [
                        [
                            'name' => 'access-token',
                            'description' => "The user's access_token",
                            'required' => true,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'header'
                        ],
                        [
                            'name' => 'body',
                            'description' => '',
                            'required' => false,
                            'type' => 'add_bank_detail',
                            'paramType' => 'body'
                        ],
                    ],
                    'summary' => 'Add Bank Detail',
                    'httpMethod' => 'POST',
                    'nickname' => 'Add_Bank_Detail',
                    'consumes' => [
                        "application/json",
                        "application/xml"
                    ],
                ]
            ]
        ],
        [
            'path' => '/user/edit-bank-detail',
            'description' => 'edit Bank Detail',
            'operations' => [
                [
                    'parameters' => [
                        [
                            'name' => 'access-token',
                            'description' => "The user's access_token",
                            'required' => true,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'header'
                        ],
                        [
                            'name' => 'body',
                            'description' => '',
                            'required' => false,
                            'type' => 'edit_bank_detail',
                            'paramType' => 'body'
                        ],
                    ],
                    'summary' => 'editBank Detail',
                    'httpMethod' => 'POST',
                    'nickname' => 'edit_Bank_Detail',
                    'consumes' => [
                        "application/json",
                        "application/xml"
                    ],
                ]
            ]
        ],
        [
            'path' => '/user/delete-bank-detail/{bank_detail_id}',
            'description' => 'Delete Bank Detail',
            'operations' => [
                [
                    'parameters' => [
                        [
                            'name' => 'access-token',
                            'description' => "The user's access_token",
                            'required' => true,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'header'
                        ],
                        [
                            'name' => 'bank_detail_id',
                            'description' => '',
                            'required' => true,
                            'dataType' => 'int',
                            'allowMultiple' => false,
                            'paramType' => 'path'
                        ], 
                    ],
                    'summary' => 'Delete Bank Detail',
                    'httpMethod' => 'delete',
                    'nickname' => 'delete_Bank_Detail',
                    'consumes' => [
                        "application/json",
                        "application/xml"
                    ],
                ]
            ]
        ],
        [
            'path' => '/user/favourite-address',
            'description' => 'Favourite address',
            'operations' => [
                [
                    'parameters' => [
                        [
                            'name' => 'access-token',
                            'description' => "The user's access_token",
                            'required' => true,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'header'
                        ],
                        [
                            'name' => 'body',
                            'description' => 'status should be favourite/unfavourite',
                            'required' => false,
                            'type' => 'favourite_address',
                            'paramType' => 'body'
                        ],
                    ],
                    'summary' => 'Favourite address',
                    'httpMethod' => 'POST',
                    'nickname' => 'favouriteAddress',
                    'consumes' => [
                        "application/json",
                        "application/xml"
                    ],
                ]
            ]
        ],
        [
            'path' => '/user/settings',
            'description' => 'Update settings',
            'operations' => [
                [
                    'parameters' => [
                        [
                            'name' => 'access-token',
                            'description' => "The user's access_token",
                            'required' => true,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'header'
                        ],
                        [
                            'name' => 'body',
                            'description' => 'notification = enable/disable <br/> hearing_type = id of hearing type',
                            'required' => false,
                            'type' => 'update_settings',
                            'paramType' => 'body'
                        ],
                    ],
                    'summary' => 'update settings',
                    'httpMethod' => 'POST',
                    'nickname' => 'updateSettings',
                    'consumes' => [
                        "application/json",
                        "application/xml"
                    ],
                ]
            ]
        ],
        [
            'path' => '/user/logout',
            'description' => 'Account Logout',
            'operations' => [
                [
                    'parameters' => [
                        [
                            'name' => 'access-token',
                            'description' => "The user's access_token",
                            'required' => true,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'header'
                        ]
                    ],
                    'summary' => 'Logout a user',
                    'httpMethod' => 'GET',
                    'nickname' => 'accountLogout',
                    'consumes' => [
                       
                    ],
                ]
            ]
        ],
        [
            'path' => '/user/get-rating-status',
            'description' => 'Check Request Status',
            'operations' => [
                [
                    'parameters' => [
                        [
                            'name' => 'access-token',
                            'description' => "The user's access_token",
                            'required' => true,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'header'
                        ]
                    ],
                    'summary' => 'Check Rating status of client',
                    'httpMethod' => 'GET',
                    'nickname' => 'checkRequestStatus',
                    'consumes' => [
                       
                    ],
                ]
            ]
        ],
        [
            'path' => '/user/contact-us',
            'description' => 'contact-us',
            'operations' => [
                [
                    'parameters' => [
                        [
                            'name' => 'access-token',
                            'description' => "The user's access_token",
                            'required' => true,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'header'
                        ],
                         [
                            'name' => 'body',
                            'description' => '',
                            'required' => false,
                            'type' => 'contact_us',
                            'paramType' => 'body'
                        ],
                    ],
                    'summary' => 'contact to admin',
                    'httpMethod' => 'POST',
                    'nickname' => 'accountLogout',
                    'consumes' => [
                       
                    ],
                ]
            ]
        ],
    ],
    'apiVersion' => $params['apiVersion'],
    'swaggerVersion' => $params['swaggerVersion'],
    'models' => [
        'update_profile' => [
            'properties' => [
                'first_name' => ['type' => 'string'],
                'last_name' => ['type' => 'string'],
                'bar_number' => ['type' => 'string'],
                'snn_number' => ['type' => 'string'],
                'mobile' => ['type' => 'string'],
                'email' => ['type' => 'string'],
                'address' => ['type' => 'string'],
                'city' => ['type' => 'string'],
                'zip_code' => ['type' => 'string'],
            ],
            'id' => 'update_profile',
            'type' => 'any',
            'required' => false
        ],
        'changepassword' =>[
            'properties' => [
                'password'=>['type'=>'string'],
                'new_password'=>['type'=>'string'],
            ],
            'id' => 'changepassword',
            'type' => 'any',
            'required' => false
        ],
        'update_settings' =>[
            'properties' => [
                'notification'=>['type'=>'string'],
                'hearing_type_id'=>['type'=>'string'],
                'is_available'=>['type'=>'int']
            ],
            'id' => 'update_settings',
            'type' => 'any',
            'required' => false
        ],
        'addAddress'=>[
            'properties' => [
                'address'=>['type'=>'string']
            ],
            'id' => 'addAddress',
            'type' => 'any',
            'required' => false
        ],
        'rating_review'=>[
            'properties' => [
                'to_user_id'=>['type'=>'string'],
                'request_id'=>['type'=>'integer'],
                'review_text'=>['type'=>'string'],
                'rating'=>['type'=>'string'],
                'apeerance_successfull'=>['type'=>'string']
            ],
            'id' => 'rating_review',
            'type' => 'any',
            'required' => false
        ],
        'favourite_address'=>[
            'properties' => [
                'address_id'=>['type'=>'integer'],
                'status'=>['type'=>'string'],
            ],
            'id' => 'favourite_address',
            'type' => 'any',
            'required' => false
        ],
        'add_bank_detail'=>[
            'properties' => [
                'bank_name'=>['type'=>'string'],
                'ach_bank_aba_number'=>['type'=>'string'],
                'account_number'=>['type'=>'string']
            ],
            'id' => 'add_bank_detail',
            'type' => 'any',
            'required' => false
        ],
        'edit_bank_detail'=>[
            'properties' => [
                'bank_detail_id'=>['type'=>'string'],
                'bank_name'=>['type'=>'string'],
                'ach_bank_aba_number'=>['type'=>'string'],
                'account_number'=>['type'=>'string']
            ],
            'id' => 'edit_bank_detail',
            'type' => 'any',
            'required' => false
        ],
        'contact_us'=>[
            'properties' => [
                'subject'=>['type'=>'string'],
                'message'=>['type'=>'string'],
               
                
            ],
            'id' => 'contact_us',
            'type' => 'any',
            'required' => false
        ],
    ] 
]);