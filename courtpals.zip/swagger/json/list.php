<?php

$params = require_once('params.php');

echo json_encode([
    'resourcePath' => '/list',
    'basePath' => $params['apiUrl'],
    'apis' => [
        [
            'path' => '/list/cities',
            'description' => 'Get Cities list',
            'operations' => [
                [
                    'parameters' => [
                        [
                            'name' => 'country_id',
                            'description' => "",
                            'required' => false,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'query'
                        ],
                      
                    ],
                    'summary' => 'Get Cities list',
                    'httpMethod' => 'GET',
                    'nickname' => '',
                    "consumes" => [
                       
                    ],
                ]
            ]
        ],
        [
            'path' => '/list/address',
            'description' => 'Get address',
            'operations' => [
                [
                    'parameters' => [
                        [
                            'name' => 'access-token',
                            'description' => "The user's access_token",
                            'required' => true,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'header'
                        ],
                        [
                            'name' => 'search',
                            'description' => "",
                            'required' => false,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'query'
                        ],
                      
                    ],
                    'summary' => 'Get address list',
                    'httpMethod' => 'GET',
                    'nickname' => '',
                    "consumes" => [
                       
                    ],
                ]
            ]
        ],
       
    ],
    'apiVersion' => $params['apiVersion'],
    'swaggerVersion' => $params['swaggerVersion'],
    'models' => [
        
        'addAddress'=>[
            'properties' => [
                'address'=>['type'=>'string']
            ],
            'id' => 'addAddress',
            'type' => 'any',
            'required' => false
        ],
    ] 
]);