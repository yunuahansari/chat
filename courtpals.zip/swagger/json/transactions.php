<?php

$params = require_once('params.php');

echo json_encode([
    'resourcePath' => '/transactions',
    'basePath' => $params['apiUrl'],
    'apis' => [
        [
            'path' => '/transactions',
            'description' => 'Add transaction',
            'operations' => [
                [
                    'parameters' => [
                        [
                            'name' => 'access-token',
                            'description' => "The user's access_token",
                            'required' => true,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'header'
                        ],
                        [
                            'name' => 'body',
                            'description' => "Made payment on behalf of request",
                            'required' => true,
                            'dataType' => 'string',
                            'type' => 'add_transaction',
                            'allowMultiple' => false,
                            'paramType' => 'body'
                        ],
                      
                    ],
                    'summary' => 'Add Transaction',
                    'httpMethod' => 'POST',
                    'nickname' => '',
                    "consumes" => [
                       
                    ],
                ]
            ]
        ],
        [
            'path' => '/transactions/totals',
            'description' => 'Get transactions total',
            'operations' => [
                [
                    'parameters' => [
                        [
                            'name' => 'access-token',
                            'description' => "The user's access_token",
                            'required' => true,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'header'
                        ],                     
                    ],
                    'summary' => 'Get Transaction total',
                    'httpMethod' => 'GET',
                    'nickname' => '',
                    "consumes" => [
                       
                    ],
                ]
            ]
        ],
        [
            'path' => '/transactions',
            'description' => 'Get transactions',
            'operations' => [
                [
                    'parameters' => [
                        [
                            'name' => 'access-token',
                            'description' => "The user's access_token",
                            'required' => true,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'header'
                        ],
                        [
                            'name' => 'type',
                            'description' => "should be sent/received",
                            'required' => true,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'query'
                        ],
                        [
                            'name' => 'timezone',
                            'description' => "like Asia/Kolkata",
                            'required' => false,
                            'dataType' => 'string',
                            'allowMultiple' => false,
                            'paramType' => 'query'
                        ],
                      
                    ],
                    'summary' => 'Get Transaction',
                    'httpMethod' => 'GET',
                    'nickname' => '',
                    "consumes" => [
                       
                    ],
                ]
            ]
        ],
    ],
    'apiVersion' => $params['apiVersion'],
    'swaggerVersion' => $params['swaggerVersion'],
    'models' => [
        
        'add_transaction'=>[
            'properties' => [
                'request_id'=>['type'=>'string'],
                'amount'=>['type'=>'string'],
                'token'=>['type'=>'string'],
                'card_id'=>['type'=>'string']
            ],
            'id' => 'add_transaction',
            'type' => 'any',
            'required' => false
        ],
    ] 
]);