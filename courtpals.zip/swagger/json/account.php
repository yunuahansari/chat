<?php

$params = require_once('params.php');

echo json_encode([
    'resourcePath' => '/account',
    'basePath' => $params['apiUrl'],
    'apis' => [
        [
            'path' => '/account/signup',
            'description' => 'Signup User',
            'operations' => [
                [
                    'parameters' => [
                        [
                            'name' => 'body',
                            'description' => "body",
                            'required' => false,
                            'type' => 'user_signup',
                            'paramType' => 'body'
                        ],   
                    ],
                    'summary' => 'Signup User',
                    'httpMethod' => 'POST',
                    'nickname' => 'Signup',
                    "consumes" => [
                        "application/json",
                        "application/xml"
                    ],
                ]
            ]
        ],
        [
            'path' => '/account/signup/avvo',
            'description' => 'AVVO',
            'operations' => [
                [
                    'parameters' => [
                        [
                            'name' => 'body',
                            'description' => 'AVVO Signup',
                            'required' => false,
                            'type' => 'avvo_signup',
                            'paramType' => 'body'
                        ],
                    ],
                    'summary' => 'AVVO Signup',
                    'httpMethod' => 'POST',
                    'nickname' => 'AVVO',
                    "consumes" => [
                        "application/json",
                        "application/xml"
                    ],
                ]
            ]
        ],
        [
            'path' => '/account/signup/linkedin',
            'description' => 'Linkedin',
            'operations' => [
                [
                    'parameters' => [
                        [
                            'name' => 'body',
                            'description' => 'Linkedin Signup',
                            'required' => false,
                            'type' => 'linkedin_signup',
                            'paramType' => 'body'
                        ],
                    ],
                    'summary' => 'Linkedin Signup',
                    'httpMethod' => 'POST',
                    'nickname' => 'Linkedin',
                    "consumes" => [
                        "application/json",
                        "application/xml"
                    ],
                ]
            ]
        ],
        [
            'path' => '/account/login',
            'description' => 'Account Login',
            'operations' => [
                [
                    'parameters' => [
                        [
                            'name' => 'body',
                            'description' => '"device_type":"ios/android", "certification_type": "development/distribution"',
                            'required' => false,
                            'type' => 'login',
                            'paramType' => 'body'
                        ],
                    ],
                    'summary' => 'Login a user',
                    'httpMethod' => 'POST',
                    'errorResponses' => [
                        [
                            'reason' => 'Incorrect email or password',
                            'code' => 200
                        ]
                    ],
                    'nickname' => 'login',
                ]
            ]
        ],
        [
            'path' => '/account/forgot-password',
            'description' => 'Forgot Password',
            'operations' => [
                [
                    'parameters' => [
                        [
                            'name' => 'body',
                            'description' => 'Forgot Password',
                            'required' => false,
                            'type' => 'forgot',
                            'paramType' => 'body'
                        ],
                    ],
                    'summary' => 'Forgot Password',
                    'httpMethod' => 'POST',
                    'errorResponses' => [
                    ],
                    'nickname' => 'Forgot Password',
                    "consumes" => [
                        "application/json",
                        "application/xml"
                    ],
                ],
            ]
        ],
        [
            'path' => '/account/reset-password',
            'description' => 'Reset Password',
            'operations' => [
                [
                    'parameters' => [
                         [
                            'name' => 'body',
                            'description' => 'Reset Password',
                            'required' => false,
                            'type' => 'resetpassword',
                            'paramType' => 'body'
                        ],
                    ],
                    'summary' => 'Reset Password',
                    'httpMethod' => 'POST',
                    'errorResponses' => [
                    ],
                    'nickname' => 'resetpassword',
                    "consumes"=> [
                                "application/json",
                                "application/xml"
                              ],
                ],
            ]
        ],
        [
            'path' => '/account/send-email',
            'description' => 'check email',
            'operations' => [
                [
                    'parameters' => [
                        [
                            'name' => 'email',
                            'description' => '',
                            'required' => true,
                            'type' => 'string',
                            'paramType' => 'query'
                        ],
                    ],
                    'summary' => 'check email',
                    'httpMethod' => 'GET',
                    'nickname' => 'check email',
                    'consumes' => [
                        "application/json",
                        "application/xml"
                    ],
                ]
            ]
        ],
    ],
    'apiVersion' => $params['apiVersion'],
    'swaggerVersion' => $params['swaggerVersion'],
    'models' => [
        'user_signup'=>[
            'properties' => [
                'first_name'=>['type'=>'string'],
                'last_name'=>['type'=>'string'],
                'email'=>['type'=>'string'],
                'password'=>['type'=>'string'],
//                'device_id'=>['type'=>'string'],
//                'device_type'=>['type'=>'string'],
//                'certification_type'=>['type'=>'string'],
            ],
            'id' => 'user_signup',
            'type' => 'any',
            'required' => false
        ],
        'avvo_signup'=>[
            'properties' => [
                'first_name'=>['type'=>'string'],
                'last_name'=>['type'=>'string'],
                'email'=>['type'=>'string'],
                'profile_pic'=>['type'=>'string'],
                'source_id'=>['type'=>'string'],
                'device_id'=>['type'=>'string'],
                'device_type'=>['type'=>'string'],
                'certification_type'=>['type'=>'string'],
            ],
            'id' => 'avvo_signup',
            'type' => 'any',
            'required' => false
        ],
        'linkedin_signup'=>[
            'properties' => [
                'first_name'=>['type'=>'string'],
                'last_name'=>['type'=>'string'],
                'email'=>['type'=>'string'],
                'profile_pic'=>['type'=>'string'],
                'source_id'=>['type'=>'string'],
                'device_id'=>['type'=>'string'],
                'device_type'=>['type'=>'string'],
                'certification_type'=>['type'=>'string'],
            ],
            'id' => 'linkedin_signup',
            'type' => 'any',
            'required' => false
        ],
        'login'=>[
            'properties' => [
                'email'=>['type'=>'string'],
                'password'=>['type'=>'string'],
                'device_id'=>['type'=>'string'],
                'device_type'=>['type'=>'string'],
                'certification_type'=>['type'=>'string'],
            ],
            'id' => 'login',
            'type' => 'any',
            'required' => false
        ],
        'forgot'=>[
            'properties' => [
                'email'=>['type'=>'string'],
            ],
            'id' => 'forgot',
            'type' => 'any',
            'required' => false
        ],
        'resetpassword'=>[
            'properties' => [
                'verified_code'=>['type'=>'string'],
                'new_password'=>['type'=>'string'],
                'confirm_password'=>['type'=>'string'],
            ],
            'id' => 'resetpassword',
            'type' => 'any',
            'required' => false
        ],
    ]
]);
