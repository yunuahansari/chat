@extends('player::layouts.app')

@section('content')

<div class="main-content">
    <section class="chat">
        <div class="container-fluid">
            <div class="heading d-flex align-items-center">
                <h2>Inbox</h2>
<!--                <div class="ml-auto">
                    <a href="javascript:void(0);" class="btn btn-success btn-lg font-20 p-15-30 border-2">NEW MESSAGE</a>
                </div>-->
            </div>
            <div class="chat_list d-flex">
                <div class="chat_users">
                    <div class="chat_toolbar">
                        <div class="search_bar">
                            <div class="collapse" id="search_box">
                                <div class="input-group">
                                    <div class="icon search_icon" onclick="filterChatUsers()">
                                        <i class="flaticon-searching-magnifying-glass "></i>
                                    </div>
                                    <input type="text" class="form-control bg-transparent border-0" id="search_text" placeholder="Search" onkeyup="filterChatUsers()">
                                    <div class="icon close_icon">
                                        <a href="javascript:void(0);" id="close_btn" onclick="clearChatFilter()">
                                            <i class="flaticon-cross"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <ul class="list-inline mb-0 action text-right">
                                <li class="list-inline-item d-none">
                                    <a href="javascript:void(0);" class="searchmsg_icon" id="search_msg">
                                        <i class="flaticon-searching-magnifying-glass"></i>
                                    </a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="javascript:void(0);" class="search_toggle" id="searchicon">
                                        <i class="flaticon-filter-results-button"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <ul class="users_list list-unstyled black-scroll mb-0" data-mcs-theme="dark" id="get-chat-users">

                    </ul>
                </div>
                <div class="chat_content" id="get-user-messages">
   
                </div>
            </div>
        </div>
    </section>
</div>

<script>
    
    $('.action .dropdown').on('show.bs.dropdown', function (e) {
        $(this).find('.dropdown-menu').first().stop(true, true).slideDown(300);
    });
    $('.action .dropdown').on('hide.bs.dropdown', function (e) {
        $(this).find('.dropdown-menu').first().stop(true, true).slideUp(200);
    });

    $("#searchicon").click(function () {
        $("#search_box").show();
        $(".search_bar .action").hide();
    });

    $("#close_btn").click(function () {
        $("#search_box").hide();
        $(".search_bar .action").show();
    });

    $(".chat_users .users_list li a").click(function () {
        $('.chat_list .chat_content').addClass("open");
    });
    $("#backicon").click(function () {
        $('.chat_list .chat_content').removeClass("open");
    });
    
    // Function for get new job list.
    function getChatUsers(){
        $.get("{{ url('player/get-chat-users') }}", function(response){
            if(response.success){
                $("#get-chat-users").html(response.html);
            }else{
                message('error', response.message);
            }
        });
    }
    
    // Function for get new job list.
    function getChatUsersOnReady(){
        $.get("{{ url('player/get-chat-users') }}", function(response){
            if(response.success){
                $("#get-chat-users").html(response.html);
                $("#get-chat-users li a").first().trigger('click');
            }else{
                message('error', response.message);
            }
        });
    }
    
    // Function for get user messages.
    function getUserMessages(id, toId){
        $.get("{{ url('player/get-user-messages') }}", {chat_id: id, to_id: toId}, function(response){
            if(response.success){
                $("#get-user-messages").html(response.html);
                updateReadCount(id);
                getChatUsers();
            }else{
                message('error', response.message);
            }
        });
    }
    
    // Function for update read coount.
    function updateReadCount(chatId){
        $.get("{{ url('player/update-read-count') }}", {chat_id: chatId});
    }
    
    // Socket for type chat msg text.
    $(document).on('keyup', '#chatMsgText', function(event){
        var chatId = $("input[name='chat_id']").val();
        var fromId = $("input[name='from_id']").val();
        if((event.keyCode >= 48 && event.keyCode <= 57) || (event.keyCode >= 96 && event.keyCode <= 105) || (event.keyCode >= 65 && event.keyCode <= 90)){
            socket.emit('is typing', {chat_id:chatId, from_id:fromId});
        }    
    });
    
    // Socket for show typing div.
    socket.on('typing', function(data){
        if(parseInt(data.from_id) != userId){
            $('#typing-hint-'+data.chat_id).show();
        } 
    });
    
    // Function for stop typing.
    $(document).on('blur', '#chatMsgText', function(){
        var chatId = $("input[name='chat_id']").val();
        var fromId = $("input[name='from_id']").val();
        socket.emit('stop_typing', {chat_id:chatId, from_id:fromId});
    });
    
    // Socket for show typing div.
    socket.on('hide_typing', function(data){
        if(parseInt(data.from_id) != userId){
            $('#typing-hint-'+data.chat_id).hide();
        }    
    });
    
    // Function for send chat message.
    $(document).on('submit', '#send-chat-message', function(e){
        e.preventDefault();
        var formData = new FormData($(this)[0]);
        $.ajax({
            url: $(this).attr('action'),
            data: formData,
            processData: false,
            contentType: false,
            type: 'POST',
            dataType: 'JSON',
            success: function (response) {
                if (response.success) {
                    $('#send-chat-message').trigger('reset');
                    socket.emit('msg', response.data);
                } else {
                    message('error', response.message);
                }
            }
        });
    });
        
    socket.on('newmsg', function(response) {
        if( response.from_id == userId ){
            $('#user-last-msg-'+response.otherUser).html(response.message);
            $('#chat-message-box-'+response.chat_id).find('.mCSB_container').append('<div class="msg msg_sent clearfix">\
                <div class="bubble">\
                    <div class="bubble_wrapper d-flex align-items-center">\
                        <div class="msg_content text-right">\
                            <p class="mb-0">'+response.message+'</p>\
                        </div>\
                        <div class="user_img align-self-start">\
                            <img class="rounded-circle" src="'+response.userImg+'" alt="chat user">\
                            <p class="time mb-0">'+response.time+'</p>\
                        </div>\
                    </div>\
                </div>\
            </div>');
        }else{
            var openChat = $("input[name='chat_id']").val();
            console.log('player : '+openChat);
            console.log('player : '+response.chat_id);
            if( openChat == response.chat_id ){
                updateReadCount(response.chat_id);
            }
            $('#user-last-msg-'+response.from_id).html(response.message);
            $('#chat-message-box-'+response.chat_id).find('.mCSB_container').append('<div class="msg msg_recipient clearfix">\
                <div class="bubble">\
                    <div class="bubble_wrapper d-flex align-items-center">\
                        <div class="user_img align-self-start">\
                            <img class="rounded-circle" src="'+response.userImg+'" alt="chat user">\
                            <p class="time mb-0">'+response.time+'</p>\
                        </div>\
                        <div class="msg_content text-left">\
                            <p class="mb-0">'+response.message+'</p>\
                        </div>\
                    </div>\
                </div>\
            </div>');
        }
                /*scroll chat top to bottom*/
              chat_scroll.mCustomScrollbar("scrollTo","bottom",{ scrollEasing:"easeOut"});
        setTimeout(function(){ getChatUsers(); },1000);
    });
    
    // Function for download attachment file from chat.
    $(document).on('click', '.downloadAttachment', function(){
        var url = $(this).data('url');
        var name = $(this).data('name');
        var link = document.createElement("a");
        link.download = name;
        link.href = url;
        link.click();
    });
    
    // Function for run default functions on page ready.
    $(document).ready(function(){
        getChatUsersOnReady();
    });

      /* Chat user filter */
    function filterChatUsers(){
        
        var serach_text = $('#search_text').val();
        var users = [];
        $(".chatUserName").each(function(){
                if($(this).text().toLowerCase().search(serach_text.toLowerCase()) != -1) {
                   users.push($(this).data('user_id'));
                   $('#user_'+$(this).data('user_id')).show();
                   $('#no_user').hide();
                }else{
                    $('#user_'+$(this).data('user_id')).hide();
                }
            if(users.length == 0){
                $('#no_user').show();
            }
        });
    }
    
    /* Clear chat filter */
    function clearChatFilter(){
        $('#search_text').val('');
        getChatUsers();
    }

      
</script>

@endsection