<div class="conversation_header">
    <div class="user_details d-flex align-items-center">
        <div class="user_img">
            <img class="rounded-circle" src="{{ checkUserImage(getUserById($to_id, 'profile_image'), getUserById($to_id, 'role')) }}" alt="user img">
            <span class="name text-uppercase">{{ getUserById($to_id, 'first_name').' '.getUserById($to_id, 'last_name') }}</span>
        </div>
        <div class="action ml-auto">
            <ul class="list-inline mb-0">
                <li class="list-inline-item">
                    <div class="dropdown">
                        <button class="btn dropdown-toggle bg-transparent p-0" type="button" id="action" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="flaticon-more-button-interface-symbol-of-three-horizontal-aligned-dots"></i>
                        </button>
                        <div class="dropdown-menu rounded-0 " aria-labelledby="action">
                                <?php  if($connectionType == 'accept'){
                                            $blockBtn = 'block';
                                            $unblockBtn = 'none';
                                            $reportBtn = 'block';        
                                        }else if($connectionType == 'block'){
                                            $blockBtn = 'none';
                                            $unblockBtn = 'block';
                                            $reportBtn = 'none';   
                                        }else{
                                            $blockBtn = 'none';
                                            $unblockBtn = 'none';
                                            $reportBtn = 'none';   
                                        } 
                                ?>
                            <a href="javascript:void(0);" style="display:{{$blockBtn}}" id="blockBtn" class="dropdown-item" onclick="blockUnBlockUser({{$to_id}},'block')">Block</a>
                            <a href="javascript:void(0);" style="display:{{$unblockBtn}}"  id="unBlockBtn" class="dropdown-item" onclick="blockUnBlockUser({{$to_id}},'unblock')">Unblock</a>
                            @php
                            $getChat = getIncidentDataByStatus(Auth::guard(getAuthGuard())->user()->id,$to_id, 'chat');
                            @endphp
                            @if($getChat != 'open')
                            <a href="javascript:void(0);" class="dropdown-item" id="reprotBtn"  style="display:{{$reportBtn}}" onclick="addReport('{{Auth::guard(getAuthGuard())->user()->id}}','{{$to_id}}', 'chat')">Report</a>
                            @endif
                        </div>
                    </div>
                </li>
                <li class="list-inline-item d-md-none">
                    <a href="javascript:void(0);" class="back_icon" id="backicon">
                        <!-- > -->
                        <i class="flaticon-angle-arrow-down"></i>  
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div>
<div class="conversation_body  black-scroll" data-mcs-theme="dark" id="chat-message-box-{{ $chat_id }}">
    @if( count($messages) > 0 )
    @foreach( $messages as $message )
    @php $userId = \Auth::guard(getAuthGuard())->user()->id; @endphp
    @if( $message->from_id == $userId )
    <div class="msg msg_sent clearfix">
        <div class="bubble">
            <div class="bubble_wrapper d-flex align-items-center">
                <div class="msg_content text-right">
                    <p class="mb-0">{!!$message->message!!}</p>
                </div>
                <div class="user_img align-self-start text-right">
                    <img class="rounded-circle" src="{{ checkUserImage(getUserById($userId, 'profile_image'), getUserById($userId, 'role')) }}" alt="chat user">
                    <p class="time mb-0">{{ timeFormat($message->created_at) }}</p>
                </div>
            </div>
        </div>
    </div>
    @else
    <div class="msg msg_recipient clearfix">
        <div class="bubble">
            <div class="bubble_wrapper d-flex align-items-center">
                <div class="user_img align-self-start">
                    <img class="rounded-circle" src="{{ checkUserImage(getUserById($to_id, 'profile_image'), getUserById($to_id, 'role')) }}" alt="chat user">
                    <p class="time mb-0">{{ timeFormat($message->created_at) }}</p>
                </div>
                <div class="msg_content text-left">
                    <p class="mb-0">{!!$message->message!!}</p>
                </div>
            </div>
        </div>
    </div>
    @endif
    @endforeach
    @endif
</div>
<div class="conversation_footer">
    <div class="send_msg">
        <form id="send-chat-message" method="post" action="{{ url('player/send-chat-message') }}">
            {{ csrf_field() }}
            <input type="hidden" name="from_id" value="{{ $from_id }}"/>
            <input type="hidden" name="to_id" value="{{ $to_id }}"/>
            <input type="hidden" name="chat_id" value="{{ $chat_id }}"/>
            <div class="chat_input">
                <input type="text" id="chatMsgText" <?php echo ($connectionType == 'accept')?'':'disabled'?> name="message" class="form-control bg-transparent border-0 rounded-0" placeholder="Type a Message...">
            </div>
            <ul class="list-inline action mb-0">
                <li class="list-inline-item">	
                    <div class="file_upload">
                        <input type="file" name="attachment" id="file_attached" hidden="" <?php echo ($connectionType == 'accept')?'':'disabled'?>>
                        <label class="icon mb-0" for="file_attached">
                            <i class="flaticon-paper-clip"></i>
                        </label>
                    </div>
                </li>
                <li class="list-inline-item">
                    <button type="submit" id="sendBtn" class="btn btn-success font-22 p-4-25 btn-lg border-2" <?php echo ($connectionType == 'accept')?'':'disabled'?>>SEND</button>
                </li>
            </ul>
        </form>
        {!! JsValidator::formRequest('App\Player\Http\Requests\SendChatMessageRequest','#send-chat-message') !!}
    </div>
</div>
<!-- Add report modal -->
<div class="modal fade modal-center share-article" data-backdrop="static" data-keyboard="false" id="add_report" data-easein="flipBounceXIn" tabindex="-1" role="dialog" aria-labelledby="post_title" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content" id="add-report-data">
            <div class="btn_loader btn_ring" id="listLoader"></div>
        </div>
    </div>
</div>
<script>
                // Function for Add report.
                    function addReport(fromId, toId, role) {
                    $.get("{{ url('add-report-form') }}", function (data) {
                    $("#add-report-data").html(data.html);
                            $('#add_report').modal('show');
                            $("#fromId").val(fromId);
                            $("#toId").val(toId);
                            $("#reportedEntity").val(role);
                    });
                    }
    /*Initialize scroll*/
    chat_scroll = $('#chat-message-box-{{ $chat_id }}').mCustomScrollbar({
                    theme:"dark",
                     axis:"y"
                });
                /*scroll chat bottom*/
                 chat_scroll.mCustomScrollbar("scrollTo","bottom",{
                scrollEasing:"easeOut"
                });
    $(document).ready(function () {
        $("[name=attachment]").change(function () {
            if (this.files && this.files[0]) {
                if (this.files[0]['name'].split('.').pop().toLowerCase() == 'jpg' ||
                    this.files[0]['name'].split('.').pop().toLowerCase() == 'jpeg' ||
                    this.files[0]['name'].split('.').pop().toLowerCase() == 'png' ||
                    this.files[0]['name'].split('.').pop().toLowerCase() == 'doc' ||
                    this.files[0]['name'].split('.').pop().toLowerCase() == 'pdf' ||
                    this.files[0]['name'].split('.').pop().toLowerCase() == 'docx' ||
                    this.files[0]['name'].split('.').pop().toLowerCase() == 'mp4' ||
                    this.files[0]['name'].split('.').pop().toLowerCase() == 'mov' ||
                    this.files[0]['name'].split('.').pop().toLowerCase() == 'zip')
                {
                    if (this.files[0].size < 2000000)  // less than 2 mb
                    {
                        var reader = new FileReader();
                        reader.onload = function (e) {
                         //   $('#front_image').attr('src', e.target.result);
                        };
                        reader.readAsDataURL(this.files[0]);
                        $(this).closest('form').submit();
                    }
                    else
                    {
                        $('#file_attached').val('');
                        message('error', 'File has to be smaller than 2MB.');
                        return false;
                    }
                }
                else
                {
                    $('#file_attached').val('');
                    message('error', 'Only jpg, jpeg, png, doc, docx, pdf, mp4, mov and zip files are allowed.');
                    return false;
                }
            }
        });
    });
    
    $(function () {
            $('#chatMsgText').blur(function () {                        
                $(this).val(
                    $.trim($(this).val())
                );
            });
        });
        
        
    function blockUnBlockUser(to_id,type){
         var token = '{{ csrf_token() }}';
         $.ajax({
            url: "{{url('player/block-chat-user')}}", 
            type: 'POST',
            data:{_token: token,user_id:to_id,type:type},
            dataType: 'JSON',
            success: function(result){
                 if(result.success){
                      $('#reprotBtn').hide();
                      if(type == 'block'){
                        $('#blockBtn').hide();
                        $('#unBlockBtn').show();
                      }
//                      else{
//                        $('#blockBtn').show();
//                        $('#unBlockBtn').hide();
//                      }
                      $('#file_attached').prop('disabled',true);
                      $('#chatMsgText').prop('disabled',true);
                      $('#sendBtn').prop('disabled',true);
                 }else{
                      console.log(result.message);
                 }
             } 
         });
    }    
        
</script>